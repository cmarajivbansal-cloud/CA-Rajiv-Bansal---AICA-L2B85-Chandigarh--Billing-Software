# Tax-Compliant Intelligent Multi-Tenant GST Billing Suite
## Capstone Project - AICA Level 2 Certificate Course

**Candidate:** CMA Rajiv Bansal (FCMA)  
**Email:** CMARAJIVBANSAL@gmail.com  
**Course:** Artificial Intelligence in Cost & Management Accounting (AICA) Level 2  
**Live Application URL:** https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app  

---

## 🚀 Optimization & Size Metrics (Strictly Under 25MB)

All build outputs, submission dossiers, and executable packages have been engineered to stay strictly under the **25 MB limit** (each under **3 MB**):

| Deliverable Artifact | Description | Target Limit | Optimized Size | Status |
| :--- | :--- | :--- | :--- | :--- |
| **`Tax_Compliant_Billing_Suite.exe`** | Standalone Single-File Windows Executable | < 25 MB | **~0.62 MB** | ✅ 99.7% Optimized |
| **`Tax_Compliant_Billing_Suite_Portable_Win64.zip`** | Portable Windows Package with Shortcuts | < 25 MB | **~0.29 MB** | ✅ Sub-1MB |
| **`AICA_Level_2_Project_CMA_Rajiv_Bansal.zip`** | Official AICA Capstone Submission Dossier | < 25 MB | **~0.45 MB** | ✅ Sub-1MB |
| **`Tax_Compliant_Billing_Suite_Full_Codebase.zip`** | Complete Source Code Archive | < 25 MB | **~0.16 MB** | ✅ Sub-1MB |

---

## ⚡ Quick Execution Methods

### Method 1: Instant Native Windows Desktop App (Zero Setup)
1. Double-click `Tax_Compliant_Billing_Suite.exe` in `release/` or run `Launch_App.bat`.
2. The application opens instantly in dedicated desktop app window mode with full offline functionality.
3. No Node.js, Electron, or internet connection required.

### Method 2: Local Web Development Server
```bash
# 1. Install dependencies
npm install

# 2. Start development server (port 3000)
npm run dev

# 3. Open in browser: http://localhost:3000
```

### Method 3: One-Click Build & Package All
```bash
npm run optimize
```
*(Automatically builds Vite production bundle, compiles standalone `.exe`, and creates all sub-25MB distribution and submission ZIP archives).*

---

## 🌟 Key Features

1. **Master Admin Licensing Engine**:
   - Master account for **CMA Rajiv Bansal** (FCMA).
   - Cryptographic SHA-256 license key generation and email dispatch.
   - Client isolation with immutable firm profile locks (GSTIN, PAN, Bank IFSC, State Code).

2. **Automated Statutory GST Invoicing**:
   - Section 7 & 8 IGST Act place of supply logic (Intra-State CGST+SGST 50/50 vs Inter-State IGST 100%).
   - Multi-tier statutory tax slabs (0%, 5%, 12%, 18%, 28%) and HSN directory.
   - 5 High-resolution printable A4 templates (Modern Navy, Classic Corporate, Clean Minimalist, Tax Compact, Retail POS).
   - Dual signature blocks (Taxpayer & Chartered/Cost Accountant).
   - Dynamic Indian Rupee currency words conversion.

3. **GSTR Excel Reporting**:
   - Multi-tab automated GSTR-1 workbook synthesizer (`.xlsx`) conforming to GST portal offline tool schemas (B2B Table 4, B2C Table 7, HSN Summary Table 12).
