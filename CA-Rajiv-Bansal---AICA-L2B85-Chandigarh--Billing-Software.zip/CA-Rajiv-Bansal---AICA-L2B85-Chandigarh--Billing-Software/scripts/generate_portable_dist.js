import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '..');
const releaseDir = path.join(rootDir, 'release');
const exePath = path.join(releaseDir, 'Tax_Compliant_Billing_Suite.exe');
const zipOut = path.join(releaseDir, 'Tax_Compliant_Billing_Suite_Portable_Win64.zip');

async function generatePortableZip() {
  if (!fs.existsSync(exePath)) {
    console.log('Standalone executable not found, building first...');
    const { execSync } = await import('child_process');
    execSync('node scripts/build_single_exe.js', { cwd: rootDir, stdio: 'inherit' });
  }

  console.log('\n📦 Creating Portable Windows Standalone ZIP Package...');
  const zip = new JSZip();

  // Add the standalone executable
  zip.file('Tax_Compliant_Billing_Suite.exe', fs.readFileSync(exePath));

  // Add quick launcher batch file
  zip.file(
    'Launch_Billing_Suite.bat',
    `@echo off
title Tax Compliant Billing & Invoicing Suite
echo Starting Tax Compliant Billing & Invoicing Suite...
start "" "%~dp0Tax_Compliant_Billing_Suite.exe"
`
  );

  // Add shortcut creation batch file
  zip.file(
    'Create_Desktop_Shortcut.bat',
    `@echo off
echo ========================================================
echo   TAX COMPLIANT BILLING SUITE - SHORTCUT CREATOR
echo ========================================================
echo.
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Tax Compliant Billing Suite.lnk')); $s.TargetPath = '%~dp0Tax_Compliant_Billing_Suite.exe'; $s.WorkingDirectory = '%~dp0'; $s.Save()"
echo [OK] Desktop Shortcut successfully created on your Desktop!
echo.
pause
`
  );

  // Add README
  zip.file(
    'README_HOW_TO_USE.txt',
    `========================================================================
TAX COMPLIANT BILLING & INVOICING SUITE - PORTABLE WINDOWS EDITION
Capstone Project: AICA Level 2 Certificate Course
Author: CMA Rajiv Bansal (FCMA) | Email: CMARAJIVBANSAL@gmail.com
========================================================================

QUICK START INSTRUCTIONS:
1. Double click "Tax_Compliant_Billing_Suite.exe" to start immediately.
2. No installation or Node.js required - runs 100% offline.
3. To create a Desktop shortcut, run "Create_Desktop_Shortcut.bat".

SYSTEM REQUIREMENTS:
- Windows 10 or Windows 11 (64-bit)
- Microsoft Edge or Google Chrome

FEATURES:
- Full GST Invoicing with 0%, 5%, 12%, 18%, 28% tax slabs.
- Place of Supply tax split (Intra-State CGST/SGST vs Inter-State IGST).
- 5 Printable A4 Tax Invoice Templates.
- Multi-Tab GSTR-1 Excel (.xlsx) Register Generator.
- Master Admin Licensing System with SHA-256 validation.
- Zero-cloud offline data security with client profile storage.
`
  );

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  fs.writeFileSync(zipOut, zipBuffer);

  const stats = fs.statSync(zipOut);
  const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
  console.log(`\n✅ Portable Windows ZIP successfully created at:`);
  console.log(`   - File: ${zipOut}`);
  console.log(`   - Final ZIP Size: ${sizeMB} MB (Target: < 25 MB, Status: OPTIMIZED 🚀)`);
}

generatePortableZip().catch(err => {
  console.error('Failed to generate portable zip:', err);
  process.exit(1);
});
