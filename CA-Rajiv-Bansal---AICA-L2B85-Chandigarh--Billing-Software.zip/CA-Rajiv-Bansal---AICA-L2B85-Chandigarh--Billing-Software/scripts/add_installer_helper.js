import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const targetDir = path.join(__dirname, '../release/win-unpacked');

if (fs.existsSync(targetDir)) {
  // 1. Create desktop shortcut batch file
  const shortcutBat = `@echo off
echo ========================================================
echo   TAX COMPLIANT BILLING SUITE - SHORTCUT CREATOR
echo ========================================================
echo.
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Tax Compliant Billing Suite.lnk')); $s.TargetPath = '%~dp0Tax Compliant Billing & Invoicing Suite.exe'; $s.WorkingDirectory = '%~dp0'; $s.Save()"
echo [OK] Desktop Shortcut successfully created!
echo.
echo You can now launch the application directly from your Desktop.
pause
`;
  fs.writeFileSync(path.join(targetDir, 'Create_Desktop_Shortcut.bat'), shortcutBat);

  // 2. Direct runner batch file
  const runnerBat = `@echo off
start "" "%~dp0Tax Compliant Billing & Invoicing Suite.exe"
`;
  fs.writeFileSync(path.join(targetDir, 'Launch_Billing_Suite.bat'), runnerBat);
  
  console.log('Created shortcut creator and runner scripts in release/win-unpacked');
}
