using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace TaxCompliantBillingSuite
{
    static class Program
    {
        private static HttpListener listener;
        private static Thread serverThread;
        private static string appDir;
        private static int activePort = 3850;
        private static bool isRunning = true;
        private static NotifyIcon trayIcon;
        private static Mutex appMutex;

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Single instance lock
            bool createdNew;
            appMutex = new Mutex(true, "TaxCompliantBillingSuite_SingleInstance_Mutex", out createdNew);

            if (!createdNew)
            {
                // Already running, simply launch/focus app in browser and exit
                LaunchBrowserWindow("http://localhost:3850/");
                return;
            }

            try
            {
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string installDir = Path.Combine(localAppData, "TaxCompliantBillingSuite");
                appDir = Path.Combine(installDir, "dist");

                // Check version / extract embedded web app payload
                EnsureAppPayloadExtracted(installDir, appDir);

                // Start lightweight embedded HTTP server
                StartHttpServer();

                // Create Desktop & Start Menu Shortcuts
                CreateAppShortcuts();

                // Initialize System Tray Icon
                InitializeTrayIcon();

                // Launch Edge / Chrome in Dedicated App Window Mode
                LaunchAppWindow();

                // Run message loop
                Application.Run();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to start Tax Compliant Billing Suite:\n\n" + ex.Message, 
                                "Tax Compliant Billing Suite", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (trayIcon != null)
                {
                    trayIcon.Visible = false;
                    trayIcon.Dispose();
                }
                StopHttpServer();
                if (appMutex != null)
                {
                    appMutex.ReleaseMutex();
                    appMutex.Close();
                }
            }
        }

        private static void EnsureAppPayloadExtracted(string installDir, string appDir)
        {
            if (!Directory.Exists(installDir))
            {
                Directory.CreateDirectory(installDir);
            }

            string exePath = Assembly.GetExecutingAssembly().Location;
            string markerFile = Path.Combine(installDir, "version.txt");
            string currentBuildId = "BUILD_" + (File.Exists(exePath) ? File.GetLastWriteTimeUtc(exePath).Ticks.ToString() : "1.0.0");
            string indexPath = Path.Combine(appDir, "index.html");

            bool needsExtraction = !Directory.Exists(appDir) || !File.Exists(indexPath) || !File.Exists(markerFile) || File.ReadAllText(markerFile).Trim() != currentBuildId;

            if (needsExtraction)
            {
                if (Directory.Exists(appDir))
                {
                    try { Directory.Delete(appDir, true); } catch { }
                }
                Directory.CreateDirectory(appDir);

                var assembly = Assembly.GetExecutingAssembly();
                using (Stream stream = assembly.GetManifestResourceStream("app_payload.zip"))
                {
                    if (stream != null)
                    {
                        using (ZipArchive archive = new ZipArchive(stream))
                        {
                            archive.ExtractToDirectory(appDir);
                        }
                        File.WriteAllText(markerFile, currentBuildId);
                    }
                    else
                    {
                        // Check if running directly adjacent to dist/ folder
                        string localDist = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dist");
                        if (Directory.Exists(localDist))
                        {
                            Program.appDir = localDist;
                        }
                    }
                }
            }
        }

        private static void StartHttpServer()
        {
            int port = 3850;
            while (port < 3900)
            {
                try
                {
                    listener = new HttpListener();
                    listener.Prefixes.Add("http://localhost:" + port + "/");
                    listener.Prefixes.Add("http://127.0.0.1:" + port + "/");
                    listener.Start();
                    activePort = port;
                    break;
                }
                catch
                {
                    if (listener != null)
                    {
                        try { listener.Close(); } catch { }
                    }
                    port++;
                }
            }

            serverThread = new Thread(ListenLoop);
            serverThread.IsBackground = true;
            serverThread.Start();
        }

        private static void ListenLoop()
        {
            while (isRunning && listener != null && listener.IsListening)
            {
                try
                {
                    HttpListenerContext context = listener.GetContext();
                    ThreadPool.QueueUserWorkItem(delegate(object ctxObj)
                    {
                        ProcessRequest((HttpListenerContext)ctxObj);
                    }, context);
                }
                catch
                {
                    if (!isRunning) break;
                }
            }
        }

        private static void ProcessRequest(HttpListenerContext context)
        {
            try
            {
                HttpListenerRequest request = context.Request;
                HttpListenerResponse response = context.Response;

                string rawUrl = request.RawUrl;
                if (string.IsNullOrEmpty(rawUrl) || rawUrl == "/")
                {
                    rawUrl = "/index.html";
                }

                // Strip query parameters
                int queryIdx = rawUrl.IndexOf('?');
                if (queryIdx >= 0)
                {
                    rawUrl = rawUrl.Substring(0, queryIdx);
                }

                string relativePath = rawUrl.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
                string filePath = Path.Combine(appDir, relativePath);

                // Fallback to index.html for Single Page App routing
                if (!File.Exists(filePath))
                {
                    filePath = Path.Combine(appDir, "index.html");
                }

                if (File.Exists(filePath))
                {
                    byte[] buffer = File.ReadAllBytes(filePath);
                    response.ContentType = GetMimeType(Path.GetExtension(filePath));
                    response.ContentLength64 = buffer.Length;
                    response.AddHeader("Cache-Control", "no-cache");
                    response.OutputStream.Write(buffer, 0, buffer.Length);
                    response.OutputStream.Close();
                }
                else
                {
                    response.StatusCode = 404;
                    byte[] notFound = Encoding.UTF8.GetBytes("File Not Found");
                    response.OutputStream.Write(notFound, 0, notFound.Length);
                    response.OutputStream.Close();
                }
            }
            catch
            {
                // Connection closed by client
            }
        }

        private static string GetMimeType(string ext)
        {
            switch (ext.ToLower())
            {
                case ".html": return "text/html; charset=utf-8";
                case ".js": return "application/javascript; charset=utf-8";
                case ".css": return "text/css; charset=utf-8";
                case ".json": return "application/json";
                case ".png": return "image/png";
                case ".jpg":
                case ".jpeg": return "image/jpeg";
                case ".svg": return "image/svg+xml";
                case ".ico": return "image/x-icon";
                case ".woff": return "font/woff";
                case ".woff2": return "font/woff2";
                case ".ttf": return "font/ttf";
                case ".xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                default: return "application/octet-stream";
            }
        }

        private static void InitializeTrayIcon()
        {
            try
            {
                trayIcon = new NotifyIcon();
                
                try
                {
                    trayIcon.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
                }
                catch
                {
                    trayIcon.Icon = SystemIcons.Application;
                }

                trayIcon.Text = "Tax Compliant Billing & Invoicing Suite (Running)";
                trayIcon.Visible = true;

                ContextMenu menu = new ContextMenu();
                MenuItem openItem = new MenuItem("Open Billing Suite", delegate(object s, EventArgs e) { LaunchAppWindow(); });
                openItem.DefaultItem = true;
                menu.MenuItems.Add(openItem);

                menu.MenuItems.Add(new MenuItem("Open in Default Browser", delegate(object s, EventArgs e) { 
                    LaunchBrowserWindow("http://localhost:" + activePort + "/"); 
                }));

                menu.MenuItems.Add(new MenuItem("-"));

                menu.MenuItems.Add(new MenuItem("Local LAN Network Info...", delegate(object s, EventArgs e) { 
                    ShowNetworkInfo(); 
                }));

                menu.MenuItems.Add(new MenuItem("-"));

                menu.MenuItems.Add(new MenuItem("Exit Application", delegate(object s, EventArgs e) { 
                    trayIcon.Visible = false;
                    Application.Exit(); 
                }));

                trayIcon.ContextMenu = menu;
                trayIcon.DoubleClick += delegate(object s, EventArgs e) { LaunchAppWindow(); };
            }
            catch { }
        }

        private static void ShowNetworkInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Tax Compliant Billing & Invoicing Suite is running locally.");
            sb.AppendLine();
            sb.AppendLine("Local Address: http://localhost:" + activePort);
            sb.AppendLine();
            sb.AppendLine("To access from other devices (phones/tablets/PCs) on the same Wi-Fi network:");

            try
            {
                string hostName = Dns.GetHostName();
                IPAddress[] ips = Dns.GetHostAddresses(hostName);
                foreach (IPAddress ip in ips)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ip))
                    {
                        sb.AppendLine(" - http://" + ip.ToString() + ":" + activePort);
                    }
                }
            }
            catch { }

            MessageBox.Show(sb.ToString(), "Local Network (LAN) Sharing", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private static void LaunchAppWindow()
        {
            string url = "http://localhost:" + activePort + "/";
            string edgePath = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";
            if (!File.Exists(edgePath))
            {
                edgePath = @"C:\Program Files\Microsoft\Edge\Application\msedge.exe";
            }

            string chromePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            if (!File.Exists(chromePath))
            {
                chromePath = @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";
            }

            string profileDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), 
                                             "TaxCompliantBillingSuite", "profile");

            try
            {
                if (File.Exists(edgePath))
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = edgePath;
                    psi.Arguments = string.Format("--app=\"{0}\" --window-size=1366,868 --user-data-dir=\"{1}\" --disable-features=TranslateUI --disable-extensions", url, profileDir);
                    psi.UseShellExecute = false;
                    Process.Start(psi);
                }
                else if (File.Exists(chromePath))
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = chromePath;
                    psi.Arguments = string.Format("--app=\"{0}\" --window-size=1366,868 --user-data-dir=\"{1}\"", url, profileDir);
                    psi.UseShellExecute = false;
                    Process.Start(psi);
                }
                else
                {
                    LaunchBrowserWindow(url);
                }
            }
            catch
            {
                LaunchBrowserWindow(url);
            }
        }

        private static void LaunchBrowserWindow(string url)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = url;
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch { }
        }

        private static void CreateAppShortcuts()
        {
            try
            {
                string exePath = Assembly.GetExecutingAssembly().Location;
                string desktopPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Tax Compliant Billing Suite.lnk");
                
                Type shellType = Type.GetTypeFromProgID("WScript.Shell");
                if (shellType != null)
                {
                    dynamic shell = Activator.CreateInstance(shellType);
                    dynamic shortcut = shell.CreateShortcut(desktopPath);
                    shortcut.TargetPath = exePath;
                    shortcut.WorkingDirectory = Path.GetDirectoryName(exePath);
                    shortcut.Description = "Tax Compliant Billing & Invoicing Suite";
                    shortcut.Save();
                }
            }
            catch { }
        }

        private static void StopHttpServer()
        {
            isRunning = false;
            try
            {
                if (listener != null)
                {
                    listener.Stop();
                    listener.Close();
                }
            }
            catch { }
        }
    }
}
