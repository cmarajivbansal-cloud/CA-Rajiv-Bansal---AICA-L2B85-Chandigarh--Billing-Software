import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import sharp from 'sharp';
import pngToIco from 'png-to-ico';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const assetsDir = path.join(__dirname, '../assets');
if (!fs.existsSync(assetsDir)) {
  fs.mkdirSync(assetsDir, { recursive: true });
}

const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="50%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#0284c7" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fbbf24" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
    <linearGradient id="sheetGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="100%" stop-color="#f8fafc" />
    </linearGradient>
  </defs>

  <!-- Background Rounded Rect -->
  <rect width="512" height="512" rx="112" fill="url(#bgGrad)" />
  <rect width="504" height="504" x="4" y="4" rx="108" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="6" />

  <!-- Document / Invoice Card -->
  <g>
    <rect x="110" y="80" width="292" height="352" rx="24" fill="url(#sheetGrad)" />
    
    <!-- Top colored bar of document -->
    <path d="M 110 104 Q 110 80 134 80 L 378 80 Q 402 80 402 104 L 402 135 L 110 135 Z" fill="#0284c7" />
    
    <!-- Header lines -->
    <rect x="140" y="100" width="100" height="14" rx="7" fill="#ffffff" />
    <circle cx="370" cy="107" r="10" fill="#38bdf8" />

    <!-- Invoice content lines -->
    <rect x="140" y="165" width="160" height="16" rx="8" fill="#334155" />
    <rect x="140" y="195" width="90" height="12" rx="6" fill="#94a3b8" />
    
    <!-- Table Header line -->
    <rect x="140" y="230" width="232" height="6" rx="3" fill="#cbd5e1" />

    <!-- Table Rows -->
    <rect x="140" y="252" width="130" height="10" rx="5" fill="#64748b" />
    <rect x="312" y="252" width="60" height="10" rx="5" fill="#0284c7" />

    <rect x="140" y="276" width="110" height="10" rx="5" fill="#64748b" />
    <rect x="322" y="276" width="50" height="10" rx="5" fill="#0284c7" />

    <rect x="140" y="300" width="140" height="10" rx="5" fill="#64748b" />
    <rect x="307" y="300" width="65" height="10" rx="5" fill="#0284c7" />

    <!-- Divider -->
    <line x1="140" y1="326" x2="372" y2="326" stroke="#94a3b8" stroke-width="2" stroke-dasharray="4,4" />

    <!-- Total badge -->
    <rect x="140" y="345" width="232" height="42" rx="10" fill="#e0f2fe" />
    <text x="155" y="372" font-family="Arial, sans-serif" font-weight="bold" font-size="16" fill="#0369a1">TAX INVOICE SUITE</text>
  </g>

  <!-- Golden Shield / Certified Stamp Badge -->
  <g transform="translate(320, 310)">
    <circle cx="50" cy="50" r="48" fill="url(#goldGrad)" />
    <circle cx="50" cy="50" r="40" fill="#ffffff" />
    <circle cx="50" cy="50" r="36" fill="url(#goldGrad)" />
    <!-- Checkmark in badge -->
    <path d="M 36 50 L 46 60 L 66 38" fill="none" stroke="#ffffff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" />
  </g>
</svg>`;

const svgPath = path.join(assetsDir, 'icon.svg');
const pngPath = path.join(assetsDir, 'icon.png');
const icoPath = path.join(assetsDir, 'icon.ico');

fs.writeFileSync(svgPath, svgContent, 'utf-8');

async function buildIcons() {
  const sizes = [16, 32, 48, 64, 128, 256];
  const pngBuffers = [];

  for (const size of sizes) {
    const buf = await sharp(Buffer.from(svgContent))
      .resize(size, size)
      .png()
      .toBuffer();
    pngBuffers.push(buf);
  }

  // Write high-res 512x512 PNG
  await sharp(Buffer.from(svgContent))
    .resize(512, 512)
    .png()
    .toFile(pngPath);
  console.log('Saved assets/icon.png');

  // Convert to multi-resolution ICO
  const icoBuffer = await pngToIco(pngBuffers);
  fs.writeFileSync(icoPath, icoBuffer);
  console.log('Saved assets/icon.ico');
}

buildIcons().catch(console.error);
