import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function generateCompleteCodeZip() {
  console.log('Generating Complete Code Files ZIP Folder...');
  const zip = new JSZip();

  // Root directory
  const rootDir = path.resolve('.');

  // Helper to check if a file or dir should be excluded
  function shouldExclude(relPath) {
    const parts = relPath.split(path.sep);
    if (parts.includes('node_modules')) return true;
    if (parts.includes('dist')) return true;
    if (parts.includes('release')) return true;
    if (parts.includes('.git')) return true;
    if (parts.includes('.gemini')) return true;
    if (parts.includes('.DS_Store')) return true;
    if (relPath.endsWith('.zip')) return true; // Don't zip existing zips inside themselves
    return false;
  }

  // Recursive walker
  function addDirectory(dir, zipFolder) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relPath = path.relative(rootDir, fullPath);

      if (shouldExclude(relPath)) {
        continue;
      }

      if (entry.isDirectory()) {
        const subFolder = zipFolder.folder(entry.name);
        addDirectory(fullPath, subFolder);
      } else if (entry.isFile()) {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(entry.name, content);
        console.log(` Added code file: ${relPath}`);
      }
    }
  }

  // Add all codebase directories & files
  addDirectory(rootDir, zip);

  // Add a comprehensive, clear README for developers and evaluators
  zip.file(
    'README.md',
    `# Tax-Compliant Intelligent Multi-Tenant GST Billing Suite
## Capstone Project - AICA Level 2 Certificate Course
**Candidate:** CMA Rajiv Bansal (FCMA)  
**Email:** CMARAJIVBANSAL@gmail.com  
**Live Deployed App:** https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app  

---

### Overview
This repository contains the complete production-grade source code for the **Tax-Compliant Multi-Tenant GST Invoicing & Statutory Audit Suite**. It features:

1. **Master Admin & CA Authority Access:**
   - Pre-configured authority profile for **CMA Rajiv Bansal** (FCMA).
   - Multi-tenant client isolation with locked statutory variables (GSTIN, PAN, Bank IFSC, State Code).
   - Cryptographic software licensing engine (SHA-256 validation, license generator, email dispatch kit).

2. **Full-Featured Day-to-Day Invoicing:**
   - Deterministic Indian GST calculation engine (Section 7 & 8 of IGST Act: Intra-State CGST+SGST 50/50 split vs. Inter-State IGST 100%).
   - Multi-item tax builder with 0%, 5%, 12%, 18%, 28% statutory tax slabs and HSN/SAC directory.
   - Five high-resolution, printable invoice templates: Modern Navy, Classic Corporate, Clean Minimalist, Tax Compact, and Retail POS Thermal Receipt.
   - Dual signature workflow: Registered Taxpayer & Authorized Chartered / Cost Accountant.
   - Dynamic currency conversion to Indian Rupees in words (Lakhs and Crores numbering format).

3. **Statutory GSTR Reporting & Tax Audit:**
   - Automated GSTR-1 Sales Register spreadsheet synthesizer (Master Register, B2B Table 4, B2C Table 7, and HSN Summary Table 12).
   - Export to professional Excel (.xlsx) and CSV formats.

---

### How to Run Locally

\`\`\`bash
# 1. Install all dependencies
npm install

# 2. Run the Vite development server (port 3000)
npm run dev

# 3. Open in your browser
http://localhost:3000
\`\`\`

### Production Build

\`\`\`bash
npm run build
npm run preview
\`\`\`

---

### Complete Code Structure
- \`src/App.tsx\` - Main application state controller & multi-tenant routing
- \`src/components/\` - User interface components (InvoiceBuilder, InvoicePreview, AdminTaxCompliance, AdminLicenseManager, ProductCatalog, ClientMaster, SellerProfileSettings, etc.)
- \`src/components/Templates/\` - 5 professional printable GST invoice templates
- \`src/utils/\` - Business logic utilities:
  - \`taxCalculator.ts\` - Place of supply and CGST/SGST/IGST breakdown
  - \`licenseManager.ts\` - Cryptographic licensing and email notices
  - \`excelGenerator.ts\` - Automated GSTR-1 multi-tab Excel reports
  - \`numberToWords.ts\` - Indian Rupee currency to words format
  - \`storage.ts\` - Multi-tenant local storage sync and state persistence
- \`src/data/seedData.ts\` - Pre-seeded seller profiles, client profiles, and test invoices
- \`AICA_SUBMISSION/\` - Official AICA Level 2 Project Submission documents & prompts
`
  );

  console.log('\nCompiling ZIP archive...');
  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  const zipFilename1 = 'Tax_Compliant_Billing_Suite_Full_Codebase.zip';
  const zipFilename2 = 'code_files.zip';

  fs.writeFileSync(path.resolve(zipFilename1), zipBuffer);
  fs.writeFileSync(path.resolve(zipFilename2), zipBuffer);

  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }
  fs.writeFileSync(path.join(publicDir, zipFilename1), zipBuffer);
  fs.writeFileSync(path.join(publicDir, zipFilename2), zipBuffer);

  console.log(`\n✅ Complete Code Files ZIP successfully created:`);
  console.log(`   - ${zipFilename1} (${(zipBuffer.length / 1024).toFixed(2)} KB)`);
  console.log(`   - ${zipFilename2} (${(zipBuffer.length / 1024).toFixed(2)} KB)`);
}

generateCompleteCodeZip().catch(err => {
  console.error('Failed to generate Code ZIP:', err);
  process.exit(1);
});
