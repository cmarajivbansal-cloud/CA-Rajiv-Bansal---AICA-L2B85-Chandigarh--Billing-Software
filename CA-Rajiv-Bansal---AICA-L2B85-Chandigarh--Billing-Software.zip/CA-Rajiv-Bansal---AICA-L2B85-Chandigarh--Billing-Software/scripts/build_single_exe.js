import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');
const releaseDir = path.join(rootDir, 'release');
const submissionExecDir = path.join(rootDir, 'AICA_SUBMISSION/04_Executable_Files');
const csFile = path.join(__dirname, 'SingleFileLauncher.cs');
const icoFile = path.join(rootDir, 'assets/icon.ico');
const targetExe = path.join(releaseDir, 'Tax_Compliant_Billing_Suite.exe');
const subExe = path.join(submissionExecDir, 'Tax_Compliant_Billing_Suite.exe');
const tempPayloadZip = path.join(releaseDir, 'temp_app_payload.zip');

const cscPath = 'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe';

if (!fs.existsSync(distDir) || !fs.existsSync(path.join(distDir, 'index.html'))) {
  console.log('Building fresh production bundle...');
  execSync('npm run build', { cwd: rootDir, stdio: 'inherit' });
}

if (!fs.existsSync(releaseDir)) {
  fs.mkdirSync(releaseDir, { recursive: true });
}

if (!fs.existsSync(submissionExecDir)) {
  fs.mkdirSync(submissionExecDir, { recursive: true });
}

async function buildSingleExe() {
  console.log('\n📦 Step 1: Packaging dist/ files into high-compression payload...');
  const zip = new JSZip();

  function addDir(currentPath, zipFolder) {
    const files = fs.readdirSync(currentPath);
    for (const file of files) {
      const fullPath = path.join(currentPath, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDir(fullPath, zipFolder.folder(file));
      } else {
        // Skip any existing zip archives inside dist
        if (!file.endsWith('.zip')) {
          zipFolder.file(file, fs.readFileSync(fullPath));
        }
      }
    }
  }

  addDir(distDir, zip);

  const payloadBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  fs.writeFileSync(tempPayloadZip, payloadBuffer);
  console.log(`   Payload compressed size: ${(payloadBuffer.length / 1024).toFixed(2)} KB`);

  console.log('\n⚙️ Step 2: Compiling Native Standalone C# Desktop Executable with embedded icon...');
  const references = [
    'System.dll',
    'System.Windows.Forms.dll',
    'System.Drawing.dll',
    'System.IO.Compression.dll',
    'System.IO.Compression.FileSystem.dll',
    'Microsoft.CSharp.dll'
  ].map(r => `/r:"${r}"`).join(' ');

  const compileCmd = `"${cscPath}" /target:winexe /platform:x64 /optimize+ /win32icon:"${icoFile}" /resource:"${tempPayloadZip}",app_payload.zip ${references} /out:"${targetExe}" "${csFile}"`;

  execSync(compileCmd, { stdio: 'inherit' });

  // Copy to submission folder
  fs.copyFileSync(targetExe, subExe);

  // Clean up temp payload zip
  if (fs.existsSync(tempPayloadZip)) {
    fs.unlinkSync(tempPayloadZip);
  }

  const stats = fs.statSync(targetExe);
  const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
  console.log(`\n✅ Standalone Windows Desktop Executable successfully built!`);
  console.log(`   - Release Path: ${targetExe}`);
  console.log(`   - Submission Path: ${subExe}`);
  console.log(`   - Final Executable Size: ${sizeMB} MB (Target: < 25 MB, Status: OPTIMIZED 🚀)`);
}

buildSingleExe().catch(err => {
  console.error('Failed to build standalone executable:', err);
  process.exit(1);
});
