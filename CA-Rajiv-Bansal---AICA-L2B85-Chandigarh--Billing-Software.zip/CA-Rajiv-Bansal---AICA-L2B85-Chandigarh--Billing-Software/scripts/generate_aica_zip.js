import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function generateAicaZip() {
  console.log('\n📦 Generating Official AICA Level 2 Project Submission Package ZIP...');
  const zip = new JSZip();
  const baseDir = path.resolve('AICA_SUBMISSION');

  // Ensure fresh standalone executable exists in 04_Executable_Files
  const exePath = path.resolve('release/Tax_Compliant_Billing_Suite.exe');
  const subExePath = path.resolve('AICA_SUBMISSION/04_Executable_Files/Tax_Compliant_Billing_Suite.exe');
  if (fs.existsSync(exePath) && !fs.existsSync(subExePath)) {
    fs.copyFileSync(exePath, subExePath);
  }

  function addDirToZip(currentDir, relativePath = '') {
    const items = fs.readdirSync(currentDir);
    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      const itemRelative = relativePath ? `${relativePath}/${item}` : item;
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        addDirToZip(fullPath, itemRelative);
      } else {
        const content = fs.readFileSync(fullPath);
        zip.file(itemRelative, content);
        console.log(`   + Added: ${itemRelative}`);
      }
    }
  }

  // Also include the full project source code files for complete evaluatability
  const srcZipFolder = zip.folder('04_Executable_Files/Source_Code');
  
  // Include key project source files
  const keyFiles = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'index.html',
    'metadata.json',
    '.env.example',
    'Launch_App.bat',
    'README.md',
    'src/App.tsx',
    'src/types.ts',
    'src/main.tsx',
    'src/index.css',
    'src/data/seedData.ts',
    'src/utils/taxCalculator.ts',
    'src/utils/licenseManager.ts',
    'src/utils/excelGenerator.ts',
    'src/utils/numberToWords.ts',
    'src/utils/storage.ts',
    'src/components/InvoiceBuilder.tsx',
    'src/components/InvoicePreview.tsx',
    'src/components/SellerProfileSettings.tsx',
    'src/components/AdminTaxCompliance.tsx',
    'src/components/AdminLicenseManager.tsx',
    'src/components/LicenseActivationModal.tsx',
    'src/components/LoginModal.tsx',
    'src/components/Navbar.tsx',
    'src/components/ClientMaster.tsx',
    'src/components/ProductCatalog.tsx',
    'src/components/Templates/ModernNavyTemplate.tsx',
    'src/components/Templates/ClassicCorporateTemplate.tsx',
    'src/components/Templates/CleanMinimalTemplate.tsx',
    'src/components/Templates/TaxCompactTemplate.tsx',
    'src/components/Templates/RetailPosTemplate.tsx',
    'scripts/SingleFileLauncher.cs',
    'scripts/build_single_exe.js',
    'scripts/generate_portable_dist.js',
    'scripts/generate_aica_zip.js',
    'scripts/generate_code_zip.js'
  ];

  for (const relFile of keyFiles) {
    if (fs.existsSync(relFile)) {
      srcZipFolder.file(relFile, fs.readFileSync(relFile));
    }
  }

  addDirToZip(baseDir);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  const outputZipPath = path.resolve('AICA_Level_2_Project_CMA_Rajiv_Bansal.zip');
  fs.writeFileSync(outputZipPath, zipBuffer);

  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }
  fs.writeFileSync(path.join(publicDir, 'AICA_Level_2_Project_CMA_Rajiv_Bansal.zip'), zipBuffer);

  const distDir = path.resolve('dist');
  if (fs.existsSync(distDir)) {
    fs.writeFileSync(path.join(distDir, 'AICA_Level_2_Project_CMA_Rajiv_Bansal.zip'), zipBuffer);
  }

  const sizeMB = (zipBuffer.length / (1024 * 1024)).toFixed(2);
  const sizeKB = (zipBuffer.length / 1024).toFixed(2);

  console.log(`\n✅ AICA Level 2 Project Submission Package successfully created:`);
  console.log(`   - Archive File: ${outputZipPath}`);
  console.log(`   - Final ZIP Size: ${sizeMB} MB (${sizeKB} KB) (Target: < 25 MB, Status: OPTIMIZED 🚀)`);
}

generateAicaZip().catch(err => {
  console.error('Failed to generate AICA ZIP:', err);
  process.exit(1);
});
