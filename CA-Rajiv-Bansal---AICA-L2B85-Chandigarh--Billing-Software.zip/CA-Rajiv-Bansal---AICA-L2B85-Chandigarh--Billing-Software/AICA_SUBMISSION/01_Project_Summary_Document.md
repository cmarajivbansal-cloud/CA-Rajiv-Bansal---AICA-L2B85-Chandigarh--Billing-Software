# AICA Level 2 Certificate Course: Project Summary Document
**Artificial Intelligence in Cost & Management Accounting (AICA)**

---

### Project & Candidate Identification
- **Candidate Name:** CMA Rajiv Bansal
- **Designation & Professional Credentials:** Cost and Management Accountant (FCMA) / Statutory Tax Auditor
- **Candidate Email:** CMARAJIVBANSAL@gmail.com
- **Course Name:** AICA Level 2 Certificate Course
- **Submission Date:** September 2026
- **Project Title:** Tax-Compliant Intelligent Multi-Tenant GST Billing Suite with Master Admin Licensing & Automated Statutory GSTR Audit Registers
- **Live Cloud Application URL:** https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app

---

## 1. Executive Summary

Small and medium-sized business enterprises (SMEs) across India face persistent compliance challenges when issuing GST invoices, maintaining immutable seller records, classifying HSN/SAC codes, determining place of supply (Intra-State CGST+SGST vs. Inter-State IGST), and transmitting period-end sales registers to practicing Cost and Management Accountants (CMAs) for GSTR-1 and GSTR-3B filings.

This project delivers a **production-ready, multi-tenant statutory GST billing and audit platform** tailored for practicing CMAs and their small business clients. The application features:
1. **Multi-Tenant Client Workspaces**: Dedicated business profiles for clients with immutable, locked statutory firm variables (GSTIN, Legal Entity Name, Principal Place of Business, Bank Remittance, and UPI details).
2. **Dynamic Format & Logo Customizer**: Configurable billing templates (Modern Navy, Classic Corporate, Clean Minimal, Tax Statutory Compact, and Retail POS), document title selection, and custom business logo uploading with real-time print height controls.
3. **Master Admin & Licensing Authority**: Exclusive master dashboard for **CMA Rajiv Bansal** to issue cryptographic, tamper-evident license keys with validity limits, accompanied by an automated email activation notice generator.
4. **Automated Excel Audit Engine**: Client-isolated and consolidated multi-sheet Excel workbooks (`.xlsx`) generated on the fly, formatting data strictly according to statutory GSTR-1 B2B/B2C tables, HSN summaries, and tax liability computations.

---

## 2. Problem Statement & Professional Relevance

### The Problem
- **Data Entry Errors:** SME shopkeepers and business managers frequently miscalculate tax splits between CGST, SGST, and IGST, enter invalid state codes, or distort statutory details.
- **Auditor Bottlenecks:** At the end of every fiscal month or quarter, CMAs spend countless hours manually converting disparate PDF and paper invoices into Excel spreadsheets for GST portal upload.
- **Uncontrolled Software Piracy:** Practicing professionals lack simple, local licensing controls to provision accounting tools to designated clients with expiration dates and verification keys.

### The Solution Developed
An AI-augmented web platform designed with high usability for both mobile and desktop devices. Clients generate compliant invoices in seconds with locked firm profiles, while CMA Rajiv Bansal retains master administrative control, instant sales register downloads, and cryptographic license oversight.

---

## 3. System Architecture & Technical Stack

- **Frontend Architecture:** React 19, TypeScript, Tailwind CSS with responsive layout and print CSS media queries (`@media print`) for standardized A4 invoice rendering.
- **Tax Calculation Engine:** Deterministic rule-based engine implementing Section 7 & 8 of the Indian IGST Act, 2017:
  - If `Supplier_State_Code === Buyer_State_Code` → Intra-State Supply (CGST 50% + SGST 50%)
  - If `Supplier_State_Code !== Buyer_State_Code` → Inter-State Supply (IGST 100%)
  - Multi-tier GST slabs: 0%, 5%, 12%, 18%, 28%, with item-level and invoice-level discount calculation.
- **Licensing Subsystem:** SHA-based cryptographic hash generator creating formatted keys (`AICA-XXXX-XXXX-XXXX-XXXX`) linked to Client ID, Tier, and Expiration Epoch, preventing unauthorized tampering.
- **Data Export & GSTR Engine:** Client-side binary spreadsheet synthesis via SheetJS (`xlsx`) constructing multi-sheet workbooks with statutory column headers conforming to GST Portal offline tool requirements.

---

## 4. Key Functional Modules

| Module Name | Target Persona | Functional Capability |
| :--- | :--- | :--- |
| **Invoice Builder** | Small Business Operator | Real-time tax computation, HSN search, itemized discounts, reverse charge toggle, dynamic line additions. |
| **Format & Logo Settings** | Small Business Operator | Local file uploader for company logo, print height slider, 5 template styles, document title selector. |
| **Fixed Firm Lock** | Statutory Compliance | Permanent storage of seller profile (GSTIN, PAN, Address, Bank/UPI) to eliminate invoice inconsistencies. |
| **Invoice Viewer & Print** | Client / Customer | Pixel-perfect A4 printable invoices, WhatsApp & Email quick-sharing, JSON data export. |
| **Admin Tax Compliance** | CMA Rajiv Bansal | Multi-client sales registers, period-based GSTR-1 summaries, monthly tax liability reports, raw Excel downloads. |
| **Master License Manager** | CMA Rajiv Bansal | Generation of cryptographic license keys, tier configuration, validity tracking, and automated email dispatch. |
| **License Activation** | Client Workspace | In-app activation modal validating license authenticity and unlocking full invoicing features. |

---

## 5. Verification & Testing

1. **Tax Split Accuracy:** Validated across all 37 Indian State & UT codes against inter-state and intra-state transactions.
2. **Excel Schema Conformance:** Verified workbook outputs against the standard GST Offline Utility template for GSTR-1 Table 4 (B2B), Table 5 (B2C Large), Table 7 (B2C Small), and Table 12 (HSN Summary).
3. **Cross-Platform Responsiveness:** Tested on mobile screen viewports (375px), tablet (768px), and desktop (1440px).
4. **Print Media Fidelity:** Verified that headers, borders, authorized signatory boxes, and terms are preserved without page breaks or clipped elements.

---

## 6. Conclusion

This project satisfies all requirements for the **AICA Level 2 Certificate Course**, demonstrating practical integration of algorithmic software design, prompt engineering methodology, statutory tax compliance rules, and professional cost accounting workflows.

**Submitted by:**
CMA Rajiv Bansal
Cost & Management Accountant
CMARAJIVBANSAL@gmail.com
