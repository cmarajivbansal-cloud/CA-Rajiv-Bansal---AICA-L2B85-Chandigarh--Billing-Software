@echo off
title Launch Tax Compliant Billing & Invoicing Suite
echo ============================================================
echo   AICA Level 2 Project - CMA Rajiv Bansal (FCMA)
echo   Launching Tax-Compliant GST Billing ^& Audit Suite
echo ============================================================
echo.

if exist "%~dp0Tax_Compliant_Billing_Suite.exe" (
    echo Launching Native Offline Standalone Desktop Application...
    start "" "%~dp0Tax_Compliant_Billing_Suite.exe"
    exit /b 0
)

if exist "%~dp0..\..\release\Tax_Compliant_Billing_Suite.exe" (
    echo Launching Native Offline Standalone Desktop Application...
    start "" "%~dp0..\..\release\Tax_Compliant_Billing_Suite.exe"
    exit /b 0
)

echo No standalone executable found, starting from source code...
call npm install
call npm run dev
pause
