# AICA Level 2 Project: Executable Application Guide
**Candidate:** CMA Rajiv Bansal (FCMA)  
**Email:** CMARAJIVBANSAL@gmail.com  
**Course:** AICA Level 2 Certificate Course  

---

## 1. Instant Desktop Execution (No Setup Required)
For Windows users, the package contains an **ultra-optimized, standalone native executable** (`Tax_Compliant_Billing_Suite.exe`, ~0.6 MB):

1. Double-click `Tax_Compliant_Billing_Suite.exe` (or `run_app.bat`).
2. The application opens instantly in dedicated desktop window mode.
3. Works **100% offline** without installing Node.js or any runtime dependencies.

---

## 2. Cloud-Hosted Live Deployment (Instant Web Evaluation)
You can directly access and test the deployed cloud application in any web browser without local setup:

- **Live Production URL:** https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app
- **Development App URL:** https://ais-dev-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app
- **Master Admin User:** `admin` (CMA Rajiv Bansal - CMARAJIVBANSAL@gmail.com)
- **Pre-Configured Client Accounts:** `sharma_ent` (Sharma Enterprises), `gupta_trade` (Gupta Trading)

---

## 3. Local Machine Source Code Execution

### Prerequisites
- Node.js version 18.0 or higher
- npm (Node Package Manager)

### Step 1: Install Base Dependencies
Open terminal / command prompt in the project root directory and execute:
```bash
npm install
```

### Step 2: Run Development Server
To start the local live server on port 3000:
```bash
npm run dev
```
Open your browser and navigate to: `http://localhost:3000`

### Step 3: Build for Production & Standalone Executable
```bash
npm run build
npm run build:standalone
```

---

## 4. Quick Run Scripts
- On **Windows**: Double-click `run_app.bat` or `Tax_Compliant_Billing_Suite.exe`
- On **Linux / macOS**: Execute `./run_app.sh`
