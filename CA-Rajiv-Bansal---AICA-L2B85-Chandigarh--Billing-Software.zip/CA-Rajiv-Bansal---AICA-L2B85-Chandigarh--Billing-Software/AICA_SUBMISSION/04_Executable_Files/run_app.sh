#!/usr/bin/env bash
echo "============================================================"
echo "AICA Level 2 Project - CMA Rajiv Bansal"
echo "Launching Tax-Compliant GST Billing & Audit Suite"
echo "============================================================"
npm install
npm run dev
