# AICA Level 2: Cryptographic Licensing & Dispatch Prompts
## File 3: Master Admin License Engine & Client Provisioning

### Prompt 3.1: Cryptographic License Key Generation Prompt
```text
System Requirement: As Master Admin (CMA Rajiv Bansal), create a cryptographic license generator for provisioning the invoice billing software to verified client firms.

Key Architecture:
1. Input: Client User ID (e.g. 'sharma_ent'), License Tier ('pro' | 'enterprise' | 'basic'), Expiration Date, Issued By ('CMARAJIVBANSAL@gmail.com').
2. Hash Algorithm: Generate a deterministic 16-hex digit signature using polynomial hashing and client salt to prevent forged license keys.
3. Formatted Key Pattern: 'AICA-XXXX-XXXX-XXXX-XXXX'
4. Validation Method: When a client enters a license key, the validator must inspect:
   - Key syntax and checksum validity
   - Expiration timestamp against current system date
   - Status (active vs revoked)
5. Upon activation, store the verified license securely in localStorage, unlock full invoicing features, and show an official 'Licensed' security seal.
```

### Prompt 3.2: Automated Email Dispatch Kit Prompt
```text
Generate an automated client email dispatch notice:
- Sender: CMA Rajiv Bansal <CMARAJIVBANSAL@gmail.com>
- Recipient: Client business email address
- Subject: Official AICA License Key & Activation Kit - [Business Name]
- Body: Contain License Key, Tier, Expiration Date, Step-by-Step Activation Instructions, Support Contact, and statutory advisory notes.
- Include one-click copy and mailto launch action so the CMA can send credentials directly via any email client.
```
