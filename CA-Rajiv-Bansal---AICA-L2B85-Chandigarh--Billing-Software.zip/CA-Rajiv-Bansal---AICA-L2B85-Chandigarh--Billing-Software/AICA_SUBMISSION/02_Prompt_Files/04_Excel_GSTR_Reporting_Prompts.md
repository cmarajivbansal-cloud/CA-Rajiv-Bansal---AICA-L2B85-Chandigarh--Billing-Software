# AICA Level 2: Statutory Excel Reporting Prompts
## File 4: Automated GSTR-1 Sales Register & Audit Workbook Synthesis

### Prompt 4.1: Multi-Sheet Government Format Excel Generator
```text
Write a client-side Excel (.xlsx) workbook generator using SheetJS (xlsx):
Target Audience: Statutory GST Auditors and Cost & Management Accountants filing GSTR-1 & GSTR-3B.

Workbook Specifications:
Sheet 1: 'Master Sales Register'
- Columns: Invoice Number, Invoice Date, Customer Name, Customer GSTIN, Place of Supply State, Taxable Value, CGST Amount, SGST Amount, IGST Amount, Total Invoice Value, Payment Status.
- Summary Row: Subtotals for Taxable Value, CGST, SGST, IGST, and Total Turnover.

Sheet 2: 'GSTR-1 B2B Supplies (Table 4)'
- Filter: Invoices where Buyer GSTIN is present and valid (15 chars).
- Columns: GSTIN/UIN of Recipient, Receiver Name, Invoice Number, Invoice Date, Invoice Value, Place of Supply, Reverse Charge, Applicable % of Tax Rate, Taxable Value, Cess Amount.

Sheet 3: 'GSTR-1 B2C Small Supplies (Table 7)'
- Filter: Invoices where Buyer GSTIN is absent or unregistered.
- Aggregated by Place of Supply State and Tax Rate.

Sheet 4: 'HSN Summary (Table 12)'
- Group invoices by HSN/SAC Code and Description.
- Columns: HSN/SAC Code, Description, UQC (Unit Quantity Code), Total Quantity, Total Value, Taxable Value, Integrated Tax Amount, Central Tax Amount, State/UT Tax Amount, Cess.

File Naming: 'GSTR1_Sales_Register_[ClientName]_[Period].xlsx'
```
