# AICA Level 2: GST Calculation Engine Prompts
## File 2: Deterministic Tax Rules & Place of Supply Engineering

### Prompt 2.1: Statutory Place of Supply & Tax Split Logic
```text
Implement an algorithmic Indian GST calculation engine conforming strictly to:
- Section 7 of the IGST Act (Inter-State Supplies)
- Section 8 of the IGST Act (Intra-State Supplies)

Input Parameters:
- sellerStateCode: 2-digit numeric string (e.g., '07' for Delhi)
- buyerStateCode: 2-digit numeric string (e.g., '07' for Delhi or '27' for Maharashtra)
- lineItems: Array of { quantity, unitPrice, discountPercent, gstRatePercent, cessPercent }

Computation Rules:
1. Item Taxable Value = (quantity * unitPrice) * (1 - discountPercent / 100)
2. If sellerStateCode === buyerStateCode (Intra-State):
   - CGST Rate = gstRatePercent / 2
   - SGST Rate = gstRatePercent / 2
   - IGST Rate = 0%
   - CGST Amount = Item Taxable Value * (CGST Rate / 100)
   - SGST Amount = Item Taxable Value * (SGST Rate / 100)
   - IGST Amount = 0
3. If sellerStateCode !== buyerStateCode (Inter-State):
   - CGST Rate = 0%
   - SGST Rate = 0%
   - IGST Rate = gstRatePercent
   - CGST Amount = 0
   - SGST Amount = 0
   - IGST Amount = Item Taxable Value * (IGST Rate / 100)
4. Invoice Total = Sum(Item Taxable Values) + Sum(CGST) + Sum(SGST) + Sum(IGST) + Sum(Cess)
5. Generate both numerical total and standard Indian numbering currency words (Lakhs and Crores) for legal validity.
```

### Prompt 2.2: Reverse Charge Mechanism (RCM) Prompt
```text
Incorporate Section 9(3) / 9(4) Reverse Charge Mechanism flags:
- If isReverseCharge === true, tax amounts must be tracked as recipient liability in tax registers without inflating the payable amount due from the customer on the tax invoice face.
- Add mandatory statutory declaration on invoice footer: "Tax payable under Reverse Charge: YES".
```
