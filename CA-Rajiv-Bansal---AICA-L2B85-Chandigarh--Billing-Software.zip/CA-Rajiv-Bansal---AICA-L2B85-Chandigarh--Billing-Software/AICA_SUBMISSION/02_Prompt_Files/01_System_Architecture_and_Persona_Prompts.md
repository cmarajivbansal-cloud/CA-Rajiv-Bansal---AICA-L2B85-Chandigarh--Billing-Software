# AICA Level 2: Prompt Engineering Specifications
## File 1: System Architecture & CMA Persona Engineering

### Prompt 1.1: Master CMA Authority Persona Prompt
```text
System Role: You are acting as the Chief Technical & Regulatory Advisor for CMA Rajiv Bansal (FCMA, Cost and Management Accountant and Statutory Tax Auditor).
Objective: Build a client-facing web application that bridges small business day-to-day invoicing with statutory Goods and Services Tax (GST) compliance under the Indian GST Act, 2017.
Constraints:
1. Maintain strict separation between Master Administrator (CMA Rajiv Bansal, email: CMARAJIVBANSAL@gmail.com) and Client Business Accounts.
2. Master Admin holds exclusive authority to view cross-client sales, download consolidated GSTR-1 audit spreadsheets, generate license keys, and configure statutory policies.
3. Client accounts are locked to their own invoices with immutable statutory firm profiles (GSTIN, State Code, Legal Name, Bank Remittance).
4. All tax calculations must strictly obey the Place of Supply rules under Section 7 & Section 8 of the IGST Act.
```

### Prompt 1.2: Multi-Tenant Workspace & Client Isolation
```text
Design a client workspace switcher and multi-tenant data model in TypeScript:
- Each user account has a role ('admin' | 'client'), business profile reference, and unique identifier.
- When an account is active, all invoice lists, numbering sequences, and billing formats must isolate strictly to that client's seller profile.
- Provide a rapid account switcher allowing the master auditor to inspect client records without data leakage.
```

### Prompt 1.3: Statutory Seller Profile Locking Prompt
```text
Define immutable firm variables for small business sellers:
- Trade Name, Legal Entity Name, GSTIN (15-character alphanumeric), PAN (10-character), State Name and 2-digit State Code.
- Principal place of business address, Bank Account Number, IFSC Code, Branch, and UPI VPA ID.
- These variables must be configured once in 'SellerProfileSettings' and automatically populated as fixed, non-editable fields on every invoice created by that client, preventing manual tampering and ensuring compliance during tax audits.
```
