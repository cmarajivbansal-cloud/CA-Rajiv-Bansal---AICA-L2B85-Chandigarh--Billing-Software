# AICA Level 2: Licensing Security & Audit Specification

## 1. Statutory Objectives
For practicing Cost and Management Accountants (CMAs) provisioning proprietary software systems to client firms, license enforcement prevents:
1. Unauthorized multi-branch replication without statutory audit oversight.
2. Inadvertent usage beyond the retainer audit agreement period.
3. Tampering with firm variables or GST tax engines.

## 2. Cryptographic Licensing Specification
- **Prefix:** `AICA`
- **Block Structure:** 4 hexadecimal groups separated by hyphens (`AICA-XXXX-XXXX-XXXX-XXXX`).
- **Signature Payload:** Contains truncated SHA digest of Client ID, Salt (`AICA_STATUTORY_AUDIT_2026`), Expiration Epoch, and Master Issuer Key (`CMARAJIVBANSAL@gmail.com`).
- **Offline Verifiability:** The client billing workspace can independently recalculate and verify the signature without requiring active cloud connection, making it suitable for industrial factory sites or low-bandwidth retail locations.

## 3. Statutory Audit Trail
- Each invoice generated stores:
  - Timestamp of issuance
  - Seller profile snapshot at time of billing
  - Invoice state hash
- This prevents post-audit tampering and facilitates statutory GST audit under the Cost and Management Accountants Act.
