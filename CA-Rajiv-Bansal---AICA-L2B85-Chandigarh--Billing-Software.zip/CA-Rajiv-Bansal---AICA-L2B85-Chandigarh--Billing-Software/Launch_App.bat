@echo off
title Tax Compliant Billing & Invoicing Suite
echo ========================================================================
echo   TAX COMPLIANT BILLING & INVOICING SUITE (AICA LEVEL 2 CAPSTONE)
echo   Author: CMA Rajiv Bansal (FCMA) ^| Email: CMARAJIVBANSAL@gmail.com
echo ========================================================================
echo.

if exist "%~dp0release\Tax_Compliant_Billing_Suite.exe" (
    echo Launching Native Offline Standalone Desktop Application...
    start "" "%~dp0release\Tax_Compliant_Billing_Suite.exe"
    exit /b 0
)

if exist "%~dp0AICA_SUBMISSION\04_Executable_Files\Tax_Compliant_Billing_Suite.exe" (
    echo Launching Native Offline Standalone Desktop Application...
    start "" "%~dp0AICA_SUBMISSION\04_Executable_Files\Tax_Compliant_Billing_Suite.exe"
    exit /b 0
)

echo Starting Local Development Server on port 3000...
npm run dev
