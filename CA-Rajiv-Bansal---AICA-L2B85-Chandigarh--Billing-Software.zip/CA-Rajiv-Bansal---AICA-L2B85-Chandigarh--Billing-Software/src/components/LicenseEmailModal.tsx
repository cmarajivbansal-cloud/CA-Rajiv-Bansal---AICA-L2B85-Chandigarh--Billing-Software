import React, { useState } from 'react';
import { ClientLicense, SellerProfile } from '../types';
import { LicenseManager } from '../utils/licenseManager';
import { Mail, Copy, Check, ExternalLink, ShieldCheck, Send, Key } from 'lucide-react';

interface LicenseEmailModalProps {
  isOpen: boolean;
  license: ClientLicense | null;
  seller?: SellerProfile;
  onClose: () => void;
  onSuccessDispatch?: () => void;
}

export const LicenseEmailModal: React.FC<LicenseEmailModalProps> = ({
  isOpen,
  license,
  seller,
  onClose,
  onSuccessDispatch
}) => {
  const [copied, setCopied] = useState(false);
  const [keyCopied, setKeyCopied] = useState(false);
  const [isSentMarked, setIsSentMarked] = useState(false);

  if (!isOpen || !license) return null;

  const emailDraft = LicenseManager.prepareEmailDraft(license, seller);

  const handleCopyBody = () => {
    navigator.clipboard.writeText(emailDraft.body);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleCopyKeyOnly = () => {
    navigator.clipboard.writeText(license.licenseKey);
    setKeyCopied(true);
    setTimeout(() => setKeyCopied(false), 2500);
  };

  const handleLaunchEmailClient = () => {
    LicenseManager.recordEmailSent(license.id);
    setIsSentMarked(true);
    if (onSuccessDispatch) onSuccessDispatch();
    window.location.href = emailDraft.mailtoUrl;
  };

  const handleMarkAsSent = () => {
    LicenseManager.recordEmailSent(license.id);
    setIsSentMarked(true);
    if (onSuccessDispatch) onSuccessDispatch();
    setTimeout(() => {
      onClose();
      setIsSentMarked(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500 text-slate-900 rounded-xl font-bold">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">Email Client License Key</h2>
                <span className="text-[10px] font-mono font-bold uppercase bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                  CMA Master Admin
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Dispatch official license certificate to <strong className="text-slate-200">{license.businessName}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs">
          {/* Key Highlight Banner */}
          <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Generated License Key</span>
              <div className="text-base font-mono font-black text-indigo-700 mt-0.5 select-all">
                {license.licenseKey}
              </div>
              <span className="text-[11px] text-slate-500">
                Tier: <strong className="text-slate-700 capitalize">{license.tier}</strong> | Valid until: <strong className="text-slate-700">{license.validUntil}</strong>
              </span>
            </div>

            <button
              onClick={handleCopyKeyOnly}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-all cursor-pointer shrink-0"
            >
              {keyCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Key className="w-3.5 h-3.5 text-slate-600" />}
              {keyCopied ? 'Key Copied!' : 'Copy Key Only'}
            </button>
          </div>

          {/* Email Preview Fields */}
          <div className="space-y-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Recipient Email (Client Contact):</label>
              <input
                type="email"
                readOnly
                value={emailDraft.recipient}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-800 font-medium select-all"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Subject Line:</label>
              <input
                type="text"
                readOnly
                value={emailDraft.subject}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 font-medium select-all"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">Official License Letter Body:</label>
                <button
                  onClick={handleCopyBody}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Full Letter Copied!' : 'Copy Entire Email Body'}
                </button>
              </div>
              <textarea
                rows={10}
                readOnly
                value={emailDraft.body}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 font-mono text-[11px] leading-relaxed text-slate-800 select-all"
              />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500">
            {license.lastEmailSentAt ? (
              <span>Last dispatched: <strong className="text-slate-700">{license.lastEmailSentAt}</strong></span>
            ) : (
              <span>Ready for initial email dispatch by CMA Rajiv Bansal</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyBody}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              Copy Letter
            </button>

            <button
              onClick={handleMarkAsSent}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-all cursor-pointer"
            >
              <Check className="w-3.5 h-3.5 text-emerald-700" />
              {isSentMarked ? 'Logged as Sent!' : 'Mark as Sent'}
            </button>

            <button
              onClick={handleLaunchEmailClient}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-200 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              Open in Email App
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
