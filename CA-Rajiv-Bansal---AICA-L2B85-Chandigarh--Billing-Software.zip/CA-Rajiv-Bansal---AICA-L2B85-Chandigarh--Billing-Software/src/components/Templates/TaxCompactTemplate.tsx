import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency } from '../../utils/numberToWords';

export const TaxCompactTemplate: React.FC<{ invoice: Invoice }> = ({ invoice }) => {
  const { seller, buyer, items } = invoice;

  return (
    <div id="printable-invoice" className="bg-white p-5 rounded shadow-sm max-w-4xl mx-auto text-slate-900 text-[11px] font-sans border-2 border-slate-800 print:p-0 print:shadow-none print:max-w-none print:border-none">
      {/* Title */}
      <div className="text-center border-b-2 border-slate-800 pb-2">
        <h2 className="text-base font-extrabold uppercase tracking-wide">GST TAX INVOICE</h2>
        <p className="text-[10px] text-slate-600 font-semibold">(Issued under Section 31 of CGST Act, 2017 read with Rule 46 of CGST Rules)</p>
      </div>

      {/* Top 3-Box Header: Seller / Buyer / Invoice Details */}
      <div className="grid grid-cols-3 divide-x-2 divide-slate-800 border-b-2 border-slate-800">
        {/* Box 1: Seller */}
        <div className="p-2 space-y-0.5">
          <p className="font-extrabold text-xs text-slate-950 uppercase">{seller.businessName}</p>
          <p className="text-slate-700">{seller.addressLine1}</p>
          <p className="text-slate-700">{seller.city}, {seller.state} - {seller.pincode}</p>
          <p className="font-bold pt-1">GSTIN: <span className="font-mono">{seller.gstin}</span></p>
          <p>PAN: <span className="font-mono font-medium">{seller.pan}</span></p>
          <p>State: {seller.state} (Code: {seller.stateCode})</p>
        </div>

        {/* Box 2: Buyer */}
        <div className="p-2 space-y-0.5 bg-slate-50/50">
          <p className="font-bold uppercase text-[10px] text-slate-500">Details of Buyer | Billed To:</p>
          <p className="font-bold text-xs text-slate-950">{buyer.companyName || buyer.name}</p>
          <p className="text-slate-700">{buyer.billingAddress.addressLine1}</p>
          <p className="text-slate-700">{buyer.billingAddress.city}, {buyer.billingAddress.state} - {buyer.billingAddress.pincode}</p>
          <p className="font-bold pt-1">GSTIN: <span className="font-mono">{buyer.gstin || 'Unregistered'}</span></p>
          <p>State: {buyer.billingAddress.state} (Code: {buyer.billingAddress.stateCode || '--'})</p>
        </div>

        {/* Box 3: Invoice Info */}
        <div className="p-2 space-y-0.5">
          <div className="flex justify-between">
            <span className="font-semibold text-slate-600">Invoice No:</span>
            <span className="font-mono font-bold">{invoice.invoiceNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold text-slate-600">Invoice Date:</span>
            <span className="font-mono">{invoice.invoiceDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold text-slate-600">Due Date:</span>
            <span className="font-mono">{invoice.dueDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold text-slate-600">Place of Supply:</span>
            <span>{buyer.placeOfSupply || buyer.billingAddress.state}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold text-slate-600">Reverse Charge:</span>
            <span className="font-mono font-bold">No</span>
          </div>
        </div>
      </div>

      {/* Full Statutory Items Table */}
      <table className="w-full text-left border-collapse border-b-2 border-slate-800">
        <thead>
          <tr className="bg-slate-100 text-slate-900 font-bold border-b border-slate-800 text-[10px]">
            <th className="p-1.5 border-r border-slate-800 text-center w-6">#</th>
            <th className="p-1.5 border-r border-slate-800">Description of Goods / Services</th>
            <th className="p-1.5 border-r border-slate-800 text-center w-14">HSN/SAC</th>
            <th className="p-1.5 border-r border-slate-800 text-center w-10">Qty</th>
            <th className="p-1.5 border-r border-slate-800 text-center w-10">Unit</th>
            <th className="p-1.5 border-r border-slate-800 text-right w-16">Rate (₹)</th>
            <th className="p-1.5 border-r border-slate-800 text-right w-16">Taxable (₹)</th>
            {invoice.isInterState ? (
              <th className="p-1.5 border-r border-slate-800 text-right w-16">IGST (₹)</th>
            ) : (
              <>
                <th className="p-1.5 border-r border-slate-800 text-right w-14">CGST (₹)</th>
                <th className="p-1.5 border-r border-slate-800 text-right w-14">SGST (₹)</th>
              </>
            )}
            <th className="p-1.5 text-right w-20">Total (₹)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-300">
          {items.map((item, idx) => (
            <tr key={idx} className="text-slate-800">
              <td className="p-1.5 border-r border-slate-300 text-center">{idx + 1}</td>
              <td className="p-1.5 border-r border-slate-300 font-medium">{item.description}</td>
              <td className="p-1.5 border-r border-slate-300 text-center font-mono">{item.hsnSacCode}</td>
              <td className="p-1.5 border-r border-slate-300 text-center font-mono">{item.quantity}</td>
              <td className="p-1.5 border-r border-slate-300 text-center">{item.unit}</td>
              <td className="p-1.5 border-r border-slate-300 text-right font-mono">{formatCurrency(item.unitPrice, '').trim()}</td>
              <td className="p-1.5 border-r border-slate-300 text-right font-mono">{formatCurrency(item.taxableAmount, '').trim()}</td>
              {invoice.isInterState ? (
                <td className="p-1.5 border-r border-slate-300 text-right font-mono">
                  <span className="text-[9px] text-slate-500 block">{item.igstRate}%</span>
                  {formatCurrency(item.igstAmount, '').trim()}
                </td>
              ) : (
                <>
                  <td className="p-1.5 border-r border-slate-300 text-right font-mono">
                    <span className="text-[9px] text-slate-500 block">{item.cgstRate}%</span>
                    {formatCurrency(item.cgstAmount, '').trim()}
                  </td>
                  <td className="p-1.5 border-r border-slate-300 text-right font-mono">
                    <span className="text-[9px] text-slate-500 block">{item.sgstRate}%</span>
                    {formatCurrency(item.sgstAmount, '').trim()}
                  </td>
                </>
              )}
              <td className="p-1.5 text-right font-mono font-bold">{formatCurrency(item.totalAmount, '').trim()}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Bottom Summary Grid */}
      <div className="grid grid-cols-2 divide-x-2 divide-slate-800">
        {/* Left: Words, Bank Details, Declaration */}
        <div className="p-2.5 space-y-2">
          <div>
            <span className="font-bold text-[10px] text-slate-600 block uppercase">Invoice Value in Words:</span>
            <p className="font-bold text-slate-950 italic">{invoice.amountInWords}</p>
          </div>

          <div className="pt-2 border-t border-slate-200">
            <span className="font-bold text-[10px] text-slate-600 block uppercase">Bank & Remittance Details:</span>
            <div className="grid grid-cols-2 gap-x-2 text-[10px] text-slate-800">
              <p>Bank: <span className="font-semibold">{seller.bankDetails.bankName}</span></p>
              <p>A/c No: <span className="font-mono font-bold">{seller.bankDetails.accountNumber}</span></p>
              <p>IFSC: <span className="font-mono font-bold">{seller.bankDetails.ifscCode}</span></p>
              <p>Branch: {seller.bankDetails.branch}</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 text-[9px] text-slate-500">
            <p className="font-bold text-slate-700">Declaration:</p>
            <p>We declare that this invoice shows the actual price of the goods/services described and that all particulars are true and correct.</p>
          </div>
        </div>

        {/* Right: Calculations & Stamp */}
        <div className="p-2.5 space-y-1 font-mono">
          <div className="flex justify-between text-slate-700">
            <span>Total Taxable Amount:</span>
            <span>{formatCurrency(invoice.totalTaxableAmount, seller.currencySymbol)}</span>
          </div>
          {invoice.isInterState ? (
            <div className="flex justify-between text-slate-700">
              <span>Integrated Tax (IGST):</span>
              <span>{formatCurrency(invoice.igstTotal, seller.currencySymbol)}</span>
            </div>
          ) : (
            <>
              <div className="flex justify-between text-slate-700">
                <span>Central Tax (CGST):</span>
                <span>{formatCurrency(invoice.cgstTotal, seller.currencySymbol)}</span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>State Tax (SGST):</span>
                <span>{formatCurrency(invoice.sgstTotal, seller.currencySymbol)}</span>
              </div>
            </>
          )}
          {invoice.roundOff !== 0 && (
            <div className="flex justify-between text-slate-500">
              <span>Round Off:</span>
              <span>{invoice.roundOff}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-xs text-slate-950 border-t-2 border-slate-800 pt-1.5">
            <span className="font-sans">TOTAL INVOICE VALUE:</span>
            <span>{formatCurrency(invoice.grandTotal, seller.currencySymbol)}</span>
          </div>

          <div className="pt-8 text-right font-sans">
            <p className="font-bold text-[10px] text-slate-900">For {seller.businessName}</p>
            <div className="h-6"></div>
            <p className="font-bold text-xs">{seller.signatoryName}</p>
            <p className="text-[10px] text-slate-500">{seller.signatoryDesignation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
