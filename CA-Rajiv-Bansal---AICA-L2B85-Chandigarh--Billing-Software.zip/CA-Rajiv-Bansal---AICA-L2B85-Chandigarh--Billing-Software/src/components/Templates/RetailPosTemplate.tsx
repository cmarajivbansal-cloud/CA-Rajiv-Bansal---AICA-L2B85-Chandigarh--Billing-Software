import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency } from '../../utils/numberToWords';

export const RetailPosTemplate: React.FC<{ invoice: Invoice }> = ({ invoice }) => {
  const { seller, buyer, items } = invoice;
  const format = invoice.billingFormat || seller.billingFormat;
  const docTitle = format?.documentTitle || 'RETAIL INVOICE / CASH MEMO';
  const showLogo = format?.showLogo !== false && !!seller.logoUrl;
  const showHsn = format?.showHsnSac !== false;
  const showDiscount = format?.showDiscount !== false && invoice.totalDiscount > 0;
  const showBank = format?.showBankDetails !== false;
  const showSignatory = format?.showSignatoryBox !== false;
  const showTerms = format?.showTerms !== false && !!invoice.termsAndConditions;
  const showNotes = format?.showNotes !== false && !!invoice.notes;

  return (
    <div
      id="printable-invoice"
      className="bg-white p-6 sm:p-7 rounded-lg shadow-sm max-w-2xl mx-auto text-slate-900 text-xs border border-slate-300 font-sans print:p-0 print:shadow-none print:border-none print:max-w-none"
    >
      {/* Retail Header */}
      <div className="text-center pb-3 border-b-2 border-slate-900">
        {showLogo && (
          <div className="flex justify-center mb-2">
            <img
              src={seller.logoUrl}
              alt="Logo"
              style={{ maxHeight: `${format?.logoHeight || 52}px` }}
              className="object-contain"
            />
          </div>
        )}
        <h1 className="text-xl font-black tracking-tight uppercase text-slate-900">{seller.businessName}</h1>
        {seller.tagline && <p className="text-[11px] text-slate-600 font-medium">{seller.tagline}</p>}
        <p className="text-[11px] text-slate-600 mt-0.5">
          {seller.addressLine1}, {seller.city}, {seller.state} - {seller.pincode}
        </p>
        <p className="text-[11px] font-mono font-bold text-slate-800 mt-0.5">
          GSTIN: {seller.gstin} | Tel: {seller.phone}
        </p>
      </div>

      {/* Document Title Banner */}
      <div className="flex items-center justify-between py-2 border-b border-dashed border-slate-400 text-xs">
        <div>
          <span className="font-extrabold uppercase tracking-wider text-slate-900 text-xs bg-slate-100 px-2 py-0.5 rounded border border-slate-300">
            {docTitle}
          </span>
        </div>
        <div className="text-right">
          <span className="font-mono font-bold text-sm text-slate-900">#{invoice.invoiceNumber}</span>
        </div>
      </div>

      {/* Date & Customer Row */}
      <div className="grid grid-cols-2 gap-2 py-2 border-b border-slate-200 text-xs">
        <div>
          <span className="text-[10px] text-slate-500 uppercase font-semibold block">Customer Details:</span>
          <p className="font-bold text-slate-900">{buyer.companyName || buyer.name || 'Counter Walk-in Customer'}</p>
          {buyer.phone && <p className="text-slate-600 font-mono text-[11px]">Mob: {buyer.phone}</p>}
          {buyer.gstin && <p className="text-slate-700 font-mono font-semibold text-[11px]">GSTIN: {buyer.gstin}</p>}
          {buyer.placeOfSupply && <p className="text-slate-500 text-[10px]">POS: {buyer.placeOfSupply}</p>}
        </div>

        <div className="text-right space-y-0.5">
          <span className="text-[10px] text-slate-500 uppercase font-semibold block">Billing Meta:</span>
          <p className="font-mono text-slate-800"><span className="text-slate-500">Date:</span> {invoice.invoiceDate}</p>
          <p className="font-mono text-slate-800"><span className="text-slate-500">Due:</span> {invoice.dueDate}</p>
          {invoice.poNumber && <p className="font-mono text-slate-700"><span className="text-slate-500">Ref:</span> {invoice.poNumber}</p>}
        </div>
      </div>

      {/* Items Table */}
      <div className="py-2">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-900 text-slate-800 font-bold uppercase text-[10px]">
              <th className="py-1.5 pl-1 w-6">#</th>
              <th className="py-1.5">Description</th>
              {showHsn && <th className="py-1.5 text-center w-16">HSN</th>}
              <th className="py-1.5 text-center w-12">Qty</th>
              <th className="py-1.5 text-right w-16">Rate</th>
              {showDiscount && <th className="py-1.5 text-right w-12">Disc</th>}
              <th className="py-1.5 text-right w-14">GST%</th>
              <th className="py-1.5 pr-1 text-right w-20">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {items.map((item, idx) => (
              <tr key={item.id || idx}>
                <td className="py-1.5 pl-1 text-slate-500 text-[11px]">{idx + 1}</td>
                <td className="py-1.5 font-medium text-slate-900">
                  {item.description}
                </td>
                {showHsn && <td className="py-1.5 text-center font-mono text-[10px] text-slate-600">{item.hsnSacCode || '-'}</td>}
                <td className="py-1.5 text-center font-mono">{item.quantity} {item.unit}</td>
                <td className="py-1.5 text-right font-mono">{formatCurrency(item.unitPrice, '').trim()}</td>
                {showDiscount && <td className="py-1.5 text-right font-mono text-slate-500">{item.discountPercent ? `${item.discountPercent}%` : '-'}</td>}
                <td className="py-1.5 text-right font-mono text-slate-600 text-[11px]">{item.gstRate}%</td>
                <td className="py-1.5 pr-1 text-right font-mono font-bold text-slate-900">{formatCurrency(item.totalAmount, '').trim()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Box */}
      <div className="pt-2 border-t-2 border-slate-900 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Left column: In words & Payment details */}
        <div className="space-y-2">
          <div className="bg-slate-50 p-2 rounded border border-slate-200 text-[11px]">
            <span className="font-bold text-slate-600 uppercase text-[10px] block">Amount in Words:</span>
            <span className="font-semibold text-slate-900 italic">{invoice.amountInWords}</span>
          </div>

          {showBank && (
            <div className="text-[11px] text-slate-600 space-y-0.5 bg-slate-50 p-2 rounded border border-slate-200">
              <span className="font-bold text-slate-800 uppercase text-[10px] block">Payment / Bank Transfer:</span>
              <p>Bank: <span className="font-semibold">{seller.bankDetails.bankName}</span> (A/c: <span className="font-mono font-bold">{seller.bankDetails.accountNumber}</span>)</p>
              <p>IFSC: <span className="font-mono font-semibold">{seller.bankDetails.ifscCode}</span> | UPI: <span className="font-mono text-indigo-700 font-bold">{seller.bankDetails.upiId}</span></p>
            </div>
          )}

          {showNotes && (
            <div className="text-[11px] text-slate-600">
              <span className="font-bold text-slate-700">Note: </span>
              <span>{invoice.notes}</span>
            </div>
          )}

          {showTerms && (
            <div className="text-[10px] text-slate-500">
              <span className="font-bold text-slate-700 block mb-0.5">Terms & Conditions:</span>
              <p className="whitespace-pre-line leading-relaxed">{invoice.termsAndConditions}</p>
            </div>
          )}
        </div>

        {/* Right column: Calculations */}
        <div className="space-y-2">
          <div className="bg-slate-50 p-2.5 rounded border border-slate-300 font-mono text-xs space-y-1">
            <div className="flex justify-between text-slate-600">
              <span>Taxable Total:</span>
              <span>{formatCurrency(invoice.totalTaxableAmount, seller.currencySymbol)}</span>
            </div>
            {invoice.totalDiscount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Discount:</span>
                <span>-{formatCurrency(invoice.totalDiscount, seller.currencySymbol)}</span>
              </div>
            )}
            {invoice.isInterState ? (
              <div className="flex justify-between text-slate-700">
                <span>IGST:</span>
                <span>{formatCurrency(invoice.igstTotal, seller.currencySymbol)}</span>
              </div>
            ) : (
              <>
                <div className="flex justify-between text-slate-700">
                  <span>CGST:</span>
                  <span>{formatCurrency(invoice.cgstTotal, seller.currencySymbol)}</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>SGST:</span>
                  <span>{formatCurrency(invoice.sgstTotal, seller.currencySymbol)}</span>
                </div>
              </>
            )}
            {invoice.roundOff !== 0 && (
              <div className="flex justify-between text-slate-500 text-[11px]">
                <span>Round Off:</span>
                <span>{invoice.roundOff > 0 ? `+${invoice.roundOff}` : invoice.roundOff}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-black text-slate-900 border-t-2 border-slate-900 pt-1.5">
              <span className="font-sans uppercase">NET PAYABLE:</span>
              <span>{formatCurrency(invoice.grandTotal, seller.currencySymbol)}</span>
            </div>
          </div>

          {showSignatory && (
            <div className="text-right pt-2 text-[11px]">
              <p className="text-slate-500">Authorized Signatory</p>
              <p className="font-bold text-slate-900">{seller.signatoryName || seller.businessName}</p>
            </div>
          )}
        </div>
      </div>

      {/* Footer thank you message */}
      <div className="mt-4 pt-2 border-t border-dashed border-slate-400 text-center text-[11px] font-semibold text-slate-600">
        *** Thank you for your business! Please visit again. ***
      </div>
    </div>
  );
};
