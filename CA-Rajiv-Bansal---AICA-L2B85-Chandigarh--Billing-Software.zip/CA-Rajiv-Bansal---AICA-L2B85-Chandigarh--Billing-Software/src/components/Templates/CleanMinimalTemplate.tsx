import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency } from '../../utils/numberToWords';

export const CleanMinimalTemplate: React.FC<{ invoice: Invoice }> = ({ invoice }) => {
  const { seller, buyer, items } = invoice;

  return (
    <div id="printable-invoice" className="bg-white p-8 rounded-lg shadow-sm max-w-4xl mx-auto text-slate-800 text-xs font-sans print:p-0 print:shadow-none print:max-w-none">
      {/* Minimal Header */}
      <div className="flex justify-between items-start pb-8 border-b border-slate-100">
        <div>
          <h1 className="text-3xl font-light text-slate-900 tracking-tight">{seller.businessName}</h1>
          <p className="text-slate-500 mt-1">{seller.addressLine1}, {seller.city} {seller.pincode}</p>
          <p className="text-slate-500 font-mono text-[11px]">GSTIN: {seller.gstin} | PAN: {seller.pan}</p>
        </div>
        <div className="text-right">
          <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">INVOICE</span>
          <div className="text-lg font-mono font-semibold text-slate-900 mt-1">{invoice.invoiceNumber}</div>
          <div className="text-slate-500 text-xs mt-1">Date: {invoice.invoiceDate}</div>
          <div className="text-slate-500 text-xs">Due: {invoice.dueDate}</div>
        </div>
      </div>

      {/* Bill To */}
      <div className="py-6 grid grid-cols-2 gap-8 border-b border-slate-100">
        <div>
          <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 block mb-2">BILLED TO</span>
          <p className="font-semibold text-sm text-slate-900">{buyer.companyName || buyer.name}</p>
          <p className="text-slate-600 mt-1">{buyer.billingAddress.addressLine1}</p>
          <p className="text-slate-600">{buyer.billingAddress.city}, {buyer.billingAddress.state} - {buyer.billingAddress.pincode}</p>
          <p className="text-slate-500 font-mono mt-2">GSTIN: {buyer.gstin || 'Unregistered'}</p>
        </div>
        <div className="text-right flex flex-col justify-end">
          <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 block mb-2">PLACE OF SUPPLY</span>
          <p className="text-slate-800 font-medium">{buyer.placeOfSupply || buyer.billingAddress.state}</p>
          <p className="text-slate-500 text-[11px] mt-1">{invoice.isInterState ? 'IGST Applicable (Inter-State)' : 'CGST + SGST (Intra-State)'}</p>
        </div>
      </div>

      {/* Items */}
      <div className="py-6">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-slate-200 text-slate-400 text-[11px] uppercase tracking-wider">
              <th className="pb-3 font-semibold">Item & Details</th>
              <th className="pb-3 text-center w-16">Qty</th>
              <th className="pb-3 text-right w-24">Price</th>
              <th className="pb-3 text-right w-24">Taxable</th>
              <th className="pb-3 text-right w-24">Tax</th>
              <th className="pb-3 text-right w-28">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((item, idx) => (
              <tr key={idx} className="text-slate-700">
                <td className="py-3.5 pr-4">
                  <p className="font-medium text-slate-900">{item.description}</p>
                  <p className="text-[10px] text-slate-400 font-mono">HSN: {item.hsnSacCode}</p>
                </td>
                <td className="py-3.5 text-center">{item.quantity} {item.unit}</td>
                <td className="py-3.5 text-right font-mono">{formatCurrency(item.unitPrice, '').trim()}</td>
                <td className="py-3.5 text-right font-mono">{formatCurrency(item.taxableAmount, '').trim()}</td>
                <td className="py-3.5 text-right font-mono text-slate-500">
                  <span className="text-[10px]">({item.gstRate}%)</span> {formatCurrency(item.cgstAmount + item.sgstAmount + item.igstAmount, '').trim()}
                </td>
                <td className="py-3.5 text-right font-mono font-semibold text-slate-900">{formatCurrency(item.totalAmount, '').trim()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer Calculation */}
      <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-between gap-6">
        <div className="max-w-sm space-y-4">
          <div>
            <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 block mb-1">PAYMENT DETAILS</span>
            <p className="text-slate-700 font-mono text-xs">{seller.bankDetails.bankName} - A/c {seller.bankDetails.accountNumber}</p>
            <p className="text-slate-500 font-mono text-xs">IFSC: {seller.bankDetails.ifscCode}</p>
            {seller.bankDetails.upiId && <p className="text-blue-600 font-mono text-xs mt-0.5">UPI: {seller.bankDetails.upiId}</p>}
          </div>

          <div className="text-slate-500 text-[11px] leading-relaxed">
            <p className="font-semibold text-slate-700 mb-0.5">Terms:</p>
            <p>{seller.defaultTerms}</p>
          </div>
        </div>

        <div className="w-full sm:w-72 space-y-2 text-right">
          <div className="flex justify-between text-slate-500">
            <span>Taxable Total:</span>
            <span className="font-mono">{formatCurrency(invoice.totalTaxableAmount, seller.currencySymbol)}</span>
          </div>
          <div className="flex justify-between text-slate-500">
            <span>GST Output:</span>
            <span className="font-mono">{formatCurrency(invoice.totalTax, seller.currencySymbol)}</span>
          </div>
          {invoice.roundOff !== 0 && (
            <div className="flex justify-between text-slate-400 text-xs">
              <span>Round Off:</span>
              <span className="font-mono">{invoice.roundOff}</span>
            </div>
          )}
          <div className="flex justify-between text-base font-bold text-slate-900 border-t border-slate-900 pt-3">
            <span>Grand Total:</span>
            <span className="font-mono">{formatCurrency(invoice.grandTotal, seller.currencySymbol)}</span>
          </div>
          <p className="text-[11px] text-slate-500 italic mt-2 text-left">{invoice.amountInWords}</p>

          <div className="pt-8 text-right">
            <p className="text-xs font-semibold text-slate-800">{seller.signatoryName}</p>
            <p className="text-[10px] text-slate-400">{seller.signatoryDesignation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
