import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency } from '../../utils/numberToWords';

export const ClassicCorporateTemplate: React.FC<{ invoice: Invoice }> = ({ invoice }) => {
  const { seller, buyer, items } = invoice;
  const format = invoice.billingFormat || seller.billingFormat;
  const docTitle = format?.documentTitle || 'TAX INVOICE';
  const showLogo = format?.showLogo !== false && !!seller.logoUrl;

  return (
    <div id="printable-invoice" className="bg-white p-6 sm:p-8 rounded-lg shadow-sm max-w-4xl mx-auto text-slate-800 text-xs border border-slate-300 print:p-0 print:shadow-none print:max-w-none print:border-none">
      {/* Top Banner Header */}
      <div className="text-center pb-4 border-b-2 border-double border-slate-700">
        {showLogo && (
          <div className="flex justify-center mb-2">
            <img
              src={seller.logoUrl}
              alt="Logo"
              style={{ maxHeight: `${format?.logoHeight || 52}px` }}
              className="object-contain"
            />
          </div>
        )}
        <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-wider uppercase">{seller.businessName}</h1>
        {seller.legalName && seller.legalName !== seller.businessName && (
          <p className="text-[11px] text-slate-600 font-serif">({seller.legalName})</p>
        )}
        <p className="text-xs text-slate-600 mt-1">
          {seller.addressLine1}, {seller.city}, {seller.state} - {seller.pincode}
        </p>
        <p className="text-xs text-slate-700 font-mono font-medium">
          GSTIN: {seller.gstin} | PAN: {seller.pan} | Email: {seller.email} | Tel: {seller.phone}
        </p>
      </div>

      <div className="text-center my-3">
        <span className="inline-block px-4 py-1 bg-slate-100 border border-slate-400 font-bold uppercase tracking-widest text-xs">
          {docTitle}
        </span>
      </div>

      {/* Invoice Meta and Parties in structured grid */}
      <div className="grid grid-cols-2 border border-slate-400 divide-x divide-slate-400 mb-4">
        {/* Buyer Info */}
        <div className="p-3 space-y-1">
          <p className="font-bold uppercase text-[11px] text-slate-700 border-b border-slate-200 pb-1">Details of Receiver (Billed To):</p>
          <p className="font-bold text-sm text-slate-900">{buyer.companyName || buyer.name}</p>
          {buyer.companyName && <p className="text-slate-600">Contact: {buyer.name}</p>}
          <p className="text-slate-600">{buyer.billingAddress.addressLine1}</p>
          <p className="text-slate-600">{buyer.billingAddress.city}, {buyer.billingAddress.state} - {buyer.billingAddress.pincode}</p>
          <p className="font-medium pt-1">GSTIN: <span className="font-mono font-bold">{buyer.gstin || 'Unregistered'}</span></p>
          <p>State / Code: <span className="font-medium">{buyer.billingAddress.state} ({buyer.billingAddress.stateCode || '--'})</span></p>
        </div>

        {/* Invoice Info */}
        <div className="p-3 space-y-1 bg-slate-50/50">
          <p className="font-bold uppercase text-[11px] text-slate-700 border-b border-slate-200 pb-1">Invoice Details:</p>
          <div className="grid grid-cols-2 gap-y-1">
            <span className="font-semibold text-slate-600">Invoice No:</span>
            <span className="font-mono font-bold text-slate-900">{invoice.invoiceNumber}</span>

            <span className="font-semibold text-slate-600">Invoice Date:</span>
            <span className="font-mono">{invoice.invoiceDate}</span>

            <span className="font-semibold text-slate-600">Payment Due:</span>
            <span className="font-mono">{invoice.dueDate}</span>

            <span className="font-semibold text-slate-600">PO / Ref No:</span>
            <span className="font-mono">{invoice.poNumber || 'N/A'}</span>

            <span className="font-semibold text-slate-600">Place of Supply:</span>
            <span>{buyer.placeOfSupply || buyer.billingAddress.state}</span>
          </div>
        </div>
      </div>

      {/* Line Items Table with clear traditional borders */}
      <table className="w-full text-left border border-slate-400 border-collapse mb-4">
        <thead>
          <tr className="bg-slate-200 text-slate-800 font-bold border-b border-slate-400">
            <th className="p-2 border-r border-slate-400 text-center w-8">S.N.</th>
            <th className="p-2 border-r border-slate-400">Description of Goods / Services</th>
            <th className="p-2 border-r border-slate-400 text-center w-16">HSN/SAC</th>
            <th className="p-2 border-r border-slate-400 text-center w-14">Qty</th>
            <th className="p-2 border-r border-slate-400 text-right w-20">Rate</th>
            <th className="p-2 border-r border-slate-400 text-right w-20">Taxable</th>
            {invoice.isInterState ? (
              <th className="p-2 border-r border-slate-400 text-right w-20">IGST</th>
            ) : (
              <>
                <th className="p-2 border-r border-slate-400 text-right w-16">CGST</th>
                <th className="p-2 border-r border-slate-400 text-right w-16">SGST</th>
              </>
            )}
            <th className="p-2 text-right w-24">Amount</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-300">
          {items.map((item, idx) => (
            <tr key={idx}>
              <td className="p-2 border-r border-slate-300 text-center">{idx + 1}</td>
              <td className="p-2 border-r border-slate-300 font-medium text-slate-900">{item.description}</td>
              <td className="p-2 border-r border-slate-300 text-center font-mono">{item.hsnSacCode}</td>
              <td className="p-2 border-r border-slate-300 text-center">{item.quantity} {item.unit}</td>
              <td className="p-2 border-r border-slate-300 text-right font-mono">{formatCurrency(item.unitPrice, '').trim()}</td>
              <td className="p-2 border-r border-slate-300 text-right font-mono">{formatCurrency(item.taxableAmount, '').trim()}</td>
              {invoice.isInterState ? (
                <td className="p-2 border-r border-slate-300 text-right font-mono">
                  <span className="text-[10px] block text-slate-500">{item.igstRate}%</span>
                  {formatCurrency(item.igstAmount, '').trim()}
                </td>
              ) : (
                <>
                  <td className="p-2 border-r border-slate-300 text-right font-mono">
                    <span className="text-[10px] block text-slate-500">{item.cgstRate}%</span>
                    {formatCurrency(item.cgstAmount, '').trim()}
                  </td>
                  <td className="p-2 border-r border-slate-300 text-right font-mono">
                    <span className="text-[10px] block text-slate-500">{item.sgstRate}%</span>
                    {formatCurrency(item.sgstAmount, '').trim()}
                  </td>
                </>
              )}
              <td className="p-2 text-right font-mono font-bold">{formatCurrency(item.totalAmount, '').trim()}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Footer Calculation & Bank Grid */}
      <div className="grid grid-cols-2 border border-slate-400 divide-x divide-slate-400">
        <div className="p-3 space-y-2">
          <div>
            <span className="font-bold text-[11px] text-slate-700 block uppercase">Bank Payment Instructions:</span>
            <p className="text-slate-800">Bank Name: <span className="font-semibold">{seller.bankDetails.bankName}</span></p>
            <p className="text-slate-800">Account No: <span className="font-mono font-bold">{seller.bankDetails.accountNumber}</span></p>
            <p className="text-slate-800">IFSC Code: <span className="font-mono font-bold">{seller.bankDetails.ifscCode}</span></p>
            <p className="text-slate-800">Branch: {seller.bankDetails.branch}</p>
            {seller.bankDetails.upiId && <p className="text-slate-800">UPI ID: <span className="font-mono font-semibold text-blue-700">{seller.bankDetails.upiId}</span></p>}
          </div>

          <div className="pt-2 border-t border-slate-200">
            <span className="font-bold text-[11px] text-slate-700 block">Amount in Words:</span>
            <p className="font-semibold italic text-slate-900">{invoice.amountInWords}</p>
          </div>
        </div>

        <div className="p-3 space-y-1.5 font-mono">
          <div className="flex justify-between">
            <span className="text-slate-600">Taxable Value:</span>
            <span>{formatCurrency(invoice.totalTaxableAmount, seller.currencySymbol)}</span>
          </div>
          {invoice.isInterState ? (
            <div className="flex justify-between">
              <span className="text-slate-600">Integrated Tax (IGST):</span>
              <span>{formatCurrency(invoice.igstTotal, seller.currencySymbol)}</span>
            </div>
          ) : (
            <>
              <div className="flex justify-between">
                <span className="text-slate-600">Central Tax (CGST):</span>
                <span>{formatCurrency(invoice.cgstTotal, seller.currencySymbol)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">State Tax (SGST):</span>
                <span>{formatCurrency(invoice.sgstTotal, seller.currencySymbol)}</span>
              </div>
            </>
          )}
          {invoice.roundOff !== 0 && (
            <div className="flex justify-between text-slate-500">
              <span>Round Off:</span>
              <span>{invoice.roundOff > 0 ? `+${invoice.roundOff}` : invoice.roundOff}</span>
            </div>
          )}
          <div className="flex justify-between text-sm font-bold text-slate-900 border-t border-slate-400 pt-2">
            <span className="font-sans uppercase">Total Invoice Value:</span>
            <span>{formatCurrency(invoice.grandTotal, seller.currencySymbol)}</span>
          </div>

          <div className="pt-8 text-right font-sans">
            <p className="font-bold text-slate-900">For {seller.businessName}</p>
            <div className="h-8"></div>
            <p className="font-semibold">{seller.signatoryName}</p>
            <p className="text-[11px] text-slate-500">{seller.signatoryDesignation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
