import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency } from '../../utils/numberToWords';

interface TemplateProps {
  invoice: Invoice;
}

export const ModernNavyTemplate: React.FC<TemplateProps> = ({ invoice }) => {
  const { seller, buyer, items } = invoice;
  const format = invoice.billingFormat || seller.billingFormat;
  const docTitle = format?.documentTitle || 'TAX INVOICE';
  const showLogo = format?.showLogo !== false && !!seller.logoUrl;
  const showHsn = format?.showHsnSac !== false;
  const showDiscount = format?.showDiscount !== false && invoice.totalDiscount > 0;
  const showBank = format?.showBankDetails !== false;
  const showSignatory = format?.showSignatoryBox !== false;
  const showTerms = format?.showTerms !== false && !!invoice.termsAndConditions;
  const showNotes = format?.showNotes !== false && !!invoice.notes;

  return (
    <div id="printable-invoice" className="bg-white p-6 sm:p-8 rounded-lg shadow-sm max-w-4xl mx-auto text-slate-800 text-sm print:p-0 print:shadow-none print:max-w-none print:rounded-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-200 pb-6 gap-4">
        <div>
          <div className="flex items-center gap-3">
            {showLogo && (
              <img
                src={seller.logoUrl}
                alt="Logo"
                style={{ maxHeight: `${format?.logoHeight || 52}px` }}
                className="object-contain"
              />
            )}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{seller.businessName}</h1>
              {seller.tagline && <p className="text-xs text-slate-500 font-medium">{seller.tagline}</p>}
            </div>
          </div>
          <div className="mt-3 text-xs text-slate-600 space-y-0.5">
            <p>{seller.addressLine1}{seller.addressLine2 ? `, ${seller.addressLine2}` : ''}</p>
            <p>{seller.city}, {seller.state} - {seller.pincode}, {seller.country}</p>
            <p className="font-medium text-slate-700">GSTIN: <span className="font-mono text-slate-900">{seller.gstin}</span> | PAN: <span className="font-mono">{seller.pan}</span></p>
            <p>Email: {seller.email} | Phone: {seller.phone}</p>
          </div>
        </div>

        <div className="text-left sm:text-right bg-slate-900 text-white p-4 rounded-md min-w-[200px] print:bg-slate-900 print:text-white">
          <span className="text-xs uppercase tracking-wider font-semibold text-slate-300">{docTitle}</span>
          <div className="text-xl font-mono font-bold mt-1">{invoice.invoiceNumber}</div>
          <div className="text-xs text-slate-300 mt-2 space-y-0.5">
            <p>Date: <span className="font-semibold text-white">{invoice.invoiceDate}</span></p>
            <p>Due Date: <span className="font-semibold text-white">{invoice.dueDate}</span></p>
            {invoice.poNumber && <p>PO / Ref: <span className="font-semibold text-white">{invoice.poNumber}</span></p>}
            <p>Place of Supply: <span className="font-semibold text-white">{buyer.placeOfSupply || buyer.billingAddress.state}</span></p>
          </div>
        </div>
      </div>

      {/* Bill To & Ship To Details */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-b border-slate-200 text-xs">
        <div className="bg-slate-50 p-3 rounded border border-slate-200">
          <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px] block mb-1">Billed To (Client / Buyer):</span>
          <p className="font-bold text-sm text-slate-900">{buyer.companyName || buyer.name}</p>
          {buyer.companyName && buyer.name && <p className="text-slate-600">Attn: {buyer.name}</p>}
          <p className="text-slate-600 mt-1">{buyer.billingAddress.addressLine1}</p>
          <p className="text-slate-600">{buyer.billingAddress.city}, {buyer.billingAddress.state} - {buyer.billingAddress.pincode}</p>
          <div className="mt-2 pt-2 border-t border-slate-200 space-y-0.5">
            <p className="font-medium text-slate-800">GSTIN / Tax ID: <span className="font-mono font-bold text-slate-900">{buyer.gstin || 'Unregistered / B2C'}</span></p>
            {buyer.email && <p className="text-slate-600">Email: {buyer.email}</p>}
            {buyer.phone && <p className="text-slate-600">Phone: {buyer.phone}</p>}
          </div>
        </div>

        <div className="bg-slate-50 p-3 rounded border border-slate-200 flex flex-col justify-between">
          <div>
            <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px] block mb-1">Payment & Bank Details:</span>
            <div className="space-y-0.5 text-slate-700">
              <p>Bank: <span className="font-semibold text-slate-900">{seller.bankDetails.bankName}</span></p>
              <p>A/c Name: <span className="font-medium">{seller.bankDetails.accountHolder}</span></p>
              <p>A/c No: <span className="font-mono font-bold text-slate-900">{seller.bankDetails.accountNumber}</span></p>
              <p>IFSC / Branch: <span className="font-mono font-semibold">{seller.bankDetails.ifscCode}</span> ({seller.bankDetails.branch})</p>
              {seller.bankDetails.upiId && <p>UPI ID: <span className="font-mono text-blue-700 font-bold">{seller.bankDetails.upiId}</span></p>}
            </div>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 italic">
            State of Supply: {seller.state} ({seller.stateCode}) &rarr; {buyer.billingAddress.state} ({buyer.billingAddress.stateCode || '--'}) [{invoice.isInterState ? 'IGST Applicable' : 'CGST + SGST Applicable'}]
          </div>
        </div>
      </div>

      {/* Line Items Table */}
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-800 text-white">
              <th className="p-2.5 rounded-l text-center w-10">#</th>
              <th className="p-2.5">Item & Description</th>
              <th className="p-2.5 text-center w-20">HSN/SAC</th>
              <th className="p-2.5 text-center w-16">Qty</th>
              <th className="p-2.5 text-right w-24">Rate ({seller.currencySymbol})</th>
              <th className="p-2.5 text-right w-16">Disc %</th>
              <th className="p-2.5 text-right w-24">Taxable ({seller.currencySymbol})</th>
              {invoice.isInterState ? (
                <th className="p-2.5 text-right w-24">IGST</th>
              ) : (
                <>
                  <th className="p-2.5 text-right w-20">CGST</th>
                  <th className="p-2.5 text-right w-20">SGST</th>
                </>
              )}
              <th className="p-2.5 rounded-r text-right w-28">Total ({seller.currencySymbol})</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {items.map((item, idx) => (
              <tr key={item.id || idx} className="hover:bg-slate-50/50">
                <td className="p-2.5 text-center text-slate-500">{idx + 1}</td>
                <td className="p-2.5 font-medium text-slate-900">
                  <div>{item.description}</div>
                </td>
                <td className="p-2.5 text-center font-mono text-slate-600">{item.hsnSacCode || '-'}</td>
                <td className="p-2.5 text-center">{item.quantity} <span className="text-[10px] text-slate-500">{item.unit}</span></td>
                <td className="p-2.5 text-right font-mono">{formatCurrency(item.unitPrice, '').trim()}</td>
                <td className="p-2.5 text-right font-mono text-slate-500">{item.discountPercent ? `${item.discountPercent}%` : '-'}</td>
                <td className="p-2.5 text-right font-mono font-medium">{formatCurrency(item.taxableAmount, '').trim()}</td>
                {invoice.isInterState ? (
                  <td className="p-2.5 text-right font-mono">
                    <span className="text-[10px] text-slate-500 block">({item.igstRate}%)</span>
                    {formatCurrency(item.igstAmount, '').trim()}
                  </td>
                ) : (
                  <>
                    <td className="p-2.5 text-right font-mono">
                      <span className="text-[10px] text-slate-500 block">({item.cgstRate}%)</span>
                      {formatCurrency(item.cgstAmount, '').trim()}
                    </td>
                    <td className="p-2.5 text-right font-mono">
                      <span className="text-[10px] text-slate-500 block">({item.sgstRate}%)</span>
                      {formatCurrency(item.sgstAmount, '').trim()}
                    </td>
                  </>
                )}
                <td className="p-2.5 text-right font-mono font-bold text-slate-900">{formatCurrency(item.totalAmount, '').trim()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals and Summary */}
      <div className="mt-4 pt-3 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Left Side: Amount in Words & Notes */}
        <div className="space-y-3">
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
            <span className="text-[11px] font-bold text-slate-700 uppercase block mb-0.5">Total Amount in Words:</span>
            <p className="text-xs font-semibold text-slate-900 italic">{invoice.amountInWords}</p>
          </div>

          {invoice.notes && (
            <div className="text-xs text-slate-600">
              <span className="font-bold text-slate-700 block mb-0.5">Special Notes:</span>
              <p className="whitespace-pre-line">{invoice.notes}</p>
            </div>
          )}

          {invoice.termsAndConditions && (
            <div className="text-[11px] text-slate-500">
              <span className="font-bold text-slate-700 block mb-0.5">Terms & Conditions:</span>
              <p className="whitespace-pre-line leading-relaxed">{invoice.termsAndConditions}</p>
            </div>
          )}
        </div>

        {/* Right Side: Calculations Table & Signatory */}
        <div className="space-y-4">
          <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs space-y-1.5 font-mono">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal:</span>
              <span>{formatCurrency(invoice.subTotal, seller.currencySymbol)}</span>
            </div>
            {invoice.totalDiscount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Total Discount:</span>
                <span>-{formatCurrency(invoice.totalDiscount, seller.currencySymbol)}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold text-slate-800 border-t border-slate-200 pt-1">
              <span>Taxable Value:</span>
              <span>{formatCurrency(invoice.totalTaxableAmount, seller.currencySymbol)}</span>
            </div>
            {invoice.isInterState ? (
              <div className="flex justify-between text-slate-700">
                <span>Integrated Tax (IGST):</span>
                <span>{formatCurrency(invoice.igstTotal, seller.currencySymbol)}</span>
              </div>
            ) : (
              <>
                <div className="flex justify-between text-slate-700">
                  <span>Central Tax (CGST):</span>
                  <span>{formatCurrency(invoice.cgstTotal, seller.currencySymbol)}</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>State Tax (SGST):</span>
                  <span>{formatCurrency(invoice.sgstTotal, seller.currencySymbol)}</span>
                </div>
              </>
            )}
            {invoice.roundOff !== 0 && (
              <div className="flex justify-between text-slate-500">
                <span>Round Off:</span>
                <span>{invoice.roundOff > 0 ? `+${invoice.roundOff}` : invoice.roundOff}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-bold text-slate-900 border-t-2 border-slate-900 pt-1.5">
              <span className="font-sans">Grand Total:</span>
              <span>{formatCurrency(invoice.grandTotal, seller.currencySymbol)}</span>
            </div>
          </div>

          {/* Authorized Signatory Box */}
          <div className="text-right pt-4 text-xs">
            <p className="font-bold text-slate-900">For {seller.businessName}</p>
            <div className="h-12 flex items-center justify-end">
              <div className="border-b border-dashed border-slate-400 w-44 mt-6"></div>
            </div>
            <p className="font-semibold text-slate-800">{seller.signatoryName}</p>
            <p className="text-[11px] text-slate-500">{seller.signatoryDesignation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
