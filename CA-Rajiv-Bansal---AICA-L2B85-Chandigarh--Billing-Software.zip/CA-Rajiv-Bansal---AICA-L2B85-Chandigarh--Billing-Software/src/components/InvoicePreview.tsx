import React, { useState } from 'react';
import { Invoice, TemplateStyle } from '../types';
import { ModernNavyTemplate } from './Templates/ModernNavyTemplate';
import { ClassicCorporateTemplate } from './Templates/ClassicCorporateTemplate';
import { CleanMinimalTemplate } from './Templates/CleanMinimalTemplate';
import { TaxCompactTemplate } from './Templates/TaxCompactTemplate';
import { RetailPosTemplate } from './Templates/RetailPosTemplate';
import { exportTaxComplianceExcel } from '../utils/excelGenerator';
import { 
  Printer, 
  FileSpreadsheet, 
  Share2, 
  Edit3, 
  ArrowLeft, 
  CheckCircle, 
  Clock, 
  Layout, 
  Sparkles 
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface InvoicePreviewProps {
  invoice: Invoice;
  onEdit: (invoice: Invoice) => void;
  onBack: () => void;
  onUpdateStatus?: (invoiceId: string, newStatus: Invoice['status']) => void;
  onOpenShareModal: (invoice: Invoice) => void;
}

export const InvoicePreview: React.FC<InvoicePreviewProps> = ({
  invoice,
  onEdit,
  onBack,
  onUpdateStatus,
  onOpenShareModal,
}) => {
  const [currentTemplate, setCurrentTemplate] = useState<TemplateStyle>(invoice.templateStyle || 'modern-navy');

  const handlePrint = () => {
    window.print();
  };

  const handleExportExcel = () => {
    exportTaxComplianceExcel([invoice], invoice.seller, `Invoice_${invoice.invoiceNumber.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  const handleMarkAsPaid = () => {
    if (onUpdateStatus) {
      onUpdateStatus(invoice.id, 'paid');
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        // Safe fallback if confetti isn't supported
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar (Hidden when printing) */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Invoices
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800">Status:</span>
            <span
              className={`px-2.5 py-1 text-xs font-semibold rounded-full uppercase tracking-wider ${
                invoice.status === 'paid'
                  ? 'bg-emerald-100 text-emerald-800'
                  : invoice.status === 'issued'
                  ? 'bg-blue-100 text-blue-800'
                  : invoice.status === 'overdue'
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {invoice.status}
            </span>
          </div>

          {invoice.status !== 'paid' && onUpdateStatus && (
            <button
              onClick={handleMarkAsPaid}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              Mark as Paid
            </button>
          )}
        </div>

        {/* Template Selector & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Template switcher */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <Layout className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
            <select
              value={currentTemplate}
              onChange={(e) => setCurrentTemplate(e.target.value as TemplateStyle)}
              aria-label="Select Invoice Template"
              className="text-xs font-medium bg-transparent text-slate-800 border-none outline-none py-1 px-1 cursor-pointer"
            >
              <option value="modern-navy">Modern Navy Template</option>
              <option value="classic-corporate">Classic Corporate Template</option>
              <option value="clean-minimal">Clean Minimal Template</option>
              <option value="tax-compact">Tax Statutory Compact Template</option>
              <option value="retail-pos">Retail &amp; Counter POS Template</option>
            </select>
          </div>

          <button
            onClick={() => onEdit(invoice)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            Edit
          </button>

          <button
            onClick={() => onOpenShareModal(invoice)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-blue-600" />
            Share / WhatsApp
          </button>

          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            Export Excel (.xlsx)
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / Save PDF
          </button>
        </div>
      </div>

      {/* Render Selected Printable Invoice */}
      <div className="transition-all duration-200">
        {currentTemplate === 'modern-navy' && <ModernNavyTemplate invoice={invoice} />}
        {currentTemplate === 'classic-corporate' && <ClassicCorporateTemplate invoice={invoice} />}
        {currentTemplate === 'clean-minimal' && <CleanMinimalTemplate invoice={invoice} />}
        {currentTemplate === 'tax-compact' && <TaxCompactTemplate invoice={invoice} />}
        {currentTemplate === 'retail-pos' && <RetailPosTemplate invoice={invoice} />}
      </div>
    </div>
  );
};
