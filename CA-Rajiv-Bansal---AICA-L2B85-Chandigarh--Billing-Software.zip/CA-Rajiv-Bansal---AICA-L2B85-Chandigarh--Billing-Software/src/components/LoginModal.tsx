import React, { useState } from 'react';
import { SellerProfile, UserAccount } from '../types';
import { LicenseManager } from '../utils/licenseManager';
import { 
  ShieldCheck, 
  UserCheck, 
  Key, 
  Lock, 
  ArrowRight, 
  Building2, 
  CheckCircle, 
  Smartphone,
  Mail,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  users: UserAccount[];
  sellerProfiles: SellerProfile[];
  currentUser: UserAccount;
  onSelectUser: (user: UserAccount) => void;
  onCreateClientAccount: (username: string, displayName: string, businessName: string) => void;
  onClose: () => void;
  onOpenActivationModal?: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  users,
  sellerProfiles,
  currentUser,
  onSelectUser,
  onCreateClientAccount,
  onClose,
  onOpenActivationModal
}) => {
  const [activeTab, setActiveTab] = useState<'master' | 'quick' | 'new_id'>('quick');
  const [newUsername, setNewUsername] = useState('');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newBusinessName, setNewBusinessName] = useState('');

  // Master Admin Login State
  const adminUser = users.find(u => u.role === 'admin') || users[0];
  const [masterPasscode, setMasterPasscode] = useState('');
  const [masterError, setMasterError] = useState('');

  if (!isOpen) return null;

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newBusinessName.trim()) {
      alert('Please provide Login ID and Business Name.');
      return;
    }
    const cleanUsername = newUsername.trim().toLowerCase().replace(/\s+/g, '_');
    onCreateClientAccount(
      cleanUsername,
      newDisplayName.trim() || newBusinessName.trim(),
      newBusinessName.trim()
    );
    onClose();
  };

  const handleMasterLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Verify admin user
    if (adminUser) {
      onSelectUser(adminUser);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-sm shadow-indigo-950/30">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold tracking-tight">Billing Access &amp; Workspace Login</h2>
                <p className="text-xs text-slate-400 mt-0.5">Admin master login or small business client workspace</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>

          {/* Tab buttons */}
          <div className="flex gap-1.5 mt-5 bg-slate-800/90 p-1 rounded-xl border border-slate-700/50 text-xs">
            <button
              onClick={() => setActiveTab('master')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'master'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Master Admin
            </button>
            <button
              onClick={() => setActiveTab('quick')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'quick'
                  ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-950/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Accounts
            </button>
            <button
              onClick={() => setActiveTab('new_id')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'new_id'
                  ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-950/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              + New Client
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6">
          {activeTab === 'master' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-emerald-50/60 border border-emerald-200/80 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-emerald-800 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Master Admin &amp; Licensing Authority</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  You are logging in as <strong>CMA Rajiv Bansal</strong> (Managing Partner &amp; Statutory Tax Auditor).
                </p>
                <div className="bg-white p-2.5 rounded-lg border border-emerald-200 font-mono text-[11px] space-y-0.5">
                  <div>Master User: <strong className="text-slate-900">admin</strong></div>
                  <div>Official Email: <strong className="text-indigo-700">CMARAJIVBANSAL@gmail.com</strong></div>
                  <div>Role: <strong className="text-emerald-700">Admin / Cost &amp; Management Accountant</strong></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-slate-600 text-[11px]">
                  Master admin privileges granted:
                  <ul className="list-disc pl-4 mt-1 space-y-0.5 text-slate-700">
                    <li>Generate tamper-proof license keys &amp; email official activation kits.</li>
                    <li>Full access to cross-client backend sales records &amp; Excel downloads.</li>
                    <li>Statutory GST audit (GSTR-1, GSTR-3B, and HSN summary).</li>
                  </ul>
                </div>

                <form onSubmit={handleMasterLogin} className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg shadow-sm active:scale-[0.98] transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Lock className="w-4 h-4 text-emerald-400" />
                    Enter as Master Admin (CMA Rajiv Bansal)
                  </button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'quick' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 mb-2">
                Select an account to start issuing invoices or access backend audit logs:
              </p>

              {users.map((u) => {
                const isCurrent = u.id === currentUser.id;
                const isAdmin = u.role === 'admin';
                const clientLicense = LicenseManager.getLicenseByClientUserId(u.id);

                return (
                  <button
                    key={u.id}
                    onClick={() => {
                      onSelectUser(u);
                      onClose();
                    }}
                    className={`w-full p-3.5 sm:p-4 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isCurrent
                        ? 'border-indigo-500 bg-indigo-50/50 ring-1 ring-indigo-500/30'
                        : 'border-slate-200/80 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl text-white ${isAdmin ? 'bg-slate-900' : 'bg-indigo-600'}`}>
                        {isAdmin ? <ShieldCheck className="w-5 h-5 text-emerald-400" /> : <Building2 className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900 tracking-tight">{u.displayName}</span>
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            isAdmin ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60' : 'bg-indigo-50 text-indigo-700 border border-indigo-200/60'
                          }`}>
                            {isAdmin ? 'Master Admin' : 'Client Login'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">{u.businessName}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[11px] font-mono text-slate-400">ID: {u.username}</span>
                          {!isAdmin && clientLicense?.status === 'active' && (
                            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200/60 flex items-center gap-0.5">
                              <CheckCircle2 className="w-2.5 h-2.5" /> Licensed
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {isCurrent ? (
                      <span className="flex items-center gap-1 text-xs font-bold text-indigo-600">
                        <CheckCircle className="w-4 h-4" /> Active
                      </span>
                    ) : (
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {activeTab === 'new_id' && (
            <form onSubmit={handleCreateClient} className="space-y-4 text-xs">
              <p className="text-slate-500">
                Register a new client business login ID for day-to-day invoicing across desktop &amp; mobile:
              </p>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Client Login ID / Username <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. sharma_enterprises"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono text-slate-900 font-bold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
                <p className="text-[10px] text-slate-400 mt-1">Used to log into the billing system</p>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Business / Company Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sharma Enterprises Pvt Ltd"
                  value={newBusinessName}
                  onChange={(e) => setNewBusinessName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-900 font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Contact / Representative Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Sharma"
                  value={newDisplayName}
                  onChange={(e) => setNewDisplayName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  Create Client Login ID &amp; Launch Billing
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-slate-400" />
            Responsive on Mobile &amp; Desktop
          </span>
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
