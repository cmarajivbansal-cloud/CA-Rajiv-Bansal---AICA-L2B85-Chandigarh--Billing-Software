import React from 'react';
import { SellerProfile, UserAccount } from '../types';
import { 
  Receipt, 
  Plus, 
  Users, 
  Package, 
  Settings, 
  ShieldCheck, 
  User, 
  ChevronDown, 
  Building2, 
  FileSpreadsheet,
  Layers,
  RotateCcw,
  Key,
  Award
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  currentUser: UserAccount;
  seller: SellerProfile;
  onOpenLoginModal: () => void;
  onResetData: () => void;
  onOpenActivationModal?: () => void;
  onOpenAicaModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  currentUser,
  seller,
  onOpenLoginModal,
  onResetData,
  onOpenActivationModal,
  onOpenAicaModal
}) => {
  const isAdmin = currentUser.role === 'admin';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo & Active Tenant */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('invoices')}
              className="flex items-center gap-2.5 text-left cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-sm group-hover:bg-indigo-600 transition-colors">
                <Receipt className="w-5 h-5 text-indigo-400 group-hover:text-white transition-colors" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-slate-900 tracking-tight">Tax Billing Suite</span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200/60 uppercase font-mono">
                    GST Ready
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium truncate max-w-[200px]">
                  {seller.businessName}
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onNavigate('invoices')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                currentView === 'invoices' || currentView === 'preview_invoice'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <Receipt className="w-4 h-4" />
              Invoices
            </button>

            <button
              onClick={() => onNavigate('clients')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                currentView === 'clients'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <Users className="w-4 h-4" />
              Clients
            </button>

            <button
              onClick={() => onNavigate('products')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                currentView === 'products'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <Package className="w-4 h-4" />
              Catalog
            </button>

            <button
              onClick={() => onNavigate('settings')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                currentView === 'settings'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <Settings className="w-4 h-4" />
              Seller Profile
            </button>

            {/* Admin Compliance Tab */}
            <button
              onClick={() => onNavigate('admin')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                currentView === 'admin'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold shadow-xs'
                  : 'text-emerald-700 hover:bg-emerald-50/80 hover:text-emerald-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Admin & Tax Excel
            </button>
          </nav>

          {/* Right Action & Account Switcher */}
          <div className="flex items-center gap-2.5">
            {onOpenAicaModal && (
              <button
                onClick={onOpenAicaModal}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-200 hover:border-sky-300 rounded-lg shadow-2xs transition-all cursor-pointer"
                title="Download Complete Code Files and AICA Level 2 Project Submission ZIP"
              >
                <Award className="w-4 h-4 text-sky-600" />
                <span className="hidden md:inline">Download Code / AICA (.ZIP)</span>
                <span className="md:hidden">Code (.ZIP)</span>
              </button>
            )}

            {!isAdmin && onOpenActivationModal && (
              <button
                onClick={onOpenActivationModal}
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
                title="View or Activate License Key"
              >
                <Key className="w-3.5 h-3.5 text-emerald-600" />
                <span>License Key</span>
              </button>
            )}

            <button
              onClick={() => onNavigate('create_invoice')}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Invoice</span>
              <span className="sm:hidden">Invoice</span>
            </button>

            {/* Active Account / Login Switcher Button */}
            <button
              onClick={onOpenLoginModal}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 hover:border-slate-300 rounded-xl transition-all cursor-pointer text-left shadow-2xs"
              title="Switch Account or Login"
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-white ${
                isAdmin ? 'bg-slate-900' : 'bg-indigo-600'
              }`}>
                {isAdmin ? <ShieldCheck className="w-4 h-4 text-emerald-400" /> : <User className="w-4 h-4" />}
              </div>
              <div className="hidden lg:block">
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-slate-800 truncate max-w-[130px]">
                    {currentUser.displayName}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </div>
                <span className="text-[10px] text-slate-500 font-mono block">
                  ID: {currentUser.username} ({isAdmin ? 'Admin' : 'Client'})
                </span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
