import React, { useState } from 'react';
import { ItemType, ProductServiceItem, SellerProfile, UnitType } from '../types';
import { GST_SLABS } from '../utils/taxCalculator';
import { formatCurrency } from '../utils/numberToWords';
import { Package, Plus, Search, Edit3, Trash2, Tag, Layers, CheckCircle } from 'lucide-react';

interface ProductCatalogProps {
  products: ProductServiceItem[];
  seller: SellerProfile;
  onSaveProduct: (product: ProductServiceItem) => void;
  onDeleteProduct: (productId: string) => void;
}

const COMMON_UNITS: UnitType[] = ['NOS', 'PCS', 'HRS', 'DAYS', 'MONTH', 'SET', 'BOX', 'KGS', 'MTR', 'SQFT', 'PKT'];

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  seller,
  onSaveProduct,
  onDeleteProduct
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductServiceItem | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<ItemType>('service');
  const [hsnSacCode, setHsnSacCode] = useState('998314');
  const [unit, setUnit] = useState<UnitType>('NOS');
  const [defaultUnitPrice, setDefaultUnitPrice] = useState<number>(1000);
  const [defaultGstRate, setDefaultGstRate] = useState<number>(18);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.hsnSacCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingProduct(null);
    setName('');
    setDescription('');
    setType('service');
    setHsnSacCode('998314');
    setUnit('NOS');
    setDefaultUnitPrice(1000);
    setDefaultGstRate(18);
    setIsEditing(true);
  };

  const handleOpenEdit = (p: ProductServiceItem) => {
    setEditingProduct(p);
    setName(p.name);
    setDescription(p.description || '');
    setType(p.type);
    setHsnSacCode(p.hsnSacCode);
    setUnit(p.unit);
    setDefaultUnitPrice(p.defaultUnitPrice);
    setDefaultGstRate(p.defaultGstRate);
    setIsEditing(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter a Product / Service title.');
      return;
    }

    const newProd: ProductServiceItem = {
      id: editingProduct?.id || `prod_${Date.now()}`,
      name,
      description,
      type,
      hsnSacCode,
      unit,
      defaultUnitPrice: Number(defaultUnitPrice) || 0,
      defaultGstRate: Number(defaultGstRate) || 0,
      ownerClientId: seller.id,
      createdAt: editingProduct?.createdAt || new Date().toISOString()
    };

    onSaveProduct(newProd);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-200/50">
              <Package className="w-5 h-5" />
            </div>
            Products &amp; Services Master Catalog
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure default item pricing, HSN / SAC statutory codes, units, and GST rates for instant 1-click billing
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm shadow-emerald-100 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add New Item / Service
        </button>
      </div>

      {/* Modal / Add Edit Drawer */}
      {isEditing && (
        <div className="bg-white p-6 rounded-xl border border-emerald-200 shadow-lg ring-1 ring-emerald-500/10">
          <form onSubmit={handleSave} className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-900">
                {editingProduct ? 'Edit Catalog Item' : 'Add New Item / Service'}
              </h2>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-xs font-medium text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="font-semibold text-slate-700 block mb-1">Item Title / Service Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Cloud Security Audit or Industrial Switch"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-semibold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Category Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as ItemType)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 cursor-pointer"
                >
                  <option value="service">Service (SAC)</option>
                  <option value="product">Goods / Product (HSN)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">HSN / SAC Code *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 998314 or 8536"
                  value={hsnSacCode}
                  onChange={(e) => setHsnSacCode(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-slate-900 font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Default Unit</label>
                <select
                  value={unit}
                  onChange={(e) => setUnit(e.target.value as UnitType)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 cursor-pointer"
                >
                  {COMMON_UNITS.map(u => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Default Rate ({seller.currencySymbol})</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={defaultUnitPrice}
                  onChange={(e) => setDefaultUnitPrice(parseFloat(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Default GST Rate</label>
                <select
                  value={defaultGstRate}
                  onChange={(e) => setDefaultGstRate(parseInt(e.target.value, 10))}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 cursor-pointer"
                >
                  {GST_SLABS.map(s => (
                    <option key={s} value={s}>{s}%</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="font-semibold text-slate-700 block mb-1">Description / Spec (Optional)</label>
                <input
                  type="text"
                  placeholder="Detailed specifications or service scope"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3.5 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm shadow-emerald-100 active:scale-[0.98] transition-all cursor-pointer"
              >
                Save Catalog Item
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search products & services by name, HSN/SAC code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
          />
        </div>
      </div>

      {/* Products Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProducts.map((prod) => (
          <div
            key={prod.id}
            className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-slate-300 hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                <div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    prod.type === 'service' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/50' : 'bg-amber-50 text-amber-700 border border-amber-200/50'
                  }`}>
                    {prod.type === 'service' ? 'Service (SAC)' : 'Product (HSN)'}
                  </span>
                  <h3 className="font-bold text-sm text-slate-900 mt-1.5 tracking-tight">{prod.name}</h3>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(prod)}
                    className="p-1 text-slate-400 hover:text-emerald-600 rounded-md hover:bg-emerald-50 transition-colors cursor-pointer"
                    title="Edit"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteProduct(prod.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {prod.description && (
                <p className="text-xs text-slate-500 mt-2.5 line-clamp-2">{prod.description}</p>
              )}

              <div className="mt-3.5 pt-2.5 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-semibold">HSN / SAC</span>
                  <span className="font-mono font-bold text-slate-800">{prod.hsnSacCode}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-semibold">GST Rate</span>
                  <span className="font-bold text-emerald-700">{prod.defaultGstRate}%</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Base Rate:</span>
              <span className="font-mono font-bold text-sm text-slate-900">
                {formatCurrency(prod.defaultUnitPrice, seller.currencySymbol)} / {prod.unit}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
