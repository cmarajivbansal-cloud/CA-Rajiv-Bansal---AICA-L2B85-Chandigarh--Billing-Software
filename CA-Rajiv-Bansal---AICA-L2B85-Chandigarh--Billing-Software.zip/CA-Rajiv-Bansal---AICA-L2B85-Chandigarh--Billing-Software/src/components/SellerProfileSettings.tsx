import React, { useState } from 'react';
import { BillingFormatConfig, SellerProfile, TemplateStyle } from '../types';
import { INDIAN_STATES } from '../utils/taxCalculator';
import { 
  Building2, 
  Save, 
  CheckCircle, 
  Lock, 
  Landmark, 
  FileText, 
  Image, 
  Upload, 
  Trash2, 
  Palette, 
  Sliders, 
  Eye, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface SellerProfileSettingsProps {
  seller: SellerProfile;
  onSave: (updatedSeller: SellerProfile) => void;
  isAdmin?: boolean;
}

const LOGO_PRESETS = [
  {
    name: 'Modern Tech & Cloud',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=160&auto=format&fit=crop&q=80'
  },
  {
    name: 'Retail & Commercial Store',
    url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=160&auto=format&fit=crop&q=80'
  },
  {
    name: 'Industrial & Hardware',
    url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=160&auto=format&fit=crop&q=80'
  },
  {
    name: 'Corporate & Advisory',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=160&auto=format&fit=crop&q=80'
  }
];

const DEFAULT_FORMAT: BillingFormatConfig = {
  templateStyle: 'modern-navy',
  documentTitle: 'TAX INVOICE',
  accentColor: '#0f172a',
  showLogo: true,
  logoHeight: 52,
  showHsnSac: true,
  showDiscount: true,
  showPoNumber: true,
  showBankDetails: true,
  showUpiQr: true,
  showSignatoryBox: true,
  showTerms: true,
  showNotes: true
};

export const SellerProfileSettings: React.FC<SellerProfileSettingsProps> = ({
  seller,
  onSave,
  isAdmin = false
}) => {
  const [formData, setFormData] = useState<SellerProfile>(() => ({
    ...seller,
    billingFormat: seller.billingFormat || DEFAULT_FORMAT
  }));
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'format' | 'logo'>('profile');

  const handleStateChange = (stateCode: string) => {
    const st = INDIAN_STATES[stateCode];
    if (st) {
      setFormData(prev => ({
        ...prev,
        state: st.name,
        stateCode: st.code,
      }));
    }
  };

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Please choose an image under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setFormData(prev => ({
            ...prev,
            logoUrl: result
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFormatChange = (field: keyof BillingFormatConfig, value: any) => {
    setFormData(prev => ({
      ...prev,
      billingFormat: {
        ...(prev.billingFormat || DEFAULT_FORMAT),
        [field]: value
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const currentFormat = formData.billingFormat || DEFAULT_FORMAT;

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
      {/* Top Banner */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200/50">
              <Building2 className="w-5 h-5" />
            </div>
            Business Firm &amp; Billing Format Settings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Fixed statutory firm variables (GSTIN, PAN, Bank) and customizable billing format with logo uploader.
          </p>
        </div>

        <button
          type="submit"
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Save className="w-4 h-4" />
          Save Settings
        </button>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'profile'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Lock className="w-3.5 h-3.5 text-indigo-600" />
          Fixed Statutory Firm Details
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('logo')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'logo'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Image className="w-3.5 h-3.5 text-indigo-600" />
          Business Logo ({formData.logoUrl ? 'Configured' : 'None'})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('format')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'format'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-indigo-600" />
          Billing Format &amp; Templates
        </button>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          Settings successfully saved! All future invoices will use this fixed profile and format.
        </div>
      )}

      {/* TAB 1: Fixed Statutory Firm Details */}
      {activeTab === 'profile' && (
        <div className="space-y-6">
          {/* Statutory Lock Banner */}
          <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-xl text-xs flex items-start gap-3">
            <div className="p-2 bg-amber-100 rounded-lg text-amber-800 shrink-0">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-amber-900 text-sm block">Fixed Statutory Variables</span>
              <p className="text-amber-800 mt-0.5 leading-relaxed">
                These seller variables (GSTIN, State Code, Legal Name, Registered Address, Bank Remittance) serve as the <strong>fixed fields</strong> across every invoice issued. Small business operators do not need to re-enter seller data each time.
              </p>
            </div>
          </div>

          {/* Business Identity & GST */}
          <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-600" />
              Company Identity &amp; Tax Registration (Fixed)
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Trade / Business Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-900 font-semibold focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Legal Registered Entity Name</label>
                <input
                  type="text"
                  value={formData.legalName}
                  onChange={(e) => setFormData({ ...formData, legalName: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  GSTIN (Goods and Services Tax ID) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold text-slate-900 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">PAN (Permanent Account Number)</label>
                <input
                  type="text"
                  value={formData.pan}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value.toUpperCase() })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono uppercase text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Business Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Business Phone / WhatsApp</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Registered Address */}
          <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-600" />
              Registered Principal Place of Business
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="font-semibold text-slate-700 block mb-1">Street Address Line 1</label>
                <input
                  type="text"
                  value={formData.addressLine1}
                  onChange={(e) => setFormData({ ...formData, addressLine1: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Address Line 2 (Optional)</label>
                <input
                  type="text"
                  value={formData.addressLine2 || ''}
                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">City</label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  State &amp; Code <span className="text-rose-500">*</span>
                </label>
                <select
                  value={formData.stateCode}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-semibold focus:border-indigo-500 cursor-pointer"
                >
                  {Object.values(INDIAN_STATES).map((st) => (
                    <option key={st.code} value={st.code}>
                      {st.code} - {st.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Postal PIN Code</label>
                <input
                  type="text"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono text-slate-800 focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Bank Details */}
          <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Landmark className="w-4 h-4 text-slate-600" />
              Bank Remittance &amp; UPI Transfer Details
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Bank Name</label>
                <input
                  type="text"
                  value={formData.bankDetails.bankName}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, bankName: e.target.value }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Account Holder Name</label>
                <input
                  type="text"
                  value={formData.bankDetails.accountHolder}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, accountHolder: e.target.value }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Account Number</label>
                <input
                  type="text"
                  value={formData.bankDetails.accountNumber}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, accountNumber: e.target.value }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono font-bold text-slate-900 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">IFSC / RTGS Code</label>
                <input
                  type="text"
                  value={formData.bankDetails.ifscCode}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, ifscCode: e.target.value.toUpperCase() }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono font-bold uppercase text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Branch Name</label>
                <input
                  type="text"
                  value={formData.bankDetails.branch}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, branch: e.target.value }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">UPI ID (VPA)</label>
                <input
                  type="text"
                  placeholder="e.g. company@upi"
                  value={formData.bankDetails.upiId || ''}
                  onChange={(e) => setFormData({
                    ...formData,
                    bankDetails: { ...formData.bankDetails, upiId: e.target.value }
                  })}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono text-indigo-700 font-medium focus:border-indigo-500"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Business Logo Uploader */}
      {activeTab === 'logo' && (
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-6 text-xs">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Image className="w-4 h-4 text-indigo-600" />
              Business Logo Settings
            </h2>
            <p className="text-slate-500 text-xs mt-0.5">
              Upload your company logo to appear on all printed and exported invoices.
            </p>
          </div>

          {/* Current Logo Preview */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-24 h-24 bg-white border border-slate-300 rounded-lg p-2 flex items-center justify-center overflow-hidden shadow-2xs">
                {formData.logoUrl ? (
                  <img
                    src={formData.logoUrl}
                    alt="Logo Preview"
                    style={{ maxHeight: `${currentFormat.logoHeight || 52}px` }}
                    className="object-contain"
                  />
                ) : (
                  <span className="text-[11px] text-slate-400 text-center">No Logo Set</span>
                )}
              </div>

              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {formData.logoUrl ? 'Active Business Logo' : 'Default Text Header'}
                </span>
                <span className="text-slate-500 text-[11px] block mt-0.5">
                  Display Height: <strong>{currentFormat.logoHeight || 52}px</strong>
                </span>
                {formData.logoUrl && (
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, logoUrl: '' })}
                    className="mt-2 text-xs font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove Logo
                  </button>
                )}
              </div>
            </div>

            {/* Height Slider */}
            {formData.logoUrl && (
              <div className="w-full sm:w-60 bg-white p-3 rounded-lg border border-slate-200">
                <label className="font-semibold text-slate-700 flex justify-between">
                  <span>Logo Print Height:</span>
                  <span className="font-mono text-indigo-700">{currentFormat.logoHeight || 52}px</span>
                </label>
                <input
                  type="range"
                  min={36}
                  max={96}
                  value={currentFormat.logoHeight || 52}
                  onChange={(e) => handleFormatChange('logoHeight', Number(e.target.value))}
                  className="w-full mt-2 cursor-pointer accent-indigo-600"
                />
              </div>
            )}
          </div>

          {/* Upload Method 1: File from Computer / Phone */}
          <div className="space-y-2">
            <label className="font-bold text-slate-800 block">
              Option 1: Upload from Computer or Mobile
            </label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 px-4 py-2.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 rounded-lg font-semibold cursor-pointer transition-colors shadow-2xs">
                <Upload className="w-4 h-4" />
                <span>Choose Image File (PNG, JPG, SVG)</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoFileUpload}
                  className="hidden"
                />
              </label>
              <span className="text-[11px] text-slate-400">Stored safely in local workspace</span>
            </div>
          </div>

          {/* Upload Method 2: Image URL */}
          <div className="space-y-1">
            <label className="font-bold text-slate-800 block">
              Option 2: Or Paste Direct Image URL
            </label>
            <input
              type="url"
              placeholder="https://example.com/logo.png"
              value={formData.logoUrl || ''}
              onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
              className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-mono text-xs focus:border-indigo-500"
            />
          </div>

          {/* Method 3: Curated Presets */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="font-bold text-slate-800 block">
              Option 3: Or Select a Standard Business Logo Preset
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {LOGO_PRESETS.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => setFormData({ ...formData, logoUrl: preset.url })}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-all cursor-pointer flex flex-col items-center text-center gap-2"
                >
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className="w-12 h-12 object-cover rounded shadow-2xs"
                  />
                  <span className="text-[10px] font-semibold text-slate-700 leading-tight">
                    {preset.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Billing Format & Template Configuration */}
      {activeTab === 'format' && (
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-6 text-xs">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-600" />
              Billing Format &amp; Invoicing Defaults
            </h2>
            <p className="text-slate-500 text-xs mt-0.5">
              Customize the visual layout, statutory document heading, and visible columns as per your business type.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Template Style */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Default Invoice Template Style
              </label>
              <select
                value={currentFormat.templateStyle}
                onChange={(e) => handleFormatChange('templateStyle', e.target.value as TemplateStyle)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-semibold focus:border-indigo-500 cursor-pointer"
              >
                <option value="modern-navy">Modern Navy (Professional Corporate)</option>
                <option value="classic-corporate">Classic Corporate (Formal GST Table)</option>
                <option value="clean-minimal">Clean Minimal (Services &amp; Consulting)</option>
                <option value="tax-compact">Tax Statutory Compact (High Item Density)</option>
                <option value="retail-pos">Retail &amp; Counter POS (Cash Memo / Shops)</option>
              </select>
            </div>

            {/* Document Title */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Printed Document Title
              </label>
              <select
                value={currentFormat.documentTitle}
                onChange={(e) => handleFormatChange('documentTitle', e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-semibold focus:border-indigo-500 cursor-pointer"
              >
                <option value="TAX INVOICE">TAX INVOICE (Standard GST Regulated)</option>
                <option value="RETAIL INVOICE / CASH MEMO">RETAIL INVOICE / CASH MEMO (Counter Sales)</option>
                <option value="BILL OF SUPPLY">BILL OF SUPPLY (Composition / Exempt)</option>
                <option value="PROFORMA INVOICE">PROFORMA INVOICE (Quotation / Estimate)</option>
                <option value="COMMERCIAL INVOICE">COMMERCIAL INVOICE</option>
              </select>
            </div>
          </div>

          {/* Display Checkbox Toggles */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <span className="font-bold text-slate-800 block">
              Format Display Preferences
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showLogo}
                  onChange={(e) => handleFormatChange('showLogo', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show Business Logo</span>
                  <span className="text-[11px] text-slate-500">Display company logo in header</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showHsnSac}
                  onChange={(e) => handleFormatChange('showHsnSac', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show HSN / SAC Codes</span>
                  <span className="text-[11px] text-slate-500">Statutory requirement for B2B GST bills</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showDiscount}
                  onChange={(e) => handleFormatChange('showDiscount', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show Discount Columns</span>
                  <span className="text-[11px] text-slate-500">Display item-level percentage discount</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showBankDetails}
                  onChange={(e) => handleFormatChange('showBankDetails', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show Bank Remittance &amp; UPI</span>
                  <span className="text-[11px] text-slate-500">Includes Bank, IFSC &amp; UPI VPA ID</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showSignatoryBox}
                  onChange={(e) => handleFormatChange('showSignatoryBox', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show Authorized Signatory Box</span>
                  <span className="text-[11px] text-slate-500">Stamp and signature placeholder</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={currentFormat.showTerms}
                  onChange={(e) => handleFormatChange('showTerms', e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="font-semibold text-slate-800 block">Show Terms &amp; Conditions</span>
                  <span className="text-[11px] text-slate-500">Standard business &amp; dispute terms</span>
                </div>
              </label>
            </div>
          </div>
        </div>
      )}
    </form>
  );
};
