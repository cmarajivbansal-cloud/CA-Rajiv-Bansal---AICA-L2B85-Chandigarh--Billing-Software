import React, { useState } from 'react';
import { UserAccount } from '../types';
import { LicenseManager } from '../utils/licenseManager';
import { Key, ShieldCheck, CheckCircle2, AlertCircle, Mail, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';

interface LicenseActivationModalProps {
  isOpen: boolean;
  currentUser: UserAccount;
  onClose: () => void;
  onLicenseUpdated: () => void;
}

export const LicenseActivationModal: React.FC<LicenseActivationModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onLicenseUpdated
}) => {
  const [licenseKeyInput, setLicenseKeyInput] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const currentLicense = LicenseManager.getLicenseByClientUserId(currentUser.id);

  const handleActivate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseKeyInput.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter a valid license key.' });
      return;
    }

    const res = LicenseManager.verifyAndActivateKey(licenseKeyInput.trim(), currentUser);
    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      try {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      } catch (e) {}
      onLicenseUpdated();
      setTimeout(() => {
        onClose();
      }, 2000);
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-xl text-white">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight">License Key &amp; Activation</h2>
              <p className="text-xs text-slate-400 mt-0.5">Statutory tax compliance authorization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-4 text-xs">
          {/* Current Status Card */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-slate-500">Current Status</span>
              {currentLicense?.status === 'active' ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-300">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Active License
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-300">
                  <AlertCircle className="w-3 h-3 text-amber-600" /> Demo / Unverified
                </span>
              )}
            </div>

            <div className="font-semibold text-slate-900 text-sm">{currentUser.businessName}</div>
            {currentLicense ? (
              <div className="space-y-0.5 pt-1 text-slate-600 border-t border-slate-200/80">
                <p>Key: <span className="font-mono font-bold text-indigo-700">{currentLicense.licenseKey}</span></p>
                <p>Edition: <span className="capitalize font-semibold text-slate-800">{currentLicense.tier} Suite</span></p>
                <p>Valid Through: <span className="font-medium text-slate-800">{currentLicense.validUntil}</span></p>
                <p className="text-[11px] text-slate-500">Issued by: {currentLicense.issuedBy}</p>
              </div>
            ) : (
              <p className="text-slate-500 text-[11px] pt-1 border-t border-slate-200/80">
                You are currently in demo mode. Activate your license key received via email from CMA Rajiv Bansal.
              </p>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleActivate} className="space-y-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Enter License Key received by Email:
              </label>
              <input
                type="text"
                required
                placeholder="e.g. GST-PRO-8491-3029-APEX"
                value={licenseKeyInput}
                onChange={(e) => setLicenseKeyInput(e.target.value.toUpperCase())}
                className="w-full bg-white border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                License keys are issued and emailed by Master Admin CMA Rajiv Bansal.
              </p>
            </div>

            {statusMessage && (
              <div
                className={`p-3 rounded-lg border text-xs flex items-center gap-2 ${
                  statusMessage.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                    : 'bg-rose-50 text-rose-800 border-rose-300'
                }`}
              >
                {statusMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{statusMessage.text}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              Verify &amp; Activate License
            </button>
          </form>

          {/* Help Contact Banner */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-slate-600 space-y-1 text-[11px]">
            <span className="font-bold text-slate-700 flex items-center gap-1">
              <Mail className="w-3.5 h-3.5 text-slate-500" />
              Need a license key or renewal?
            </span>
            <p>
              Please contact the tax compliance administrator:
            </p>
            <div className="font-medium text-slate-800">
              CMA Rajiv Bansal &bull; <a href="mailto:CMARAJIVBANSAL@gmail.com" className="text-indigo-600 hover:underline">CMARAJIVBANSAL@gmail.com</a>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 p-3.5 border-t border-slate-100 text-right">
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
