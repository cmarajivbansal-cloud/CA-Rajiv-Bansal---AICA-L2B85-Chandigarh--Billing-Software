import React, { useState } from 'react';
import { Invoice } from '../types';
import { formatCurrency } from '../utils/numberToWords';
import { Share2, Mail, MessageSquare, Copy, Check, ExternalLink, QrCode } from 'lucide-react';

interface QuickShareModalProps {
  isOpen: boolean;
  invoice: Invoice | null;
  onClose: () => void;
}

export const QuickShareModal: React.FC<QuickShareModalProps> = ({
  isOpen,
  invoice,
  onClose
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !invoice) return null;

  const { seller, buyer } = invoice;

  const invoiceSummaryText = `*Tax Invoice Details*
*Invoice No:* ${invoice.invoiceNumber}
*Date:* ${invoice.invoiceDate}
*From:* ${seller.businessName} (GSTIN: ${seller.gstin})
*To:* ${buyer.companyName || buyer.name}
*Amount Due:* ${formatCurrency(invoice.grandTotal, seller.currencySymbol)}
*Due Date:* ${invoice.dueDate}

*Bank Payment Details:*
Bank: ${seller.bankDetails.bankName}
A/c No: ${seller.bankDetails.accountNumber}
IFSC: ${seller.bankDetails.ifscCode}
${seller.bankDetails.upiId ? `UPI ID: ${seller.bankDetails.upiId}` : ''}

Thank you for your business!`;

  const whatsappUrl = `https://wa.me/${buyer.phone?.replace(/[^0-9]/g, '') || ''}?text=${encodeURIComponent(invoiceSummaryText)}`;

  const mailtoUrl = `mailto:${buyer.email || ''}?subject=${encodeURIComponent(
    `Tax Invoice ${invoice.invoiceNumber} from ${seller.businessName}`
  )}&body=${encodeURIComponent(invoiceSummaryText)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(invoiceSummaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-sm shadow-indigo-950/30">
                <Share2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold tracking-tight">Share Tax Invoice</h2>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  {invoice.invoiceNumber} &bull; {formatCurrency(invoice.grandTotal, seller.currencySymbol)}
                </p>
              </div>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-white text-sm cursor-pointer">✕</button>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-4 text-xs">
          {/* Quick Channels */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 bg-emerald-50/70 hover:bg-emerald-50 border border-emerald-200/80 rounded-xl flex flex-col items-center justify-center text-center gap-1.5 active:scale-[0.98] transition-all cursor-pointer"
            >
              <div className="p-2 bg-emerald-600 text-white rounded-full shadow-xs">
                <MessageSquare className="w-4 h-4" />
              </div>
              <span className="font-bold text-emerald-900 tracking-tight">Send WhatsApp</span>
              <span className="text-[10px] text-emerald-700">{buyer.phone || 'Direct text'}</span>
            </a>

            <a
              href={mailtoUrl}
              className="p-3.5 bg-indigo-50/70 hover:bg-indigo-50 border border-indigo-200/80 rounded-xl flex flex-col items-center justify-center text-center gap-1.5 active:scale-[0.98] transition-all cursor-pointer"
            >
              <div className="p-2 bg-indigo-600 text-white rounded-full shadow-xs">
                <Mail className="w-4 h-4" />
              </div>
              <span className="font-bold text-indigo-900 tracking-tight">Email Invoice</span>
              <span className="text-[10px] text-indigo-700">{buyer.email || 'Draft client email'}</span>
            </a>
          </div>

          {/* Copy Raw text summary */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-semibold text-slate-700">Payment &amp; Invoice Summary Text</label>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied to Clipboard!' : 'Copy Text'}
              </button>
            </div>
            <textarea
              readOnly
              rows={7}
              value={invoiceSummaryText}
              className="w-full p-3 bg-slate-50/80 border border-slate-200 rounded-lg text-slate-700 font-mono text-[11px] leading-relaxed select-all focus:outline-hidden"
            />
          </div>
        </div>

        <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
