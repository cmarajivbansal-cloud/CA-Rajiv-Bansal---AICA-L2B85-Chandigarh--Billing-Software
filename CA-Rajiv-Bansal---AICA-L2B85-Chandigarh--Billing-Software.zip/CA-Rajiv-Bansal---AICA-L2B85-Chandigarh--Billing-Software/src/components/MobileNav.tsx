import React from 'react';
import { 
  Receipt, 
  Plus, 
  Users, 
  Package, 
  Settings, 
  ShieldCheck 
} from 'lucide-react';

interface MobileNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isAdmin: boolean;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentView,
  onNavigate,
  isAdmin
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-1.5 shadow-lg print:hidden">
      <div className="flex items-center justify-around">
        <button
          onClick={() => onNavigate('invoices')}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition-colors ${
            currentView === 'invoices' || currentView === 'preview_invoice'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Receipt className="w-5 h-5 mb-0.5" />
          <span>Invoices</span>
        </button>

        <button
          onClick={() => onNavigate('clients')}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition-colors ${
            currentView === 'clients' ? 'text-indigo-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>Clients</span>
        </button>

        {/* Center Floating Plus Button for Mobile Fast Invoicing */}
        <button
          onClick={() => onNavigate('create_invoice')}
          className="flex flex-col items-center -mt-5"
          title="New Invoice"
        >
          <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-200 border-2 border-white hover:bg-indigo-700 active:scale-95 transition-all">
            <Plus className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-bold text-indigo-700 mt-0.5">New Bill</span>
        </button>

        <button
          onClick={() => onNavigate('products')}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition-colors ${
            currentView === 'products' ? 'text-indigo-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Package className="w-5 h-5 mb-0.5" />
          <span>Catalog</span>
        </button>

        <button
          onClick={() => onNavigate(isAdmin ? 'admin' : 'settings')}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition-colors ${
            currentView === 'settings' || currentView === 'admin'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          {isAdmin ? <ShieldCheck className="w-5 h-5 mb-0.5 text-emerald-600" /> : <Settings className="w-5 h-5 mb-0.5" />}
          <span>{isAdmin ? 'Admin' : 'Profile'}</span>
        </button>
      </div>
    </div>
  );
};
