import React, { useState } from 'react';
import { Invoice, SellerProfile, UserAccount } from '../types';
import { exportTaxComplianceExcel } from '../utils/excelGenerator';
import { formatCurrency } from '../utils/numberToWords';
import { AdminLicenseManager } from './AdminLicenseManager';
import { AICA_SUBMISSION_FILES, downloadAicaSubmissionZip, downloadCodebaseZip } from '../utils/aicaZipGenerator';
import { 
  ShieldCheck, 
  FileSpreadsheet, 
  Building2, 
  Download, 
  TrendingUp, 
  Users, 
  Receipt, 
  Calendar, 
  CheckCircle, 
  Clock, 
  ArrowRight,
  ExternalLink,
  Layers,
  Database,
  FileCheck2,
  Lock,
  Sparkles,
  Key,
  Mail,
  Award,
  Code2
} from 'lucide-react';

interface AdminTaxComplianceProps {
  invoices: Invoice[];
  sellerProfiles: SellerProfile[];
  users: UserAccount[];
  currentUser: UserAccount;
  onSwitchClient: (sellerId: string) => void;
  onViewInvoice: (invoice: Invoice) => void;
}

export const AdminTaxCompliance: React.FC<AdminTaxComplianceProps> = ({
  invoices,
  sellerProfiles,
  users,
  currentUser,
  onSwitchClient,
  onViewInvoice
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-08');
  const [adminTab, setAdminTab] = useState<'compliance' | 'licenses' | 'master_login' | 'aica_dossier'>('compliance');
  const [isZipping, setIsZipping] = useState(false);

  // Filter invoices for selected period
  const periodInvoices = invoices.filter(inv => inv.invoiceDate.startsWith(selectedMonth));
  const allInvoices = invoices;

  // Aggregate Metrics Across ALL Clients
  const totalGrossTurnover = allInvoices.reduce((acc, i) => acc + i.grandTotal, 0);
  const totalTaxable = allInvoices.reduce((acc, i) => acc + i.totalTaxableAmount, 0);
  const totalCgst = allInvoices.reduce((acc, i) => acc + i.cgstTotal, 0);
  const totalSgst = allInvoices.reduce((acc, i) => acc + i.sgstTotal, 0);
  const totalIgst = allInvoices.reduce((acc, i) => acc + i.igstTotal, 0);
  const totalTaxLiability = totalCgst + totalSgst + totalIgst;
  const totalPaidRevenue = allInvoices
    .filter(i => i.status === 'paid')
    .reduce((acc, i) => acc + i.grandTotal, 0);
  const totalOutstanding = allInvoices
    .filter(i => i.status === 'issued' || i.status === 'overdue')
    .reduce((acc, i) => acc + i.grandTotal, 0);

  // Group invoices by seller
  const sellerStats = sellerProfiles.map(profile => {
    const clientInvoices = allInvoices.filter(inv => inv.createdByClientId === profile.id);
    const clientTurnover = clientInvoices.reduce((acc, i) => acc + i.grandTotal, 0);
    const clientTax = clientInvoices.reduce((acc, i) => acc + i.totalTax, 0);
    const paidCount = clientInvoices.filter(i => i.status === 'paid').length;

    return {
      profile,
      invoices: clientInvoices,
      turnover: clientTurnover,
      tax: clientTax,
      totalCount: clientInvoices.length,
      paidCount
    };
  });

  // Export Master Consolidated Excel across all clients
  const handleExportMasterExcel = () => {
    exportTaxComplianceExcel(
      allInvoices,
      undefined,
      'CONSOLIDATED_MASTER_TAX_COMPLIANCE_GSTR1_AUDIT'
    );
  };

  // Export Specific Client Excel
  const handleExportClientExcel = (profile: SellerProfile, clientInvoices: Invoice[]) => {
    exportTaxComplianceExcel(
      clientInvoices,
      profile,
      `GSTR1_Compliance_${profile.businessName.replace(/[^a-zA-Z0-9]/g, '_')}`
    );
  };

  return (
    <div className="space-y-6">
      {/* Admin Header Banner */}
      <div className="bg-slate-900 text-white p-6 sm:p-7 rounded-2xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-semibold uppercase tracking-wider mb-2">
            <div className="p-1 bg-emerald-950/80 rounded border border-emerald-800/50">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
            Tax Compliance Officer &amp; CA Admin Portal
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Statutory Audit &amp; Backend Excel Master Records
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl mt-1.5 leading-relaxed">
            Centralized tax administration for all managed client billing IDs. Download GSTR-1, HSN Summary, and Sales Registers for direct GST portal upload and statutory compliance.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportMasterExcel}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-xl shadow-md shadow-emerald-950/20 active:scale-[0.98] transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-900" />
            Download Master Tax Excel (.xlsx)
          </button>
        </div>
      </div>

      {/* Admin Module Sub-Tabs */}
      <div className="flex gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs">
        <button
          onClick={() => setAdminTab('compliance')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            adminTab === 'compliance'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          Tax Registers &amp; Backend Excel
        </button>

        <button
          onClick={() => setAdminTab('licenses')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            adminTab === 'licenses'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Key className="w-4 h-4 text-indigo-600" />
          Client Licensing &amp; Email Dispatch
        </button>

        <button
          onClick={() => setAdminTab('master_login')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            adminTab === 'master_login'
              ? 'bg-white text-slate-900 shadow-xs font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="w-4 h-4 text-amber-600" />
          Master Login &amp; CA Profile
        </button>

        <button
          onClick={() => setAdminTab('aica_dossier')}
          className={`flex-1 py-2 px-3 rounded-lg font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            adminTab === 'aica_dossier'
              ? 'bg-sky-600 text-white shadow-xs font-bold'
              : 'text-sky-700 bg-sky-50/70 hover:bg-sky-100/70 font-semibold'
          }`}
        >
          <Award className="w-4 h-4 text-sky-300" />
          AICA Level 2 Submission (.ZIP)
        </button>
      </div>

      {/* TAB 1: Compliance & Excel Records */}
      {adminTab === 'compliance' && (
        <div className="space-y-6">

      {/* High-Level Consolidated Tax Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-medium text-slate-500 flex items-center justify-between">
            Consolidated Gross Turnover
            <Building2 className="w-4 h-4 text-slate-400" />
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 mt-2">
            {formatCurrency(totalGrossTurnover, '₹')}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Across {allInvoices.length} invoices ({sellerProfiles.length} clients)</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-medium text-indigo-700 flex items-center justify-between">
            Total Output Tax Liability
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </span>
          <div className="text-xl font-bold font-mono text-indigo-900 mt-2">
            {formatCurrency(totalTaxLiability, '₹')}
          </div>
          <span className="text-[11px] text-indigo-600 mt-1 block">
            CGST: {formatCurrency(totalCgst, '₹')} | SGST: {formatCurrency(totalSgst, '₹')} | IGST: {formatCurrency(totalIgst, '₹')}
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-medium text-emerald-700 flex items-center justify-between">
            Total Realized Collections
            <CheckCircle className="w-4 h-4 text-emerald-500" />
          </span>
          <div className="text-xl font-bold font-mono text-emerald-900 mt-2">
            {formatCurrency(totalPaidRevenue, '₹')}
          </div>
          <span className="text-[11px] text-emerald-600 mt-1 block">Settled via NEFT / UPI / Bank</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-medium text-amber-700 flex items-center justify-between">
            Receivables Pending
            <Clock className="w-4 h-4 text-amber-500" />
          </span>
          <div className="text-xl font-bold font-mono text-amber-900 mt-2">
            {formatCurrency(totalOutstanding, '₹')}
          </div>
          <span className="text-[11px] text-amber-600 mt-1 block">Unpaid client invoices</span>
        </div>
      </div>

      {/* Client Accounts & Direct Excel Downloads */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-600" />
              Client Businesses &amp; Backend Filing Vault
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Access each client's individual backend accounting database, export GSTR-1 sheets, or switch into their billing workspace
            </p>
          </div>

          <span className="text-xs font-mono font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
            {sellerProfiles.length} Active Billing Entities
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sellerStats.map(({ profile, invoices: clientInvoices, turnover, tax, totalCount, paidCount }) => (
            <div
              key={profile.id}
              className="bg-slate-50/70 p-4 sm:p-5 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-200/80">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 tracking-tight">{profile.businessName}</h3>
                    <p className="text-[11px] font-mono text-slate-500 mt-0.5">GSTIN: {profile.gstin}</p>
                  </div>
                  <span className="text-[10px] font-semibold px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-700">
                    {profile.state} ({profile.stateCode})
                  </span>
                </div>

                <div className="mt-3 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Total Billed:</span>
                    <span className="font-mono font-bold text-slate-900">{formatCurrency(turnover, '₹')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">GST Collected:</span>
                    <span className="font-mono font-semibold text-indigo-700">{formatCurrency(tax, '₹')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Invoices Issued:</span>
                    <span className="font-semibold text-slate-800">{totalCount} ({paidCount} Paid)</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-200/80">
                    <span>A/c: {profile.bankDetails.bankName}</span>
                    <span className="font-mono">...{profile.bankDetails.accountNumber.slice(-4)}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleExportClientExcel(profile, clientInvoices)}
                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200 rounded-lg active:scale-[0.98] transition-all cursor-pointer"
                  title="Export GSTR-1 Excel for this Client"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  GSTR-1 Excel
                </button>

                <button
                  onClick={() => onSwitchClient(profile.id)}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span>Open</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Statutory Invoices Stream */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-slate-700" />
              Master Audit Log &amp; Cross-Client Invoicing Ledger
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Real-time audit stream of all transactions issued across systems</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="p-3 pl-4">Invoice No</th>
                <th className="p-3">Seller Business</th>
                <th className="p-3">Buyer Customer</th>
                <th className="p-3">POS</th>
                <th className="p-3 text-right">Taxable</th>
                <th className="p-3 text-right">Tax</th>
                <th className="p-3 text-right font-bold">Total</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 pr-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {allInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3 pl-4 font-mono font-bold text-indigo-700">
                    <button
                      onClick={() => onViewInvoice(inv)}
                      className="hover:underline text-left cursor-pointer"
                    >
                      {inv.invoiceNumber}
                    </button>
                  </td>
                  <td className="p-3 font-medium text-slate-900">
                    {inv.seller.businessName}
                  </td>
                  <td className="p-3 text-slate-700">
                    {inv.buyer.companyName || inv.buyer.name}
                  </td>
                  <td className="p-3 text-slate-500">
                    {inv.buyer.placeOfSupply || inv.buyer.billingAddress.state}
                  </td>
                  <td className="p-3 text-right font-mono text-slate-700">
                    {formatCurrency(inv.totalTaxableAmount, '₹')}
                  </td>
                  <td className="p-3 text-right font-mono text-slate-600">
                    {formatCurrency(inv.totalTax, '₹')}
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900">
                    {formatCurrency(inv.grandTotal, '₹')}
                  </td>
                  <td className="p-3 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                      inv.status === 'paid'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                        : inv.status === 'issued'
                        ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60'
                        : inv.status === 'overdue'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                        : 'bg-amber-50 text-amber-700 border border-amber-200/60'
                    }`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="p-3 pr-4 text-right">
                    <button
                      onClick={() => onViewInvoice(inv)}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )}

  {/* TAB 2: Licensing & Email Dispatch */}
  {adminTab === 'licenses' && (
    <AdminLicenseManager
      users={users}
      sellerProfiles={sellerProfiles}
      onSelectClient={onSwitchClient}
    />
  )}

  {/* TAB 3: Master Login & CA Authority Profile */}
  {adminTab === 'master_login' && (
    <div className="bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/80 shadow-xs space-y-6 max-w-3xl">
      <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
        <div className="p-2.5 bg-slate-900 text-emerald-400 rounded-xl">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Master Administrator &amp; Statutory Authority Profile
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Sole master login authority for license key generation, client onboarding, and tax compliance audit.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Practitioner Name</span>
          <span className="text-sm font-bold text-slate-900 block">CMA Rajiv Bansal</span>
          <span className="text-indigo-700 font-medium">Cost &amp; Management Accountant (FCMA)</span>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Official Dispatch Email</span>
          <span className="text-sm font-bold text-indigo-700 font-mono block">CMARAJIVBANSAL@gmail.com</span>
          <span className="text-slate-500">Verified master sender for client license keys</span>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Master System Login ID</span>
          <span className="text-sm font-bold font-mono text-slate-900 block">admin</span>
          <span className="text-emerald-700 font-semibold">Master Super-Admin Access Granted</span>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Statutory Audit Jurisdiction</span>
          <span className="text-sm font-bold text-slate-900 block">Goods &amp; Services Tax (GST)</span>
          <span className="text-slate-500">GSTR-1, GSTR-3B, Tax Liability &amp; HSN Audit</span>
        </div>
      </div>

      <div className="p-4 bg-emerald-50/70 border border-emerald-200/80 rounded-xl text-xs space-y-2">
        <div className="flex items-center gap-2 text-emerald-900 font-bold">
          <Lock className="w-4 h-4 text-emerald-700" />
          <span>Master Security &amp; Access Rights</span>
        </div>
        <p className="text-emerald-800 leading-relaxed text-[11px]">
          As Master Admin, you have immutable rights to switch between client accounts, generate cryptographic license keys, send activation notices via email, download raw sales data in Excel, and preserve firm variables to prevent fraudulent tax filing.
        </p>
      </div>
    </div>
  )}

  {/* TAB 4: AICA Level 2 Project Submission Dossier */}
  {adminTab === 'aica_dossier' && (
    <div className="space-y-6">
      {/* Dossier Header Card */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-3 bg-sky-600 rounded-xl text-white shadow-md shadow-sky-950/40">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold uppercase tracking-wider bg-sky-500/20 text-sky-300 px-2.5 py-0.5 rounded border border-sky-400/30">
                  AICA Level 2 Certificate Course
                </span>
                <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> 100% Complete &amp; Verified
                </span>
              </div>
              <h2 className="text-xl font-bold tracking-tight text-white mt-1.5">
                Official Capstone Project Submission Package (.ZIP)
              </h2>
              <p className="text-xs text-slate-300 mt-1">
                Candidate: <strong>CMA Rajiv Bansal</strong> &bull; Email: <span className="text-sky-300 font-mono">CMARAJIVBANSAL@gmail.com</span>
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0">
            <button
              onClick={async () => {
                setIsZipping(true);
                try {
                  await downloadCodebaseZip();
                } catch (e) {
                  console.error(e);
                  alert('Download failed. Please retry.');
                } finally {
                  setIsZipping(false);
                }
              }}
              disabled={isZipping}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-950/30 transition-all cursor-pointer disabled:opacity-60"
              title="Download full project source code files as a ZIP folder"
            >
              <Code2 className="w-4 h-4 text-emerald-200" />
              {isZipping ? 'Packing ZIP...' : 'Download Code Files (.ZIP)'}
            </button>

            <button
              onClick={async () => {
                setIsZipping(true);
                try {
                  await downloadAicaSubmissionZip();
                } catch (e) {
                  console.error(e);
                  alert('Download failed. Please retry.');
                } finally {
                  setIsZipping(false);
                }
              }}
              disabled={isZipping}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-3 bg-sky-600 hover:bg-sky-700 active:scale-[0.98] text-white font-bold text-xs rounded-xl shadow-lg shadow-sky-950/30 transition-all cursor-pointer disabled:opacity-60"
              title="Download AICA Level 2 Capstone Submission Dossier"
            >
              <Award className="w-4 h-4 text-sky-200" />
              {isZipping ? 'Packing ZIP...' : 'Download AICA Project (.ZIP)'}
            </button>
          </div>
        </div>

        {/* 5 Required Structure Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mt-6 pt-5 border-t border-slate-800 text-xs">
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-sky-300 font-bold uppercase tracking-wider block">Requirement 1</span>
            <span className="font-bold text-white mt-1 block">Project Summary Document</span>
            <span className="text-[11px] text-slate-400">PDF-ready HTML &amp; Markdown</span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider block">Requirement 2</span>
            <span className="font-bold text-white mt-1 block">Prompt File(s)</span>
            <span className="text-[11px] text-slate-400">5 Systemic Prompt Specs</span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider block">Requirement 3</span>
            <span className="font-bold text-white mt-1 block">Example File(s)</span>
            <span className="text-[11px] text-slate-400">B2B/B2C Invoices &amp; GSTR CSV</span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider block">Requirement 4</span>
            <span className="font-bold text-white mt-1 block">Executable File(s)</span>
            <span className="text-[11px] text-slate-400">Live App URL, npm &amp; scripts</span>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
            <span className="text-[10px] text-rose-300 font-bold uppercase tracking-wider block">Requirement 5</span>
            <span className="font-bold text-white mt-1 block">Supporting Documents</span>
            <span className="text-[11px] text-slate-400">GST Slabs, State Codes, Manifest</span>
          </div>
        </div>
      </div>

      {/* Structured File Manifest Grid */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Verified Submission File Inventory (All 20 Enclosed Files)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              All files are properly named, structured in compliance with AICA Level 2 guidelines, and compiled into the single ZIP package.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
            Archive: AICA_Level_2_Project_CMA_Rajiv_Bansal.zip
          </span>
        </div>

        <div className="divide-y divide-slate-100 max-h-[420px] overflow-y-auto pr-1">
          {AICA_SUBMISSION_FILES.map((item, i) => (
            <div key={i} className="py-2.5 flex items-start justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5">
                <span className="text-slate-400 font-mono text-[11px] mt-0.5 w-5">{i + 1}.</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900">{item.filename}</span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-slate-500 text-[11px] mt-0.5 leading-relaxed">{item.description}</p>
                </div>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded shrink-0">
                Included in ZIP
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )}
</div>
);
};
