import React, { useState } from 'react';
import { ClientBuyer, SellerProfile } from '../types';
import { INDIAN_STATES } from '../utils/taxCalculator';
import { Users, Plus, Search, Edit3, Trash2, Building2, Mail, Phone, MapPin, CheckCircle } from 'lucide-react';

interface ClientMasterProps {
  clients: ClientBuyer[];
  seller: SellerProfile;
  onSaveClient: (client: ClientBuyer) => void;
  onDeleteClient: (clientId: string) => void;
}

export const ClientMaster: React.FC<ClientMasterProps> = ({
  clients,
  seller,
  onSaveClient,
  onDeleteClient
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editingClient, setEditingClient] = useState<ClientBuyer | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [gstin, setGstin] = useState('');
  const [pan, setPan] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [stateCode, setStateCode] = useState('07');
  const [pincode, setPincode] = useState('');

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.gstin?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.billingAddress.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingClient(null);
    setName('');
    setCompanyName('');
    setGstin('');
    setPan('');
    setEmail('');
    setPhone('');
    setAddressLine1('');
    setCity('');
    setStateCode(seller.stateCode || '07');
    setPincode('');
    setIsEditing(true);
  };

  const handleOpenEdit = (c: ClientBuyer) => {
    setEditingClient(c);
    setName(c.name);
    setCompanyName(c.companyName);
    setGstin(c.gstin || '');
    setPan(c.pan || '');
    setEmail(c.email);
    setPhone(c.phone);
    setAddressLine1(c.billingAddress.addressLine1);
    setCity(c.billingAddress.city);
    setStateCode(c.billingAddress.stateCode || '07');
    setPincode(c.billingAddress.pincode);
    setIsEditing(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName.trim() && !name.trim()) {
      alert('Please specify Company Name or Contact Name.');
      return;
    }

    const stateObj = INDIAN_STATES[stateCode] || { code: stateCode, name: 'Delhi' };

    const newClient: ClientBuyer = {
      id: editingClient?.id || `client_${Date.now()}`,
      name: name || companyName,
      companyName: companyName || name,
      gstin: gstin.toUpperCase(),
      pan: pan.toUpperCase(),
      email,
      phone,
      billingAddress: {
        addressLine1: addressLine1 || 'Billing Address',
        city: city || 'City',
        state: stateObj.name,
        stateCode: stateObj.code,
        pincode: pincode || '000000',
        country: 'India'
      },
      placeOfSupply: `${stateObj.name} (${stateObj.code})`,
      ownerClientId: seller.id,
      createdAt: editingClient?.createdAt || new Date().toISOString()
    };

    onSaveClient(newClient);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200/50">
              <Users className="w-5 h-5" />
            </div>
            Client &amp; Buyer Directory Master
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Store recurring customer billing addresses, GSTIN numbers, and contact records
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add New Client
        </button>
      </div>

      {/* Modal / Add Edit Drawer */}
      {isEditing && (
        <div className="bg-white p-6 rounded-xl border border-indigo-200 shadow-lg ring-1 ring-indigo-500/10">
          <form onSubmit={handleSave} className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-900">
                {editingClient ? 'Edit Client Details' : 'Add New Client / Buyer'}
              </h2>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-xs font-medium text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Company / Business Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Acme Enterprises Ltd"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Contact Person Name</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Buyer GSTIN / Tax ID</label>
                <input
                  type="text"
                  placeholder="e.g. 27AAACZ1122K1Z5"
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono uppercase text-slate-900 font-bold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="billing@client.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Phone Number</label>
                <input
                  type="text"
                  placeholder="+91 98000 00000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Buyer State &amp; Code *</label>
                <select
                  value={stateCode}
                  onChange={(e) => setStateCode(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                >
                  {Object.values(INDIAN_STATES).map((st) => (
                    <option key={st.code} value={st.code}>
                      {st.code} - {st.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="font-semibold text-slate-700 block mb-1">Billing Street Address</label>
                <input
                  type="text"
                  placeholder="Office #, Complex Name, Street"
                  value={addressLine1}
                  onChange={(e) => setAddressLine1(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">City &amp; PIN</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="City"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-1/2 bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                  <input
                    type="text"
                    placeholder="Pincode"
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    className="w-1/2 bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-mono focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3.5 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
              >
                Save Client Record
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search clients by company name, contact, GSTIN, city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>
      </div>

      {/* Clients Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.map((client) => (
          <div
            key={client.id}
            className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-slate-300 hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 tracking-tight">{client.companyName}</h3>
                  {client.name && client.name !== client.companyName && (
                    <p className="text-xs text-slate-500 mt-0.5">Attn: {client.name}</p>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(client)}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded-md hover:bg-indigo-50 transition-colors cursor-pointer"
                    title="Edit"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteClient(client.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="mt-3.5 space-y-2 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-700">GSTIN:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {client.gstin || <span className="font-normal text-slate-400 font-sans">Unregistered</span>}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{client.billingAddress.city}, {client.billingAddress.state}</span>
                </div>

                {client.email && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{client.email}</span>
                  </div>
                )}

                {client.phone && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{client.phone}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>POS: {client.placeOfSupply || client.billingAddress.state}</span>
              <span className="font-semibold text-indigo-600">Ready for Billing</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
