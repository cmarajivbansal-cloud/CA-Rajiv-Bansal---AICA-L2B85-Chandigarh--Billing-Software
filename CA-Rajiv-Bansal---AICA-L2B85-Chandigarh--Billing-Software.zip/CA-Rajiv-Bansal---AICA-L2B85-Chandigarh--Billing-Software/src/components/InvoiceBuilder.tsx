import React, { useState, useEffect } from 'react';
import { 
  ClientBuyer, 
  Invoice, 
  InvoiceLineItem, 
  ProductServiceItem, 
  SellerProfile, 
  TemplateStyle, 
  UnitType 
} from '../types';
import { calculateInvoiceTotals, calculateLineItem, GST_SLABS, INDIAN_STATES } from '../utils/taxCalculator';
import { numberToIndianWords, formatCurrency } from '../utils/numberToWords';
import { ModernNavyTemplate } from './Templates/ModernNavyTemplate';
import { ClassicCorporateTemplate } from './Templates/ClassicCorporateTemplate';
import { CleanMinimalTemplate } from './Templates/CleanMinimalTemplate';
import { TaxCompactTemplate } from './Templates/TaxCompactTemplate';
import { 
  Plus, 
  Trash2, 
  Save, 
  Eye, 
  Printer, 
  Building2, 
  UserCheck, 
  Package, 
  Receipt, 
  Sparkles, 
  Lock, 
  HelpCircle, 
  Check, 
  FileSpreadsheet, 
  ArrowLeft,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface InvoiceBuilderProps {
  seller: SellerProfile;
  clients: ClientBuyer[];
  products: ProductServiceItem[];
  initialInvoice?: Invoice | null;
  onSaveInvoice: (invoice: Invoice, andPreview?: boolean) => void;
  onCancel: () => void;
}

const COMMON_UNITS: UnitType[] = ['NOS', 'PCS', 'HRS', 'DAYS', 'MONTH', 'SET', 'BOX', 'KGS', 'MTR', 'SQFT', 'PKT'];

export const InvoiceBuilder: React.FC<InvoiceBuilderProps> = ({
  seller,
  clients,
  products,
  initialInvoice,
  onSaveInvoice,
  onCancel
}) => {
  // Mode: form or live preview split/tab
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [isSellerCollapsed, setIsSellerCollapsed] = useState(true);

  // Form states
  const [invoiceNumber, setInvoiceNumber] = useState(
    initialInvoice?.invoiceNumber || `${seller.invoicePrefix}${String(seller.nextInvoiceNumber).padStart(3, '0')}`
  );
  const [invoiceDate, setInvoiceDate] = useState(
    initialInvoice?.invoiceDate || new Date().toISOString().split('T')[0]
  );
  const [dueDate, setDueDate] = useState(
    initialInvoice?.dueDate || new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [poNumber, setPoNumber] = useState(initialInvoice?.poNumber || '');
  const [templateStyle, setTemplateStyle] = useState<TemplateStyle>(initialInvoice?.templateStyle || 'modern-navy');
  const [notes, setNotes] = useState(initialInvoice?.notes || seller.defaultNotes || '');
  const [terms, setTerms] = useState(initialInvoice?.termsAndConditions || seller.defaultTerms || '');
  const [status, setStatus] = useState<Invoice['status']>(initialInvoice?.status || 'issued');

  // Client Selection / Entry
  const [selectedClientId, setSelectedClientId] = useState<string>(initialInvoice?.buyer?.id || (clients[0]?.id || ''));
  const [buyerName, setBuyerName] = useState(initialInvoice?.buyer?.name || clients[0]?.name || '');
  const [buyerCompany, setBuyerCompany] = useState(initialInvoice?.buyer?.companyName || clients[0]?.companyName || '');
  const [buyerGstin, setBuyerGstin] = useState(initialInvoice?.buyer?.gstin || clients[0]?.gstin || '');
  const [buyerEmail, setBuyerEmail] = useState(initialInvoice?.buyer?.email || clients[0]?.email || '');
  const [buyerPhone, setBuyerPhone] = useState(initialInvoice?.buyer?.phone || clients[0]?.phone || '');
  const [buyerAddress, setBuyerAddress] = useState(initialInvoice?.buyer?.billingAddress?.addressLine1 || clients[0]?.billingAddress?.addressLine1 || '');
  const [buyerCity, setBuyerCity] = useState(initialInvoice?.buyer?.billingAddress?.city || clients[0]?.billingAddress?.city || '');
  const [buyerState, setBuyerState] = useState(initialInvoice?.buyer?.billingAddress?.state || clients[0]?.billingAddress?.state || 'Delhi');
  const [buyerStateCode, setBuyerStateCode] = useState(initialInvoice?.buyer?.billingAddress?.stateCode || clients[0]?.billingAddress?.stateCode || '07');
  const [buyerPincode, setBuyerPincode] = useState(initialInvoice?.buyer?.billingAddress?.pincode || clients[0]?.billingAddress?.pincode || '110001');

  // Line items
  const [items, setItems] = useState<InvoiceLineItem[]>(() => {
    if (initialInvoice?.items?.length) {
      return initialInvoice.items;
    }
    // Default initial line item
    return [
      calculateLineItem({
        id: 'item_init_1',
        productId: products[0]?.id,
        description: products[0]?.name || 'Professional Services',
        hsnSacCode: products[0]?.hsnSacCode || '998314',
        quantity: 1,
        unit: products[0]?.unit || 'NOS',
        unitPrice: products[0]?.defaultUnitPrice || 5000,
        discountPercent: 0,
        gstRate: products[0]?.defaultGstRate || 18,
      }, seller.stateCode !== (clients[0]?.billingAddress?.stateCode || '07'))
    ];
  });

  // Check if Inter-State supply (IGST) or Intra-State (CGST + SGST)
  const isInterState = (seller.stateCode || '').trim() !== (buyerStateCode || '').trim();

  // Handle Client selection change
  const handleClientChange = (clientId: string) => {
    setSelectedClientId(clientId);
    if (clientId === 'custom_new') {
      setBuyerName('');
      setBuyerCompany('');
      setBuyerGstin('');
      setBuyerEmail('');
      setBuyerPhone('');
      setBuyerAddress('');
      setBuyerCity('');
      setBuyerState(seller.state);
      setBuyerStateCode(seller.stateCode);
      setBuyerPincode('');
      return;
    }

    const c = clients.find(cl => cl.id === clientId);
    if (c) {
      setBuyerName(c.name);
      setBuyerCompany(c.companyName || '');
      setBuyerGstin(c.gstin || '');
      setBuyerEmail(c.email || '');
      setBuyerPhone(c.phone || '');
      setBuyerAddress(c.billingAddress.addressLine1 || '');
      setBuyerCity(c.billingAddress.city || '');
      setBuyerState(c.billingAddress.state || '');
      setBuyerStateCode(c.billingAddress.stateCode || '');
      setBuyerPincode(c.billingAddress.pincode || '');

      // Recalculate items for new state logic
      const newIsInterState = seller.stateCode !== c.billingAddress.stateCode;
      setItems(prevItems => prevItems.map(it => calculateLineItem(it, newIsInterState)));
    }
  };

  // Handle manual GSTIN change to auto-detect State & State Code
  const handleGstinChange = (newGstin: string) => {
    setBuyerGstin(newGstin);
    if (newGstin.length >= 2) {
      const code = newGstin.substring(0, 2);
      const stateObj = INDIAN_STATES[code];
      if (stateObj) {
        setBuyerState(stateObj.name);
        setBuyerStateCode(stateObj.code);
        const newIsInterState = seller.stateCode !== stateObj.code;
        setItems(prev => prev.map(it => calculateLineItem(it, newIsInterState)));
      }
    }
  };

  // Handle State dropdown change
  const handleStateChange = (code: string) => {
    const stateObj = INDIAN_STATES[code];
    if (stateObj) {
      setBuyerState(stateObj.name);
      setBuyerStateCode(stateObj.code);
      const newIsInterState = seller.stateCode !== stateObj.code;
      setItems(prev => prev.map(it => calculateLineItem(it, newIsInterState)));
    }
  };

  // Add Item from Catalog or Blank
  const handleAddItem = (product?: ProductServiceItem) => {
    const newItem = calculateLineItem({
      id: `item_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      productId: product?.id,
      description: product?.name || '',
      hsnSacCode: product?.hsnSacCode || '998314',
      quantity: 1,
      unit: product?.unit || 'NOS',
      unitPrice: product?.defaultUnitPrice || 1000,
      discountPercent: 0,
      gstRate: product?.defaultGstRate ?? 18,
    }, isInterState);

    setItems([...items, newItem]);
  };

  // Update line item property
  const handleItemChange = (index: number, field: keyof InvoiceLineItem, value: any) => {
    const updated = [...items];
    const current = { ...updated[index], [field]: value };
    
    // If selecting a product from dropdown
    if (field === 'productId') {
      const prod = products.find(p => p.id === value);
      if (prod) {
        current.description = prod.name;
        current.hsnSacCode = prod.hsnSacCode;
        current.unit = prod.unit;
        current.unitPrice = prod.defaultUnitPrice;
        current.gstRate = prod.defaultGstRate;
      }
    }

    updated[index] = calculateLineItem(current, isInterState);
    setItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) {
      alert('Invoice must contain at least one line item.');
      return;
    }
    setItems(items.filter((_, idx) => idx !== index));
  };

  // Totals
  const totals = calculateInvoiceTotals(items);
  const amountInWords = numberToIndianWords(totals.grandTotal, seller.currency);

  // Construct current preview invoice object
  const currentInvoiceData: Invoice = {
    id: initialInvoice?.id || `inv_${Date.now()}`,
    invoiceNumber,
    invoiceDate,
    dueDate,
    status,
    poNumber,
    seller,
    buyer: {
      id: selectedClientId === 'custom_new' ? `buyer_${Date.now()}` : selectedClientId,
      name: buyerName || 'Client Name',
      companyName: buyerCompany || buyerName || 'Client Company',
      gstin: buyerGstin,
      email: buyerEmail,
      phone: buyerPhone,
      billingAddress: {
        addressLine1: buyerAddress || 'Billing Address',
        city: buyerCity || 'City',
        state: buyerState,
        stateCode: buyerStateCode,
        pincode: buyerPincode || '000000',
        country: 'India'
      },
      placeOfSupply: `${buyerState} (${buyerStateCode})`,
      ownerClientId: seller.id,
      createdAt: new Date().toISOString()
    },
    items,
    subTotal: totals.subTotal,
    totalDiscount: totals.totalDiscount,
    totalTaxableAmount: totals.totalTaxableAmount,
    isInterState,
    cgstTotal: totals.cgstTotal,
    sgstTotal: totals.sgstTotal,
    igstTotal: totals.igstTotal,
    totalTax: totals.totalTax,
    roundOff: totals.roundOff,
    grandTotal: totals.grandTotal,
    amountInWords,
    notes,
    termsAndConditions: terms,
    templateStyle,
    createdByClientId: seller.id,
    createdAt: initialInvoice?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const handleSubmit = (andPreview: boolean = false) => {
    if (!invoiceNumber.trim()) {
      alert('Please provide an Invoice Number.');
      return;
    }
    if (!buyerCompany.trim() && !buyerName.trim()) {
      alert('Please provide Client / Buyer Company Name or Contact Name.');
      return;
    }
    if (items.some(it => !it.description.trim() || it.quantity <= 0)) {
      alert('Please fill description and positive quantity for all items.');
      return;
    }

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch (e) {
      // Confetti fallback
    }

    onSaveInvoice(currentInvoiceData, andPreview);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <div className="p-1.5 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200/50">
                <Receipt className="w-4 h-4" />
              </div>
              {initialInvoice ? `Edit Invoice: ${initialInvoice.invoiceNumber}` : 'Create New Tax Invoice'}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Issuing for: <span className="font-semibold text-slate-700">{seller.businessName}</span> (GSTIN: <span className="font-mono">{seller.gstin}</span>)
            </p>
          </div>
        </div>

        {/* View mode toggle & Save buttons */}
        <div className="flex items-center gap-2">
          {/* Tab Switcher */}
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              onClick={() => setActiveTab('edit')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'edit'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Invoice Form
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'preview'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Live Preview
            </button>
          </div>

          <button
            onClick={() => handleSubmit(false)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs active:scale-[0.98] transition-all cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            Save Invoice
          </button>

          <button
            onClick={() => handleSubmit(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Save &amp; View / Print
          </button>
        </div>
      </div>

      {/* Main Content Area: Editor or Live Preview */}
      {activeTab === 'preview' ? (
        <div className="space-y-4">
          <div className="bg-indigo-50/70 border border-indigo-200/80 text-indigo-900 p-3 rounded-lg text-xs flex justify-between items-center">
            <span className="font-medium">Viewing Live Formatted Template Preview. Switch back to Form to make edits.</span>
            <div className="flex items-center gap-2">
              <span className="font-semibold">Template:</span>
              <select
                value={templateStyle}
                onChange={(e) => setTemplateStyle(e.target.value as TemplateStyle)}
                className="bg-white border border-indigo-300 text-xs rounded px-2 py-1 font-medium cursor-pointer"
              >
                <option value="modern-navy">Modern Navy</option>
                <option value="classic-corporate">Classic Corporate</option>
                <option value="clean-minimal">Clean Minimal</option>
                <option value="tax-compact">Tax Statutory Compact</option>
              </select>
            </div>
          </div>

          {templateStyle === 'modern-navy' && <ModernNavyTemplate invoice={currentInvoiceData} />}
          {templateStyle === 'classic-corporate' && <ClassicCorporateTemplate invoice={currentInvoiceData} />}
          {templateStyle === 'clean-minimal' && <CleanMinimalTemplate invoice={currentInvoiceData} />}
          {templateStyle === 'tax-compact' && <TaxCompactTemplate invoice={currentInvoiceData} />}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Core Invoice Form */}
          <div className="lg:col-span-8 space-y-6">

            {/* SECTION 1: Seller Details (Fixed variables preset) */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-slate-100 rounded-lg text-slate-700">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Seller / Biller Profile (Fixed Master)</h2>
                    <p className="text-[11px] text-slate-500">Fixed variables locked for day-to-day billing consistency</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    <Lock className="w-3 h-3" /> Configured &amp; Validated
                  </span>
                  <button
                    onClick={() => setIsSellerCollapsed(!isSellerCollapsed)}
                    className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    title="Toggle details"
                  >
                    {isSellerCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {isSellerCollapsed ? (
                <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-semibold">Business</span>
                    <span className="font-bold text-slate-900 truncate block">{seller.businessName}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-semibold">GSTIN</span>
                    <span className="font-mono font-semibold text-slate-900">{seller.gstin}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-semibold">State / Code</span>
                    <span className="font-medium">{seller.state} ({seller.stateCode})</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-semibold">Bank A/c</span>
                    <span className="font-mono text-slate-900">{seller.bankDetails.bankName} (...{seller.bankDetails.accountNumber.slice(-4)})</span>
                  </div>
                </div>
              ) : (
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Company / Legal Name</label>
                    <input
                      type="text"
                      disabled
                      value={seller.businessName}
                      className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 text-slate-800 font-semibold cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Seller GSTIN</label>
                    <input
                      type="text"
                      disabled
                      value={seller.gstin}
                      className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 font-mono text-slate-800 font-bold cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">State &amp; State Code</label>
                    <input
                      type="text"
                      disabled
                      value={`${seller.state} (Code: ${seller.stateCode})`}
                      className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 text-slate-800 cursor-not-allowed"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Registered Address</label>
                    <input
                      type="text"
                      disabled
                      value={`${seller.addressLine1}, ${seller.city} - ${seller.pincode}`}
                      className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 text-slate-700 cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Bank Remittance</label>
                    <input
                      type="text"
                      disabled
                      value={`${seller.bankDetails.bankName} | A/c ${seller.bankDetails.accountNumber}`}
                      className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 text-slate-700 font-mono cursor-not-allowed"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* SECTION 2: Client / Buyer Details (Fillable Variables) */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-100 gap-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Client / Buyer Details (Fillable)</h2>
                    <p className="text-[11px] text-slate-500">Pick from existing client master or enter new client</p>
                  </div>
                </div>

                {/* Fast Client Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-600">Select Client:</span>
                  <select
                    value={selectedClientId}
                    onChange={(e) => handleClientChange(e.target.value)}
                    className="text-xs bg-slate-50 border border-slate-300 rounded-lg py-1.5 px-2.5 font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 cursor-pointer"
                  >
                    {clients.map((cl) => (
                      <option key={cl.id} value={cl.id}>
                        {cl.companyName || cl.name} ({cl.billingAddress.state})
                      </option>
                    ))}
                    <option value="custom_new">+ Enter New Client / Ad-hoc</option>
                  </select>
                </div>
              </div>

              {/* Inter-state vs Intra-state GST indicator banner */}
              <div className={`p-2.5 rounded-lg text-xs flex items-center justify-between ${
                isInterState 
                  ? 'bg-purple-50/80 border border-purple-200 text-purple-900' 
                  : 'bg-emerald-50/80 border border-emerald-200 text-emerald-900'
              }`}>
                <div className="flex items-center gap-2">
                  <span className="font-bold uppercase tracking-wider text-[10px] px-1.5 py-0.5 rounded bg-white/90 border border-current">
                    {isInterState ? 'Inter-State Supply' : 'Intra-State Supply'}
                  </span>
                  <span>
                    Seller: <strong className="font-semibold">{seller.state} ({seller.stateCode})</strong> &rarr; Buyer: <strong className="font-semibold">{buyerState} ({buyerStateCode})</strong>
                  </span>
                </div>
                <span className="font-semibold text-[11px]">
                  {isInterState ? 'IGST Applicable' : 'CGST + SGST (50/50) Applicable'}
                </span>
              </div>

              {/* Fillable Client Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    Client / Company Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Zenith Logistics Ltd"
                    value={buyerCompany}
                    onChange={(e) => setBuyerCompany(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    Client GSTIN / Tax ID <span className="text-slate-400 font-normal">(Auto-detects State)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 27AAACZ1122K1Z5"
                    value={buyerGstin}
                    onChange={(e) => handleGstinChange(e.target.value.toUpperCase())}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono uppercase text-slate-900 font-bold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    Contact Person Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Vikram Singhania"
                    value={buyerName}
                    onChange={(e) => setBuyerName(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="accounts@client.com"
                    value={buyerEmail}
                    onChange={(e) => setBuyerEmail(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+91 98000 00000"
                    value={buyerPhone}
                    onChange={(e) => setBuyerPhone(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    Buyer State &amp; Code <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={buyerStateCode}
                    onChange={(e) => handleStateChange(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                  >
                    {Object.values(INDIAN_STATES).map((st) => (
                      <option key={st.code} value={st.code}>
                        {st.code} - {st.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Billing Street Address</label>
                  <input
                    type="text"
                    placeholder="Flat / Floor, Building Name, Street Area"
                    value={buyerAddress}
                    onChange={(e) => setBuyerAddress(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">City &amp; Pincode</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="City"
                      value={buyerCity}
                      onChange={(e) => setBuyerCity(e.target.value)}
                      className="w-1/2 bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                    />
                    <input
                      type="text"
                      placeholder="PIN"
                      value={buyerPincode}
                      onChange={(e) => setBuyerPincode(e.target.value)}
                      className="w-1/2 bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-mono focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION 3: Products & Services Line Items */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-100 gap-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-emerald-50 rounded-lg text-emerald-600">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Products &amp; Services Details</h2>
                    <p className="text-[11px] text-slate-500">Add items from your catalog or enter custom lines</p>
                  </div>
                </div>

                {/* Quick Add Buttons */}
                <div className="flex items-center gap-2">
                  {products.length > 0 && (
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          const p = products.find(prod => prod.id === e.target.value);
                          if (p) handleAddItem(p);
                          e.target.value = '';
                        }
                      }}
                      defaultValue=""
                      className="text-xs bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-lg py-1.5 px-2 font-medium cursor-pointer"
                    >
                      <option value="" disabled>+ Quick Add From Catalog</option>
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({seller.currencySymbol}{p.defaultUnitPrice} | {p.defaultGstRate}%)
                        </option>
                      ))}
                    </select>
                  )}

                  <button
                    type="button"
                    onClick={() => handleAddItem()}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Custom Line
                  </button>
                </div>
              </div>

              {/* Items Table / Responsive Item Cards */}
              <div className="space-y-3">
                {items.map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/60 hover:bg-slate-50 space-y-3 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <input
                            type="text"
                            placeholder="Item description / Service title (e.g. Cloud App Development)"
                            value={item.description}
                            onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                            className="flex-1 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                          />
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Remove Item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Numerical Controls: HSN, Qty, Unit, Price, Discount, Tax Rate */}
                    <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">HSN/SAC</label>
                        <input
                          type="text"
                          placeholder="e.g. 998314"
                          value={item.hsnSacCode}
                          onChange={(e) => handleItemChange(idx, 'hsnSacCode', e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800 font-mono focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Qty</label>
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', parseFloat(e.target.value) || 0)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-900 font-bold font-mono focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Unit</label>
                        <select
                          value={item.unit}
                          onChange={(e) => handleItemChange(idx, 'unit', e.target.value as UnitType)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800 font-medium focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                        >
                          {COMMON_UNITS.map(u => (
                            <option key={u} value={u}>{u}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Rate ({seller.currencySymbol})</label>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(idx, 'unitPrice', parseFloat(e.target.value) || 0)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-900 font-bold font-mono focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Disc %</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={item.discountPercent}
                          onChange={(e) => handleItemChange(idx, 'discountPercent', parseFloat(e.target.value) || 0)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800 font-mono focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">GST Rate</label>
                        <select
                          value={item.gstRate}
                          onChange={(e) => handleItemChange(idx, 'gstRate', parseInt(e.target.value, 10))}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800 font-semibold focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                        >
                          {GST_SLABS.map(slab => (
                            <option key={slab} value={slab}>{slab}%</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Calculated Line Totals preview badge */}
                    <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between text-[11px] text-slate-600">
                      <div className="space-x-3">
                        <span>Taxable: <strong className="font-mono text-slate-800">{formatCurrency(item.taxableAmount, seller.currencySymbol)}</strong></span>
                        {isInterState ? (
                          <span>IGST ({item.igstRate}%): <strong className="font-mono text-slate-800">{formatCurrency(item.igstAmount, seller.currencySymbol)}</strong></span>
                        ) : (
                          <span>CGST+SGST ({item.gstRate}%): <strong className="font-mono text-slate-800">{formatCurrency(item.cgstAmount + item.sgstAmount, seller.currencySymbol)}</strong></span>
                        )}
                      </div>
                      <div className="font-bold text-slate-900">
                        Line Total: <span className="font-mono text-xs text-indigo-700 font-bold">{formatCurrency(item.totalAmount, seller.currencySymbol)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SECTION 4: Terms & Special Notes */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Terms &amp; Conditions</label>
                <textarea
                  rows={4}
                  value={terms}
                  onChange={(e) => setTerms(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-mono leading-relaxed focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  placeholder="Terms of payment, interest on delayed payment, jurisdiction, etc."
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Special Notes / Payment Remarks</label>
                <textarea
                  rows={4}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 leading-relaxed focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  placeholder="Thank you note, payment reference directions, or delivery notes."
                />
              </div>
            </div>

          </div>

          {/* Right Column: Meta Info, Calculations, Template selector */}
          <div className="lg:col-span-4 space-y-6">

            {/* Invoice Meta Settings */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-3.5 text-xs">
              <h2 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
                Invoice Metadata &amp; Numbering
              </h2>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Invoice Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
                <p className="text-[10px] text-slate-400 mt-0.5">Auto-sequenced from seller prefix</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Invoice Date</label>
                  <input
                    type="date"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Due Date</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">PO / Reference Number</label>
                <input
                  type="text"
                  placeholder="e.g. PO-2026-99"
                  value={poNumber}
                  onChange={(e) => setPoNumber(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-mono focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as Invoice['status'])}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                >
                  <option value="issued">Issued / Unpaid</option>
                  <option value="paid">Paid in Full</option>
                  <option value="draft">Draft (Unsent)</option>
                  <option value="overdue">Overdue</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Printable Template Style</label>
                <select
                  value={templateStyle}
                  onChange={(e) => setTemplateStyle(e.target.value as TemplateStyle)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                >
                  <option value="modern-navy">Modern Navy Theme</option>
                  <option value="classic-corporate">Classic Corporate</option>
                  <option value="clean-minimal">Clean Minimalist</option>
                  <option value="tax-compact">Tax Statutory Compact</option>
                </select>
              </div>
            </div>

            {/* Calculations Summary Card */}
            <div className="bg-slate-900 text-white p-5 rounded-xl shadow-lg border border-slate-800 space-y-3 text-xs font-mono">
              <h2 className="text-sm font-sans font-bold text-slate-200 pb-2 border-b border-slate-800 flex justify-between items-center">
                <span>Tax &amp; Totals Breakdown</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-indigo-400 font-semibold">
                  {isInterState ? 'IGST' : 'CGST+SGST'}
                </span>
              </h2>

              <div className="flex justify-between text-slate-400">
                <span>Subtotal (Gross):</span>
                <span>{formatCurrency(totals.subTotal, seller.currencySymbol)}</span>
              </div>

              {totals.totalDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Total Discount:</span>
                  <span>-{formatCurrency(totals.totalDiscount, seller.currencySymbol)}</span>
                </div>
              )}

              <div className="flex justify-between font-semibold text-slate-200 border-t border-slate-800 pt-2">
                <span>Taxable Value:</span>
                <span>{formatCurrency(totals.totalTaxableAmount, seller.currencySymbol)}</span>
              </div>

              {isInterState ? (
                <div className="flex justify-between text-slate-300">
                  <span>Integrated Tax (IGST):</span>
                  <span>{formatCurrency(totals.igstTotal, seller.currencySymbol)}</span>
                </div>
              ) : (
                <>
                  <div className="flex justify-between text-slate-300">
                    <span>Central Tax (CGST):</span>
                    <span>{formatCurrency(totals.cgstTotal, seller.currencySymbol)}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>State Tax (SGST):</span>
                    <span>{formatCurrency(totals.sgstTotal, seller.currencySymbol)}</span>
                  </div>
                </>
              )}

              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Total Tax Output:</span>
                <span>{formatCurrency(totals.totalTax, seller.currencySymbol)}</span>
              </div>

              {totals.roundOff !== 0 && (
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Round Off:</span>
                  <span>{totals.roundOff > 0 ? `+${totals.roundOff}` : totals.roundOff}</span>
                </div>
              )}

              <div className="flex justify-between text-base font-bold text-white border-t-2 border-slate-700 pt-3">
                <span className="font-sans">Grand Total:</span>
                <span className="text-emerald-400">{formatCurrency(totals.grandTotal, seller.currencySymbol)}</span>
              </div>

              {/* Amount in Words */}
              <div className="pt-2 border-t border-slate-800 text-[10px] font-sans text-slate-300 italic">
                <span className="text-slate-500 font-semibold block uppercase not-italic text-[9px]">Amount in Words:</span>
                {amountInWords}
              </div>

              {/* Action Trigger */}
              <div className="pt-4 space-y-2">
                <button
                  type="button"
                  onClick={() => handleSubmit(true)}
                  className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 font-sans font-bold text-white text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm shadow-indigo-900/50 active:scale-[0.98] cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Save &amp; Print / Save PDF
                </button>
                <button
                  type="button"
                  onClick={() => handleSubmit(false)}
                  className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 font-sans font-semibold text-slate-300 text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 active:scale-[0.98] cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  Save as Draft / Invoices List
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
