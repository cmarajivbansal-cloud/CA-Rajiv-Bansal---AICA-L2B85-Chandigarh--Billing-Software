import React, { useState } from 'react';
import { ClientLicense, LicenseTier, SellerProfile, UserAccount } from '../types';
import { LicenseManager } from '../utils/licenseManager';
import { LicenseEmailModal } from './LicenseEmailModal';
import { 
  Key, 
  Mail, 
  Plus, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Search, 
  Copy, 
  Check, 
  Send, 
  RotateCcw,
  Sparkles,
  Lock,
  Building2,
  Users
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AdminLicenseManagerProps {
  users: UserAccount[];
  sellerProfiles: SellerProfile[];
  onOpenEmailModal?: (license: ClientLicense) => void;
}

export const AdminLicenseManager: React.FC<AdminLicenseManagerProps> = ({
  users,
  sellerProfiles,
  onOpenEmailModal
}) => {
  const [licenses, setLicenses] = useState<ClientLicense[]>(() => LicenseManager.getLicenses());
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  // Email modal
  const [emailTargetLicense, setEmailTargetLicense] = useState<ClientLicense | null>(null);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

  // New License Generator Form modal/drawer
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [selectedUserForLicense, setSelectedUserForLicense] = useState<string>(users.find(u => u.role === 'client')?.id || '');
  const [customBusinessName, setCustomBusinessName] = useState('');
  const [customClientEmail, setCustomClientEmail] = useState('');
  const [selectedTier, setSelectedTier] = useState<LicenseTier>('professional');
  const [validityMonths, setValidityMonths] = useState<number>(12);
  const [licenseNotes, setLicenseNotes] = useState('');

  const refreshLicenses = () => {
    setLicenses(LicenseManager.getLicenses());
  };

  const handleCopyKey = (license: ClientLicense) => {
    navigator.clipboard.writeText(license.licenseKey);
    setCopiedKeyId(license.id);
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  const handleOpenEmail = (license: ClientLicense) => {
    setEmailTargetLicense(license);
    setIsEmailModalOpen(true);
    if (onOpenEmailModal) onOpenEmailModal(license);
  };

  const handleToggleStatus = (license: ClientLicense) => {
    const nextStatus = license.status === 'active' ? 'suspended' : 'active';
    LicenseManager.updateLicenseStatus(license.id, nextStatus);
    refreshLicenses();
  };

  const handleRenewOneYear = (license: ClientLicense) => {
    const currentExp = new Date(license.validUntil);
    const baseDate = currentExp > new Date() ? currentExp : new Date();
    baseDate.setFullYear(baseDate.getFullYear() + 1);
    
    const all = LicenseManager.getLicenses();
    const item = all.find(l => l.id === license.id);
    if (item) {
      item.validUntil = baseDate.toISOString().split('T')[0];
      item.status = 'active';
      LicenseManager.saveLicenses(all);
      refreshLicenses();
      alert(`License for ${license.businessName} extended to ${item.validUntil}!`);
    }
  };

  const handleGenerateLicense = (e: React.FormEvent) => {
    e.preventDefault();

    let clientUserId = selectedUserForLicense;
    let clientUsername = '';
    let businessName = customBusinessName;
    let clientEmail = customClientEmail;

    if (selectedUserForLicense !== 'new_external') {
      const u = users.find(usr => usr.id === selectedUserForLicense);
      if (u) {
        clientUserId = u.id;
        clientUsername = u.username;
        businessName = businessName || u.businessName;
        clientEmail = clientEmail || u.email;
      }
    } else {
      clientUsername = businessName.toLowerCase().replace(/[^a-z0-9]/g, '_');
      clientUserId = `client_${Date.now()}`;
    }

    if (!businessName.trim() || !clientEmail.trim()) {
      alert('Please fill in business name and client email.');
      return;
    }

    const newLic = LicenseManager.issueLicense({
      clientUserId,
      clientUsername: clientUsername || 'client',
      businessName,
      clientEmail,
      tier: selectedTier,
      validityMonths,
      notes: licenseNotes
    });

    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
    } catch (e) {}

    refreshLicenses();
    setIsGeneratorOpen(false);

    // Prompt to email immediately
    setEmailTargetLicense(newLic);
    setIsEmailModalOpen(true);
  };

  // Filtered licenses
  const filtered = licenses.filter(lic => {
    const matchesSearch = 
      lic.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lic.licenseKey.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lic.clientEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lic.clientUsername.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTier = tierFilter === 'all' || lic.tier === tierFilter;
    return matchesSearch && matchesTier;
  });

  const activeCount = licenses.filter(l => l.status === 'active').length;
  const proCount = licenses.filter(l => l.tier === 'professional').length;

  return (
    <div className="space-y-6">
      {/* Master Admin Header Banner */}
      <div className="bg-slate-900 text-white p-6 sm:p-7 rounded-2xl shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-semibold uppercase tracking-wider mb-2">
            <div className="p-1 bg-emerald-950 rounded border border-emerald-800">
              <Key className="w-3.5 h-3.5" />
            </div>
            Master Admin Licensing &amp; Client Rights Authority
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Client Licensing &amp; Email Key Distribution
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl mt-1.5 leading-relaxed">
            Manage billing access rights, issue tamper-proof GST license keys, and email official activation certificates directly to client businesses from Master Admin <strong className="text-white">CMA Rajiv Bansal (CMARAJIVBANSAL@gmail.com)</strong>.
          </p>
        </div>

        <button
          onClick={() => setIsGeneratorOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-xl shadow-md shadow-emerald-950/20 active:scale-[0.98] transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 text-slate-900" />
          Generate &amp; Email New Key
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="font-semibold text-slate-500 flex items-center justify-between">
            Total Client Licenses
            <Building2 className="w-4 h-4 text-slate-400" />
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1.5">{licenses.length}</div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Managed client firms</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="font-semibold text-emerald-700 flex items-center justify-between">
            Active Verified
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </span>
          <div className="text-xl font-bold font-mono text-emerald-800 mt-1.5">{activeCount}</div>
          <span className="text-[11px] text-emerald-600 mt-0.5 block">Full invoicing rights</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="font-semibold text-indigo-700 flex items-center justify-between">
            Professional &amp; Audit Suite
            <ShieldCheck className="w-4 h-4 text-indigo-500" />
          </span>
          <div className="text-xl font-bold font-mono text-indigo-800 mt-1.5">{proCount}</div>
          <span className="text-[11px] text-indigo-600 mt-0.5 block">Excel GSTR-1 enabled</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="font-semibold text-slate-700 flex items-center justify-between">
            Email Delivery Ready
            <Mail className="w-4 h-4 text-slate-500" />
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1.5">
            {licenses.filter(l => !!l.lastEmailSentAt).length} / {licenses.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Keys dispatched via email</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search license key, business name, email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 font-medium">Tier:</span>
          <select
            value={tierFilter}
            onChange={(e) => setTierFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-slate-800 font-medium focus:bg-white focus:border-indigo-500 cursor-pointer"
          >
            <option value="all">All Tiers</option>
            <option value="starter">Starter Suite</option>
            <option value="professional">Professional GST Suite</option>
            <option value="enterprise">Enterprise Multi-Branch</option>
          </select>
        </div>
      </div>

      {/* Licenses Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-600" />
              Issued Master License Registry
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Click &quot;Email License Key&quot; to send official email kit to the client
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200">
                <th className="p-3.5 pl-4">Client Business</th>
                <th className="p-3.5">License Key</th>
                <th className="p-3.5">Tier / Edition</th>
                <th className="p-3.5">Validity Period</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5">Email Status</th>
                <th className="p-3.5 pr-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((lic) => {
                const isCopied = copiedKeyId === lic.id;
                const isExpired = new Date(lic.validUntil) < new Date();

                return (
                  <tr key={lic.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 pl-4">
                      <div className="font-bold text-slate-900">{lic.businessName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        Login ID: <span className="font-semibold text-slate-700">{lic.clientUsername}</span> &bull; {lic.clientEmail}
                      </div>
                    </td>

                    <td className="p-3.5 font-mono">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-indigo-700 bg-indigo-50/60 px-2 py-1 rounded border border-indigo-100 select-all">
                          {lic.licenseKey}
                        </span>
                        <button
                          onClick={() => handleCopyKey(lic)}
                          className="p-1 text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer"
                          title="Copy Key to Clipboard"
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        lic.tier === 'enterprise'
                          ? 'bg-purple-50 text-purple-700 border border-purple-200'
                          : lic.tier === 'professional'
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}>
                        {lic.tier}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <div className="font-medium text-slate-800">{lic.validUntil}</div>
                      <div className="text-[10px] text-slate-400">Issued: {lic.issuedAt}</div>
                    </td>

                    <td className="p-3.5 text-center">
                      <button
                        onClick={() => handleToggleStatus(lic)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase cursor-pointer border ${
                          lic.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                            : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                        }`}
                        title="Click to toggle status"
                      >
                        {lic.status === 'active' ? (
                          <><CheckCircle2 className="w-3 h-3" /> Active</>
                        ) : (
                          <><AlertTriangle className="w-3 h-3" /> Suspended</>
                        )}
                      </button>
                    </td>

                    <td className="p-3.5 text-[11px] text-slate-600">
                      {lic.lastEmailSentAt ? (
                        <div className="flex items-center gap-1 text-emerald-700">
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Sent: {lic.lastEmailSentAt}</span>
                        </div>
                      ) : (
                        <span className="text-amber-600 font-medium">Not emailed yet</span>
                      )}
                    </td>

                    <td className="p-3.5 pr-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEmail(lic)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-all cursor-pointer"
                          title="Open Email Dispatch Tool"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>Email Key</span>
                        </button>

                        <button
                          onClick={() => handleRenewOneYear(lic)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                          title="Extend +1 Year"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Generate New License Modal */}
      {isGeneratorOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-slate-900 text-white p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500 text-slate-900 rounded-xl font-bold">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold">Generate New Client License Key</h2>
                  <p className="text-xs text-slate-400 mt-0.5">Authorizes tax billing and compliance usage</p>
                </div>
              </div>
              <button
                onClick={() => setIsGeneratorOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleGenerateLicense} className="p-5 sm:p-6 space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Target Client Account:</label>
                <select
                  value={selectedUserForLicense}
                  onChange={(e) => {
                    setSelectedUserForLicense(e.target.value);
                    const u = users.find(usr => usr.id === e.target.value);
                    if (u) {
                      setCustomBusinessName(u.businessName);
                      setCustomClientEmail(u.email);
                    }
                  }}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:border-indigo-500 cursor-pointer"
                >
                  {users.filter(u => u.role === 'client').map(u => (
                    <option key={u.id} value={u.id}>
                      {u.displayName} ({u.businessName})
                    </option>
                  ))}
                  <option value="new_external">+ Create New External Client License</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Client Business / Firm Name <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apex Technologies Pvt Ltd"
                  value={customBusinessName}
                  onChange={(e) => setCustomBusinessName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-900 font-semibold focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Client Contact Email for License Delivery <span className="text-rose-500">*</span></label>
                <input
                  type="email"
                  required
                  placeholder="e.g. billing@clientbusiness.com"
                  value={customClientEmail}
                  onChange={(e) => setCustomClientEmail(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-900 font-mono focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">License Tier</label>
                  <select
                    value={selectedTier}
                    onChange={(e) => setSelectedTier(e.target.value as LicenseTier)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="starter">Starter Suite (Counter Billing)</option>
                    <option value="professional">Professional GST Suite (Recommended)</option>
                    <option value="enterprise">Enterprise Multi-Branch</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Validity Duration</label>
                  <select
                    value={validityMonths}
                    onChange={(e) => setValidityMonths(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:border-indigo-500 cursor-pointer"
                  >
                    <option value={6}>6 Months</option>
                    <option value={12}>1 Year (12 Months)</option>
                    <option value={24}>2 Years (24 Months)</option>
                    <option value={36}>3 Years (36 Months)</option>
                    <option value={120}>Lifetime (10 Years)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Auditor / Administrative Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. GST Audit client under Rajiv Bansal & Associates"
                  value={licenseNotes}
                  onChange={(e) => setLicenseNotes(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-slate-800 font-sans focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsGeneratorOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm active:scale-[0.98] transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Key className="w-3.5 h-3.5" />
                  Generate &amp; Open Email Dispatch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Email Modal */}
      <LicenseEmailModal
        isOpen={isEmailModalOpen}
        license={emailTargetLicense}
        onClose={() => setIsEmailModalOpen(false)}
        onSuccessDispatch={refreshLicenses}
      />
    </div>
  );
};
