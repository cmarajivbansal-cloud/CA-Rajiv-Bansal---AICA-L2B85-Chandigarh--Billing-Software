import React, { useState } from 'react';
import { AICA_SUBMISSION_FILES, downloadAicaSubmissionZip, downloadCodebaseZip } from '../utils/aicaZipGenerator';
import { 
  FileArchive, 
  Download, 
  CheckCircle2, 
  FileText, 
  Terminal, 
  FileSpreadsheet, 
  ShieldCheck, 
  FolderArchive,
  ExternalLink,
  Sparkles,
  Layers,
  Award,
  Code2
} from 'lucide-react';

interface AicaSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AicaSubmissionModal: React.FC<AicaSubmissionModalProps> = ({
  isOpen,
  onClose
}) => {
  const [downloadingAica, setDownloadingAica] = useState(false);
  const [downloadingCode, setDownloadingCode] = useState(false);
  const [downloadSuccessMsg, setDownloadSuccessMsg] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'All Files (20 Files)' },
    { id: 'Project Summary Document', label: '1. Project Summary' },
    { id: 'Prompt File(s)', label: '2. Prompt Files' },
    { id: 'Example File(s)', label: '3. Example Files' },
    { id: 'Executable File(s)', label: '4. Executable Files' },
    { id: 'Supporting Documents/Data', label: '5. Supporting Data' },
  ];

  const filteredFiles = selectedCategory === 'all' 
    ? AICA_SUBMISSION_FILES 
    : AICA_SUBMISSION_FILES.filter(f => f.category === selectedCategory);

  const handleDownloadAica = async () => {
    setDownloadingAica(true);
    try {
      await downloadAicaSubmissionZip();
      setDownloadSuccessMsg('AICA_Level_2_Project_CMA_Rajiv_Bansal.zip downloaded successfully! Ready for course submission.');
      setTimeout(() => setDownloadSuccessMsg(null), 5000);
    } catch (err) {
      console.error(err);
      alert('Could not download AICA ZIP automatically. Please try again.');
    } finally {
      setDownloadingAica(false);
    }
  };

  const handleDownloadCode = async () => {
    setDownloadingCode(true);
    try {
      await downloadCodebaseZip();
      setDownloadSuccessMsg('Tax_Compliant_Billing_Suite_Full_Codebase.zip downloaded successfully! Contains 100% of application code files.');
      setTimeout(() => setDownloadSuccessMsg(null), 5000);
    } catch (err) {
      console.error(err);
      alert('Could not download Code ZIP automatically. Please try again.');
    } finally {
      setDownloadingCode(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-sky-600 rounded-xl text-white shadow-md shadow-sky-950/40">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded border border-sky-400/30">
                    AICA Level 2 Certificate Course
                  </span>
                  <span className="text-xs text-slate-400 font-mono">Dossier v2.0</span>
                </div>
                <h2 className="text-lg font-bold tracking-tight text-white mt-1">
                  Capstone Project Submission Package
                </h2>
                <p className="text-xs text-slate-300 mt-0.5">
                  Candidate: <strong>CMA Rajiv Bansal</strong> &bull; <span className="text-sky-300 font-mono">CMARAJIVBANSAL@gmail.com</span>
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>

          {/* Quick Info Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-slate-800 text-[11px]">
            <div>
              <span className="text-slate-400 block">Required Format:</span>
              <span className="font-semibold text-emerald-400">Single Organized .ZIP</span>
            </div>
            <div>
              <span className="text-slate-400 block">Total Files:</span>
              <span className="font-semibold text-white">20 Verified Files</span>
            </div>
            <div>
              <span className="text-slate-400 block">Archive Name:</span>
              <span className="font-mono text-sky-300 truncate block">AICA_Level_2_..._Bansal.zip</span>
            </div>
            <div>
              <span className="text-slate-400 block">Status:</span>
              <span className="font-semibold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Ready for Upload
              </span>
            </div>
          </div>
        </div>

        {/* Action Callout Bar */}
        <div className="bg-slate-50 p-4 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-700">
            <span className="font-semibold block text-slate-900">Download Submission & Code Archives:</span>
            Choose whether to download the complete codebase repository or the AICA course submission dossier.
          </div>
          <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap sm:flex-nowrap">
            <button
              onClick={handleDownloadCode}
              disabled={downloadingCode}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white text-xs font-bold rounded-xl shadow-sm shadow-emerald-950/20 transition-all cursor-pointer disabled:opacity-50 whitespace-nowrap"
              title="Download 100% of application source code files in a ZIP folder"
            >
              <Code2 className="w-4 h-4 text-emerald-200" />
              {downloadingCode ? 'Packing Code...' : 'Download Code Files (.ZIP)'}
            </button>

            <button
              onClick={handleDownloadAica}
              disabled={downloadingAica}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-xs font-bold rounded-xl shadow-sm shadow-sky-950/20 transition-all cursor-pointer disabled:opacity-50 whitespace-nowrap"
              title="Download official AICA Capstone Project Dossier with 20 course files"
            >
              <Award className="w-4 h-4 text-sky-200" />
              {downloadingAica ? 'Compiling Dossier...' : 'Download AICA Project (.ZIP)'}
            </button>
          </div>
        </div>

        {downloadSuccessMsg && (
          <div className="bg-emerald-50 border-b border-emerald-200 p-3 text-emerald-900 text-xs flex items-center justify-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span><strong>{downloadSuccessMsg}</strong></span>
          </div>
        )}

        {/* Category Filter Tabs */}
        <div className="flex overflow-x-auto gap-1 p-3 bg-slate-100/70 border-b border-slate-200 text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* File Inventory List */}
        <div className="p-4 sm:p-5 max-h-[380px] overflow-y-auto space-y-2.5">
          {filteredFiles.map((file, idx) => (
            <div
              key={idx}
              className="p-3 bg-white hover:bg-slate-50 border border-slate-200/80 rounded-xl flex items-start justify-between gap-3 text-xs transition-colors"
            >
              <div className="flex items-start gap-2.5">
                <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0 mt-0.5">
                  {file.category === 'Project Summary Document' && <FileText className="w-4 h-4 text-sky-600" />}
                  {file.category === 'Prompt File(s)' && <Terminal className="w-4 h-4 text-amber-600" />}
                  {file.category === 'Example File(s)' && <FileSpreadsheet className="w-4 h-4 text-emerald-600" />}
                  {file.category === 'Executable File(s)' && <FolderArchive className="w-4 h-4 text-indigo-600" />}
                  {file.category === 'Supporting Documents/Data' && <ShieldCheck className="w-4 h-4 text-rose-600" />}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-slate-900">{file.filename}</span>
                    <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200">
                      {file.category}
                    </span>
                  </div>
                  <p className="text-slate-500 mt-0.5 text-[11px] leading-relaxed">
                    {file.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer with Compliance Note */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="text-slate-500 text-[11px]">
            Organized in compliance with AICA Level 2 Certificate guidelines.
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadCode}
              disabled={downloadingCode}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5" />
              Code (.ZIP)
            </button>
            <span className="text-slate-300">|</span>
            <button
              onClick={handleDownloadAica}
              disabled={downloadingAica}
              className="text-xs font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1 cursor-pointer"
            >
              <Award className="w-3.5 h-3.5" />
              AICA Dossier (.ZIP)
            </button>
            <span className="text-slate-300">|</span>
            <button
              onClick={onClose}
              className="text-xs font-semibold text-slate-600 hover:text-slate-800 cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
