import React, { useState } from 'react';
import { Invoice, SellerProfile } from '../types';
import { formatCurrency } from '../utils/numberToWords';
import { exportTaxComplianceExcel } from '../utils/excelGenerator';
import { 
  Plus, 
  Search, 
  FileSpreadsheet, 
  Printer, 
  Eye, 
  Edit3, 
  Trash2, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Filter, 
  Download, 
  Copy,
  Receipt,
  TrendingUp,
  CreditCard,
  Building2
} from 'lucide-react';

interface InvoiceListProps {
  invoices: Invoice[];
  seller: SellerProfile;
  onCreateNew: () => void;
  onViewInvoice: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (invoiceId: string) => void;
  onUpdateStatus: (invoiceId: string, status: Invoice['status']) => void;
  onDuplicateInvoice: (invoice: Invoice) => void;
}

export const InvoiceList: React.FC<InvoiceListProps> = ({
  invoices,
  seller,
  onCreateNew,
  onViewInvoice,
  onEditInvoice,
  onDeleteInvoice,
  onUpdateStatus,
  onDuplicateInvoice
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');

  // Filter invoices
  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.buyer.companyName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.buyer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.buyer.gstin?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Calculate Metrics
  const totalBilled = filteredInvoices.reduce((acc, i) => acc + i.grandTotal, 0);
  const totalPaid = filteredInvoices
    .filter(i => i.status === 'paid')
    .reduce((acc, i) => acc + i.grandTotal, 0);
  const totalOutstanding = filteredInvoices
    .filter(i => i.status === 'issued' || i.status === 'overdue')
    .reduce((acc, i) => acc + i.grandTotal, 0);
  const totalGst = filteredInvoices.reduce((acc, i) => acc + i.totalTax, 0);

  const handleExportFilteredExcel = () => {
    exportTaxComplianceExcel(
      filteredInvoices,
      seller,
      `Sales_Register_${seller.businessName.replace(/[^a-zA-Z0-9]/g, '_')}`
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200/50">
              <Receipt className="w-5 h-5" />
            </div>
            Invoices &amp; Billing Hub
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage daily sales bills, track payments, and export tax compliance files
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportFilteredExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 rounded-lg shadow-xs active:scale-[0.98] transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            Export Sales Register (.xlsx)
          </button>

          <button
            onClick={onCreateNew}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create New Invoice
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-colors">
          <span className="text-xs font-semibold text-slate-500 flex items-center justify-between">
            Total Invoiced ({filteredInvoices.length})
            <Receipt className="w-4 h-4 text-slate-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 mt-1.5">
            {formatCurrency(totalBilled, seller.currencySymbol)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">Gross billed amount</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-colors">
          <span className="text-xs font-semibold text-emerald-700 flex items-center justify-between">
            Collected / Paid
            <CheckCircle className="w-4 h-4 text-emerald-500" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-emerald-800 mt-1.5">
            {formatCurrency(totalPaid, seller.currencySymbol)}
          </div>
          <span className="text-[11px] text-emerald-600 font-medium mt-0.5 block">Settled funds</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs hover:border-amber-300 transition-colors">
          <span className="text-xs font-semibold text-amber-700 flex items-center justify-between">
            Outstanding Receivable
            <Clock className="w-4 h-4 text-amber-500" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-amber-800 mt-1.5">
            {formatCurrency(totalOutstanding, seller.currencySymbol)}
          </div>
          <span className="text-[11px] text-amber-600 font-medium mt-0.5 block">Pending collections</span>
        </div>

        <div className="bg-white p-4.5 rounded-xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-colors">
          <span className="text-xs font-semibold text-indigo-700 flex items-center justify-between">
            GST Output Tax
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-indigo-800 mt-1.5">
            {formatCurrency(totalGst, seller.currencySymbol)}
          </div>
          <span className="text-[11px] text-indigo-600 font-medium mt-0.5 block">Tax compliance liability</span>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search invoice number, client, GSTIN..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span>Status:</span>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-slate-800 font-medium focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
          >
            <option value="all">All Invoices</option>
            <option value="paid">Paid</option>
            <option value="issued">Issued / Unpaid</option>
            <option value="overdue">Overdue</option>
            <option value="draft">Drafts</option>
          </select>
        </div>
      </div>

      {/* Invoices Data Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredInvoices.length === 0 ? (
          <div className="text-center py-14 px-4">
            <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto mb-3">
              <Receipt className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">No invoices found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
              {searchTerm || statusFilter !== 'all'
                ? 'Try adjusting your search query or status filter.'
                : 'Start issuing professional invoices for your clients right away.'}
            </p>
            <button
              onClick={onCreateNew}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Create First Invoice
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200">
                  <th className="p-3.5 pl-4">Invoice No</th>
                  <th className="p-3.5">Date &amp; Due</th>
                  <th className="p-3.5">Client / Buyer</th>
                  <th className="p-3.5">GSTIN &amp; POS</th>
                  <th className="p-3.5 text-right">Taxable Amt</th>
                  <th className="p-3.5 text-right">Total Tax</th>
                  <th className="p-3.5 text-right font-bold">Grand Total</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 pr-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 pl-4 font-mono font-bold text-indigo-700">
                      <button
                        onClick={() => onViewInvoice(inv)}
                        className="hover:underline text-left cursor-pointer"
                      >
                        {inv.invoiceNumber}
                      </button>
                    </td>

                    <td className="p-3.5 text-slate-600">
                      <div className="font-medium text-slate-800">{inv.invoiceDate}</div>
                      <div className="text-[10px] text-slate-400">Due: {inv.dueDate}</div>
                    </td>

                    <td className="p-3.5">
                      <div className="font-semibold text-slate-900">
                        {inv.buyer.companyName || inv.buyer.name}
                      </div>
                      {inv.buyer.companyName && inv.buyer.name && (
                        <div className="text-[10px] text-slate-500">{inv.buyer.name}</div>
                      )}
                    </td>

                    <td className="p-3.5 font-mono text-[11px] text-slate-600">
                      <div className="font-semibold text-slate-800">{inv.buyer.gstin || <span className="text-slate-400 font-sans font-normal">Unregistered</span>}</div>
                      <div className="text-[10px] font-sans text-slate-500">{inv.buyer.placeOfSupply || inv.buyer.billingAddress.state}</div>
                    </td>

                    <td className="p-3.5 text-right font-mono text-slate-700 font-medium">
                      {formatCurrency(inv.totalTaxableAmount, seller.currencySymbol)}
                    </td>

                    <td className="p-3.5 text-right font-mono text-slate-600">
                      <div className="font-medium text-slate-700">{formatCurrency(inv.totalTax, seller.currencySymbol)}</div>
                      <div className="text-[10px] text-slate-400">
                        {inv.isInterState ? 'IGST' : 'CGST+SGST'}
                      </div>
                    </td>

                    <td className="p-3.5 text-right font-mono font-bold text-slate-900 text-sm">
                      {formatCurrency(inv.grandTotal, seller.currencySymbol)}
                    </td>

                    <td className="p-3.5 text-center">
                      <select
                        value={inv.status}
                        onChange={(e) => onUpdateStatus(inv.id, e.target.value as Invoice['status'])}
                        className={`text-[11px] font-semibold uppercase px-2.5 py-1 rounded-full border cursor-pointer transition-colors ${
                          inv.status === 'paid'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                            : inv.status === 'issued'
                            ? 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
                            : inv.status === 'overdue'
                            ? 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'
                            : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                        }`}
                      >
                        <option value="issued">Issued</option>
                        <option value="paid">Paid</option>
                        <option value="draft">Draft</option>
                        <option value="overdue">Overdue</option>
                      </select>
                    </td>

                    <td className="p-3.5 pr-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onViewInvoice(inv)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors cursor-pointer"
                          title="View / Print Invoice"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onEditInvoice(inv)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors cursor-pointer"
                          title="Edit Invoice"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDuplicateInvoice(inv)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors cursor-pointer"
                          title="Duplicate Invoice"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteInvoice(inv.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                          title="Delete Invoice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
