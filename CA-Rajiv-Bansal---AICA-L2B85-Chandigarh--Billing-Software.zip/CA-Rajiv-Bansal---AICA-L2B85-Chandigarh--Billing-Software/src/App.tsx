/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ClientBuyer, 
  Invoice, 
  ProductServiceItem, 
  SellerProfile, 
  UserAccount 
} from './types';
import { StorageService } from './utils/storage';
import { Navbar } from './components/Navbar';
import { MobileNav } from './components/MobileNav';
import { InvoiceList } from './components/InvoiceList';
import { InvoiceBuilder } from './components/InvoiceBuilder';
import { InvoicePreview } from './components/InvoicePreview';
import { SellerProfileSettings } from './components/SellerProfileSettings';
import { ClientMaster } from './components/ClientMaster';
import { ProductCatalog } from './components/ProductCatalog';
import { AdminTaxCompliance } from './components/AdminTaxCompliance';
import { LoginModal } from './components/LoginModal';
import { QuickShareModal } from './components/QuickShareModal';
import { LicenseActivationModal } from './components/LicenseActivationModal';
import { AicaSubmissionModal } from './components/AicaSubmissionModal';
import { INITIAL_SELLER_PROFILES, INITIAL_USERS } from './data/seedData';
import { ShieldCheck, RotateCcw } from 'lucide-react';

export default function App() {
  // Global Application States
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => StorageService.getCurrentUser());
  const [users, setUsers] = useState<UserAccount[]>(() => StorageService.getUsers());
  const [sellerProfiles, setSellerProfiles] = useState<SellerProfile[]>(() => StorageService.getSellerProfiles());
  
  // Current active seller profile
  const [currentSeller, setCurrentSeller] = useState<SellerProfile>(() => {
    const user = StorageService.getCurrentUser();
    const profile = StorageService.getSellerProfile(user.sellerProfileId);
    return profile || INITIAL_SELLER_PROFILES[0];
  });

  const [clients, setClients] = useState<ClientBuyer[]>(() => StorageService.getClientBuyers());
  const [products, setProducts] = useState<ProductServiceItem[]>(() => StorageService.getProducts());
  const [invoices, setInvoices] = useState<Invoice[]>(() => StorageService.getInvoices());

  // Navigation and Modal States
  const [currentView, setCurrentView] = useState<string>('invoices');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isActivationModalOpen, setIsActivationModalOpen] = useState(false);
  const [isAicaModalOpen, setIsAicaModalOpen] = useState(false);
  const [shareInvoiceTarget, setShareInvoiceTarget] = useState<Invoice | null>(null);

  // Sync state when current user or active seller changes
  useEffect(() => {
    const profile = StorageService.getSellerProfile(currentUser.sellerProfileId);
    if (profile) {
      setCurrentSeller(profile);
    }
  }, [currentUser]);

  // Client-filtered data for non-admin view
  const displayClients = currentUser.role === 'admin' 
    ? clients 
    : clients.filter(c => c.ownerClientId === currentSeller.id);

  const displayProducts = currentUser.role === 'admin'
    ? products
    : products.filter(p => p.ownerClientId === currentSeller.id);

  const displayInvoices = currentUser.role === 'admin'
    ? invoices
    : invoices.filter(inv => inv.createdByClientId === currentSeller.id);

  // --- Handlers ---
  const handleSelectUser = (user: UserAccount) => {
    setCurrentUser(user);
    StorageService.setCurrentUser(user);
    const profile = StorageService.getSellerProfile(user.sellerProfileId);
    if (profile) {
      setCurrentSeller(profile);
    }
    setCurrentView(user.role === 'admin' ? 'admin' : 'invoices');
  };

  const handleCreateClientAccount = (username: string, displayName: string, businessName: string) => {
    const newSellerId = `seller_${username}`;
    
    // Create new seller profile
    const newSellerProfile: SellerProfile = {
      id: newSellerId,
      businessName,
      legalName: businessName,
      tagline: 'Quality Goods & Services',
      gstin: '07AAACZ1122K1Z5',
      pan: 'AAACZ1122K',
      email: `${username}@business.com`,
      phone: '+91 98000 12345',
      addressLine1: 'Commercial Complex, Main Road',
      city: 'New Delhi',
      state: 'Delhi',
      stateCode: '07',
      pincode: '110001',
      country: 'India',
      bankDetails: {
        bankName: 'HDFC Bank',
        accountHolder: businessName,
        accountNumber: '502000' + Math.floor(10000000 + Math.random() * 90000000),
        ifscCode: 'HDFC0001234',
        branch: 'Main Branch',
        upiId: `${username}@hdfcbank`
      },
      currency: 'INR',
      currencySymbol: '₹',
      invoicePrefix: `${username.substring(0, 3).toUpperCase()}/2026/`,
      nextInvoiceNumber: 1,
      defaultTerms: '1. Payment due within 15 days.\n2. Standard statutory tax terms apply.',
      defaultNotes: 'Thank you for your business!',
      signatoryName: displayName,
      signatoryDesignation: 'Authorized Signatory',
      taxRegistrationType: 'Regular GST'
    };

    // Create user account
    const newUser: UserAccount = {
      id: `user_${username}`,
      username,
      displayName,
      email: `${username}@business.com`,
      role: 'client',
      businessName,
      sellerProfileId: newSellerId,
      phone: '+91 98000 12345',
      lastLogin: new Date().toLocaleString()
    };

    StorageService.saveSellerProfile(newSellerProfile);
    
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('billing_app_users_v1', JSON.stringify(updatedUsers));

    setSellerProfiles(StorageService.getSellerProfiles());
    handleSelectUser(newUser);
  };

  const handleSaveInvoice = (invoice: Invoice, andPreview: boolean = false) => {
    StorageService.saveInvoice(invoice);
    setInvoices(StorageService.getInvoices());
    setSellerProfiles(StorageService.getSellerProfiles());

    if (andPreview) {
      setSelectedInvoice(invoice);
      setCurrentView('preview_invoice');
    } else {
      setCurrentView('invoices');
    }
  };

  const handleDeleteInvoice = (invoiceId: string) => {
    if (confirm('Are you sure you want to delete this invoice record?')) {
      StorageService.deleteInvoice(invoiceId);
      setInvoices(StorageService.getInvoices());
    }
  };

  const handleUpdateStatus = (invoiceId: string, status: Invoice['status']) => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (inv) {
      const updated: Invoice = {
        ...inv,
        status,
        updatedAt: new Date().toISOString(),
        paymentDate: status === 'paid' ? (inv.paymentDate || new Date().toISOString().split('T')[0]) : inv.paymentDate
      };
      StorageService.saveInvoice(updated);
      setInvoices(StorageService.getInvoices());
      if (selectedInvoice && selectedInvoice.id === invoiceId) {
        setSelectedInvoice(updated);
      }
    }
  };

  const handleDuplicateInvoice = (invoice: Invoice) => {
    const newInv: Invoice = {
      ...invoice,
      id: `inv_${Date.now()}`,
      invoiceNumber: `${currentSeller.invoicePrefix}${String(currentSeller.nextInvoiceNumber).padStart(3, '0')}`,
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setSelectedInvoice(newInv);
    setCurrentView('create_invoice');
  };

  const handleSaveSeller = (updatedSeller: SellerProfile) => {
    StorageService.saveSellerProfile(updatedSeller);
    setSellerProfiles(StorageService.getSellerProfiles());
    setCurrentSeller(updatedSeller);
  };

  const handleSaveClient = (client: ClientBuyer) => {
    StorageService.saveClientBuyer(client);
    setClients(StorageService.getClientBuyers());
  };

  const handleDeleteClient = (clientId: string) => {
    if (confirm('Are you sure you want to delete this client?')) {
      StorageService.deleteClientBuyer(clientId);
      setClients(StorageService.getClientBuyers());
    }
  };

  const handleSaveProduct = (product: ProductServiceItem) => {
    StorageService.saveProduct(product);
    setProducts(StorageService.getProducts());
  };

  const handleDeleteProduct = (productId: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      StorageService.deleteProduct(productId);
      setProducts(StorageService.getProducts());
    }
  };

  const handleAdminSwitchClient = (sellerId: string) => {
    const profile = StorageService.getSellerProfile(sellerId);
    if (profile) {
      setCurrentSeller(profile);
      setCurrentView('invoices');
    }
  };

  const handleResetData = () => {
    if (confirm('Reset entire billing and tax database to initial demo state?')) {
      StorageService.resetAllData();
      setUsers(StorageService.getUsers());
      setCurrentUser(StorageService.getCurrentUser());
      setSellerProfiles(StorageService.getSellerProfiles());
      setClients(StorageService.getClientBuyers());
      setProducts(StorageService.getProducts());
      setInvoices(StorageService.getInvoices());
      const profile = StorageService.getSellerProfile(StorageService.getCurrentUser().sellerProfileId);
      if (profile) setCurrentSeller(profile);
      setCurrentView('invoices');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={(view) => {
          if (view === 'create_invoice') setSelectedInvoice(null);
          setCurrentView(view);
        }}
        currentUser={currentUser}
        seller={currentSeller}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onResetData={handleResetData}
        onOpenActivationModal={() => setIsActivationModalOpen(true)}
        onOpenAicaModal={() => setIsAicaModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 pb-24 md:pb-12">
        {currentView === 'invoices' && (
          <InvoiceList
            invoices={displayInvoices}
            seller={currentSeller}
            onCreateNew={() => {
              setSelectedInvoice(null);
              setCurrentView('create_invoice');
            }}
            onViewInvoice={(inv) => {
              setSelectedInvoice(inv);
              setCurrentView('preview_invoice');
            }}
            onEditInvoice={(inv) => {
              setSelectedInvoice(inv);
              setCurrentView('create_invoice');
            }}
            onDeleteInvoice={handleDeleteInvoice}
            onUpdateStatus={handleUpdateStatus}
            onDuplicateInvoice={handleDuplicateInvoice}
          />
        )}

        {currentView === 'create_invoice' && (
          <InvoiceBuilder
            seller={currentSeller}
            clients={displayClients}
            products={displayProducts}
            initialInvoice={selectedInvoice}
            onSaveInvoice={handleSaveInvoice}
            onCancel={() => setCurrentView('invoices')}
          />
        )}

        {currentView === 'preview_invoice' && selectedInvoice && (
          <InvoicePreview
            invoice={selectedInvoice}
            onEdit={(inv) => {
              setSelectedInvoice(inv);
              setCurrentView('create_invoice');
            }}
            onBack={() => setCurrentView('invoices')}
            onUpdateStatus={handleUpdateStatus}
            onOpenShareModal={(inv) => {
              setShareInvoiceTarget(inv);
              setIsShareModalOpen(true);
            }}
          />
        )}

        {currentView === 'clients' && (
          <ClientMaster
            clients={displayClients}
            seller={currentSeller}
            onSaveClient={handleSaveClient}
            onDeleteClient={handleDeleteClient}
          />
        )}

        {currentView === 'products' && (
          <ProductCatalog
            products={displayProducts}
            seller={currentSeller}
            onSaveProduct={handleSaveProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        )}

        {currentView === 'settings' && (
          <SellerProfileSettings
            seller={currentSeller}
            onSave={handleSaveSeller}
            isAdmin={currentUser.role === 'admin'}
          />
        )}

        {currentView === 'admin' && (
          <AdminTaxCompliance
            invoices={invoices}
            sellerProfiles={sellerProfiles}
            users={users}
            currentUser={currentUser}
            onSwitchClient={handleAdminSwitchClient}
            onViewInvoice={(inv) => {
              setSelectedInvoice(inv);
              setCurrentView('preview_invoice');
            }}
          />
        )}
      </main>

      {/* Professional Polish Bottom Status Bar (Hidden when printing and on small mobile viewports where bottom nav is shown) */}
      <footer className="hidden md:block bg-white border-t border-slate-200/80 py-2.5 px-6 print:hidden">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-medium text-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Sync Active
            </span>
            <span className="text-slate-300">|</span>
            <span>Biller: <strong className="text-slate-700 font-semibold">{currentSeller.businessName}</strong></span>
            <span className="text-slate-300">|</span>
            <span className="font-mono text-slate-600">GSTIN: {currentSeller.gstin}</span>
          </div>

          <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
            <span>Tax Compliance Engine v2.4</span>
            <span className="text-slate-300">&bull;</span>
            <span>GSTR-1 &amp; 3B Ready</span>
          </div>
        </div>
      </footer>

      {/* Bottom Mobile Navigation */}
      <MobileNav
        currentView={currentView}
        onNavigate={(view) => {
          if (view === 'create_invoice') setSelectedInvoice(null);
          setCurrentView(view);
        }}
        isAdmin={currentUser.role === 'admin'}
      />

      {/* Modals */}
      <LoginModal
        isOpen={isLoginModalOpen}
        users={users}
        sellerProfiles={sellerProfiles}
        currentUser={currentUser}
        onSelectUser={handleSelectUser}
        onCreateClientAccount={handleCreateClientAccount}
        onClose={() => setIsLoginModalOpen(false)}
      />

      <QuickShareModal
        isOpen={isShareModalOpen}
        invoice={shareInvoiceTarget}
        onClose={() => {
          setIsShareModalOpen(false);
          setShareInvoiceTarget(null);
        }}
      />

      <LicenseActivationModal
        isOpen={isActivationModalOpen}
        currentUser={currentUser}
        seller={currentSeller}
        onClose={() => setIsActivationModalOpen(false)}
        onLicenseActivated={(license) => {
          // Trigger re-render / notification
          setIsActivationModalOpen(false);
        }}
      />

      <AicaSubmissionModal
        isOpen={isAicaModalOpen}
        onClose={() => setIsAicaModalOpen(false)}
      />
    </div>
  );
}
