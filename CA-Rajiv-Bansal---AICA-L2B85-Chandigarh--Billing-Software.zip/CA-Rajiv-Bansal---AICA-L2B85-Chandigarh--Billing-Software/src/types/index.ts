export type UserRole = 'admin' | 'client';

export type InvoiceStatus = 'draft' | 'issued' | 'paid' | 'overdue' | 'cancelled';

export type TemplateStyle = 'modern-navy' | 'classic-corporate' | 'clean-minimal' | 'tax-compact' | 'retail-pos';

export type ItemType = 'product' | 'service';

export type UnitType = 'PCS' | 'NOS' | 'HRS' | 'DAYS' | 'MTR' | 'KGS' | 'MONTH' | 'SET' | 'BOX' | 'SQFT' | 'PKT';

export type LicenseTier = 'starter' | 'professional' | 'enterprise';
export type LicenseStatus = 'active' | 'pending' | 'expired' | 'suspended';

export interface ClientLicense {
  id: string;
  licenseKey: string;
  clientUserId: string;
  clientUsername: string;
  businessName: string;
  clientEmail: string;
  tier: LicenseTier;
  status: LicenseStatus;
  issuedAt: string;
  validUntil: string;
  issuedBy: string; // e.g., 'CMA Rajiv Bansal (Admin / CA)'
  maxInvoices?: number;
  canExportExcel: boolean;
  canCustomizeTemplates: boolean;
  canUploadLogo: boolean;
  notes?: string;
  lastEmailSentAt?: string;
}

export interface BillingFormatConfig {
  templateStyle: TemplateStyle;
  documentTitle: string; // 'TAX INVOICE' | 'BILL OF SUPPLY' | 'RETAIL INVOICE / CASH MEMO' | 'PROFORMA INVOICE'
  accentColor: string; // hex color e.g. '#0f172a', '#4f46e5', '#059669', '#991b1b', '#334155'
  showLogo: boolean;
  logoHeight: number; // 36 to 96 px
  showHsnSac: boolean;
  showDiscount: boolean;
  showPoNumber: boolean;
  showBankDetails: boolean;
  showUpiQr: boolean;
  showSignatoryBox: boolean;
  showTerms: boolean;
  showNotes: boolean;
  paperSize?: 'A4' | 'Thermal80mm';
}

export interface BankDetails {
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
  upiId?: string;
  qrCodeUrl?: string;
}

export interface SellerProfile {
  id: string;
  businessName: string;
  legalName: string;
  tagline?: string;
  gstin: string;
  pan: string;
  email: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  stateCode: string;
  pincode: string;
  country: string;
  logoUrl?: string;
  bankDetails: BankDetails;
  currency: string;
  currencySymbol: string;
  invoicePrefix: string;
  nextInvoiceNumber: number;
  defaultTerms: string;
  defaultNotes: string;
  signatoryName: string;
  signatoryDesignation: string;
  signatorySignatureUrl?: string;
  taxRegistrationType: 'Regular GST' | 'Composition Scheme' | 'Non-GST / Exempt';
  billingFormat?: BillingFormatConfig;
}

export interface ClientBuyer {
  id: string;
  name: string;
  companyName: string;
  gstin?: string;
  pan?: string;
  email: string;
  phone: string;
  billingAddress: {
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    stateCode: string;
    pincode: string;
    country: string;
  };
  shippingAddress?: {
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    stateCode: string;
    pincode: string;
    country: string;
  };
  placeOfSupply: string; // State Name & Code
  ownerClientId: string; // The seller client who owns this buyer record
  notes?: string;
  createdAt: string;
}

export interface ProductServiceItem {
  id: string;
  name: string;
  description?: string;
  type: ItemType;
  hsnSacCode: string;
  unit: UnitType;
  defaultUnitPrice: number;
  defaultGstRate: number; // e.g. 18 for 18%
  ownerClientId: string;
  createdAt: string;
}

export interface InvoiceLineItem {
  id: string;
  productId?: string;
  description: string;
  hsnSacCode: string;
  quantity: number;
  unit: UnitType;
  unitPrice: number;
  discountPercent: number;
  discountAmount: number;
  taxableAmount: number;
  gstRate: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  igstRate: number;
  igstAmount: number;
  totalAmount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  status: InvoiceStatus;
  poNumber?: string;
  poDate?: string;
  seller: SellerProfile;
  buyer: ClientBuyer;
  items: InvoiceLineItem[];
  subTotal: number;
  totalDiscount: number;
  totalTaxableAmount: number;
  isInterState: boolean; // true if Seller State != Buyer State
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  totalTax: number;
  roundOff: number;
  grandTotal: number;
  amountInWords: string;
  notes: string;
  termsAndConditions: string;
  templateStyle: TemplateStyle;
  billingFormat?: BillingFormatConfig;
  createdByClientId: string;
  createdAt: string;
  updatedAt: string;
  paidAmount?: number;
  paymentDate?: string;
  paymentMethod?: 'UPI' | 'NEFT/RTGS' | 'Cheque' | 'Cash' | 'Card' | 'Online';
  paymentReference?: string;
}

export interface UserAccount {
  id: string;
  username: string;
  displayName: string;
  email: string;
  role: UserRole;
  businessName: string;
  sellerProfileId: string;
  avatar?: string;
  phone?: string;
  lastLogin?: string;
  licenseKey?: string;
  licenseTier?: LicenseTier;
  licenseStatus?: LicenseStatus;
  licenseExpiresAt?: string;
}

export interface StateCodeMap {
  [key: string]: { code: string; name: string };
}
