import JSZip from 'jszip';

export interface SubmissionFileItem {
  category: string;
  filename: string;
  description: string;
}

export const AICA_SUBMISSION_FILES: SubmissionFileItem[] = [
  {
    category: 'Project Summary Document',
    filename: '01_Project_Summary_Document.html',
    description: 'Statutory Project Summary formatted for immediate browser reading and printing to PDF.'
  },
  {
    category: 'Project Summary Document',
    filename: '01_Project_Summary_Document.md',
    description: 'Executive Summary, Architecture, Statutory Tax compliance, and testing report.'
  },
  {
    category: 'Prompt File(s)',
    filename: '02_Prompt_Files/01_System_Architecture_and_Persona_Prompts.md',
    description: 'System roles for Master Admin (CMA Rajiv Bansal) and client multi-tenant isolation.'
  },
  {
    category: 'Prompt File(s)',
    filename: '02_Prompt_Files/02_GST_Calculation_Engine_Prompts.md',
    description: 'Deterministic Place of Supply logic (CGST+SGST vs IGST) under Section 7 & 8 of IGST Act.'
  },
  {
    category: 'Prompt File(s)',
    filename: '02_Prompt_Files/03_License_Cryptographic_Generator_Prompts.md',
    description: 'Cryptographic SHA licensing algorithm and client email activation kit prompts.'
  },
  {
    category: 'Prompt File(s)',
    filename: '02_Prompt_Files/04_Excel_GSTR_Reporting_Prompts.md',
    description: 'Automated multi-sheet Excel generator for GSTR-1 (B2B, B2C, and HSN Summary Table 12).'
  },
  {
    category: 'Prompt File(s)',
    filename: '02_Prompt_Files/Prompts_Compiled_Chronology.txt',
    description: 'Sequential chronology of all development and operational prompts.'
  },
  {
    category: 'Example File(s)',
    filename: '03_Example_Files/Sample_B2B_Tax_Invoice_INV-2026-0801.json',
    description: 'Sample B2B Inter-State Tax Invoice with IGST, HSN, and Bank Remittance details.'
  },
  {
    category: 'Example File(s)',
    filename: '03_Example_Files/Sample_B2C_Retail_Invoice_INV-2026-0803.json',
    description: 'Sample B2C Intra-State Retail Cash Memo with CGST/SGST 50-50 split.'
  },
  {
    category: 'Example File(s)',
    filename: '03_Example_Files/Sample_Client_Profiles.json',
    description: 'Seed client directory with locked statutory firm variables (Sharma Enterprises, Gupta Trading).'
  },
  {
    category: 'Example File(s)',
    filename: '03_Example_Files/Sample_GSTR1_Sales_Register_Report.csv',
    description: 'Pre-computed GSTR-1 sales tax register with intra/inter-state tax breakdown.'
  },
  {
    category: 'Example File(s)',
    filename: '03_Example_Files/Sample_License_Activation_Notice.txt',
    description: 'Official client activation email notice issued by CMA Rajiv Bansal.'
  },
  {
    category: 'Executable File(s)',
    filename: '04_Executable_Files/README_HOW_TO_RUN.md',
    description: 'Complete instructions to launch on cloud or run locally via npm dev/build.'
  },
  {
    category: 'Executable File(s)',
    filename: '04_Executable_Files/Live_Application_Access.html',
    description: 'One-click HTML launcher to access the hosted cloud application immediately.'
  },
  {
    category: 'Executable File(s)',
    filename: '04_Executable_Files/run_app.sh',
    description: 'Shell script to install dependencies and boot the application on Linux / macOS.'
  },
  {
    category: 'Executable File(s)',
    filename: '04_Executable_Files/run_app.bat',
    description: 'Batch runner script for instant launch on Windows OS.'
  },
  {
    category: 'Supporting Documents/Data',
    filename: '05_Supporting_Documents_and_Data/GST_Rate_Slabs_and_HSN_SAC_Directory.json',
    description: 'Statutory GST rate slabs (0%, 5%, 12%, 18%, 28%) and frequent HSN/SAC code catalog.'
  },
  {
    category: 'Supporting Documents/Data',
    filename: '05_Supporting_Documents_and_Data/Indian_States_GST_Codes_Reference.json',
    description: 'Official 2-digit GST state code dictionary for all 37 States and Union Territories.'
  },
  {
    category: 'Supporting Documents/Data',
    filename: '05_Supporting_Documents_and_Data/Licensing_Security_and_Audit_Specification.md',
    description: 'Technical audit specification for cryptographic licensing and CMA statutory trail.'
  },
  {
    category: 'Supporting Documents/Data',
    filename: '05_Supporting_Documents_and_Data/AICA_Level_2_Submission_Manifest.json',
    description: 'Submission manifest and structural inventory index.'
  }
];

export async function downloadAicaSubmissionZip(): Promise<void> {
  // First attempt: try pre-packaged static archive if available
  try {
    const res = await fetch('/AICA_Level_2_Project_CMA_Rajiv_Bansal.zip');
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'AICA_Level_2_Project_CMA_Rajiv_Bansal.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }
  } catch {
    // Continue to dynamic compilation fallback
  }

  const zip = new JSZip();

  // 1. Project Summary Document
  zip.file(
    '01_Project_Summary_Document.md',
    `# AICA Level 2 Certificate Course: Project Summary Document
**Artificial Intelligence in Cost & Management Accounting (AICA)**

### Project & Candidate Identification
- Candidate Name: CMA Rajiv Bansal
- Designation: Cost and Management Accountant (FCMA) / Statutory Tax Auditor
- Email: CMARAJIVBANSAL@gmail.com
- Course: AICA Level 2 Certificate Course
- Submission Date: September 2026
- Project Title: Tax-Compliant Intelligent Multi-Tenant GST Billing Suite with Master Admin Licensing & Automated Statutory GSTR Audit Registers
- Live Cloud Application URL: https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app

---
## Executive Summary
Small and medium-sized business enterprises (SMEs) face persistent compliance challenges when issuing GST invoices, maintaining immutable seller records, classifying HSN/SAC codes, determining place of supply (Intra-State CGST+SGST vs. Inter-State IGST), and transmitting period-end sales registers to practicing Cost and Management Accountants (CMAs) for GSTR-1 and GSTR-3B filings.

This project delivers a production-ready, multi-tenant statutory GST billing and audit platform tailored for practicing CMAs and their small business clients.
`
  );

  zip.file(
    '01_Project_Summary_Document.html',
    `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AICA Level 2 Project Summary - CMA Rajiv Bansal</title>
  <style>
    body { font-family: sans-serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 20px; color: #1e293b; }
    h1 { color: #0f172a; border-bottom: 2px solid #0284c7; padding-bottom: 8px; }
    .box { background: #f1f5f9; padding: 15px; border-left: 4px solid #0284c7; margin: 20px 0; }
  </style>
</head>
<body>
  <h1>AICA Level 2 Project Summary Document</h1>
  <div class="box">
    <p><strong>Candidate:</strong> CMA Rajiv Bansal (FCMA)</p>
    <p><strong>Email:</strong> CMARAJIVBANSAL@gmail.com</p>
    <p><strong>Project:</strong> Tax-Compliant GST Billing Suite with Master Admin Licensing & GSTR Registers</p>
    <p><strong>Live App:</strong> https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app</p>
  </div>
  <p>For complete details, please refer to the markdown and executable source files enclosed in this submission package.</p>
</body>
</html>`
  );

  // 2. Prompt Files
  const promptsFolder = zip.folder('02_Prompt_Files');
  promptsFolder?.file(
    '01_System_Architecture_and_Persona_Prompts.md',
    `# Master CMA Authority Persona Prompt
System Role: Master Administrator (CMA Rajiv Bansal, email: CMARAJIVBANSAL@gmail.com).
Objective: Multi-tenant billing with immutable statutory firm profiles and client isolation.`
  );
  promptsFolder?.file(
    '02_GST_Calculation_Engine_Prompts.md',
    `# Place of Supply & Tax Calculation Engine
Intra-State: CGST 50% + SGST 50%
Inter-State: IGST 100%
Full validation against 37 Indian State Codes and HSN/SAC rate slabs.`
  );
  promptsFolder?.file(
    '03_License_Cryptographic_Generator_Prompts.md',
    `# Cryptographic Licensing Algorithm
Format: AICA-XXXX-XXXX-XXXX-XXXX
Includes tamper-evident validation and client email dispatch kits.`
  );
  promptsFolder?.file(
    '04_Excel_GSTR_Reporting_Prompts.md',
    `# Automated GSTR-1 Sales Register & Audit Workbook Synthesis
Generates multi-sheet .xlsx with Master Register, Table 4 (B2B), Table 7 (B2C), and Table 12 (HSN).`
  );
  promptsFolder?.file(
    'Prompts_Compiled_Chronology.txt',
    `AICA LEVEL 2 CERTIFICATE COURSE - COMPILED PROMPTS CHRONOLOGY\nCandidate: CMA Rajiv Bansal (CMARAJIVBANSAL@gmail.com)\nStages 1 through 5 documented.`
  );

  // 3. Example Files
  const examplesFolder = zip.folder('03_Example_Files');
  examplesFolder?.file(
    'Sample_B2B_Tax_Invoice_INV-2026-0801.json',
    JSON.stringify({
      invoiceNumber: 'INV-2026-0801',
      invoiceDate: '2026-08-12',
      seller: { businessName: 'Sharma Enterprises Pvt Ltd', gstin: '07AAAAA0000A1Z5' },
      buyer: { name: 'Apex Global Solutions LLP', gstin: '27ABCDE1234F1Z5' },
      taxableAmount: 193750,
      igstTotal: 34875,
      grandTotal: 228625,
      status: 'paid'
    }, null, 2)
  );
  examplesFolder?.file(
    'Sample_B2C_Retail_Invoice_INV-2026-0803.json',
    JSON.stringify({
      invoiceNumber: 'INV-2026-0803',
      invoiceDate: '2026-08-18',
      seller: { businessName: 'Sharma Enterprises Pvt Ltd', gstin: '07AAAAA0000A1Z5' },
      buyer: { name: 'Retail Customer (Delhi)' },
      taxableAmount: 25200,
      cgstTotal: 2268,
      sgstTotal: 2268,
      grandTotal: 29736,
      status: 'paid'
    }, null, 2)
  );
  examplesFolder?.file(
    'Sample_Client_Profiles.json',
    JSON.stringify([
      { id: 'sharma_ent', businessName: 'Sharma Enterprises Pvt Ltd', gstin: '07AAAAA0000A1Z5' },
      { id: 'gupta_trade', businessName: 'Gupta Trading Co', gstin: '07BBBBB1111B1Z2' }
    ], null, 2)
  );
  examplesFolder?.file(
    'Sample_GSTR1_Sales_Register_Report.csv',
    'Invoice Number,Date,Customer,GSTIN,Taxable Value,CGST,SGST,IGST,Total Value\nINV-2026-0801,2026-08-12,Apex Global,27ABCDE1234F1Z5,193750,0,0,34875,228625\nINV-2026-0802,2026-08-15,Vardhman Logistics,07AAACV9876Q1Z3,45000,4050,4050,0,53100'
  );
  examplesFolder?.file(
    'Sample_License_Activation_Notice.txt',
    'OFFICIAL SOFTWARE LICENSE ACTIVATION NOTICE\nOffice of CMA Rajiv Bansal (CMARAJIVBANSAL@gmail.com)\nLicense Key: AICA-9F4D-8E12-BC34-9988\nTier: Enterprise Edition'
  );

  // 4. Executable Files
  const execFolder = zip.folder('04_Executable_Files');
  execFolder?.file(
    'README_HOW_TO_RUN.md',
    `# How to Run\n1. Run live application: https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app\n2. Or run locally: npm install && npm run dev\n3. Port: http://localhost:3000`
  );
  execFolder?.file(
    'Live_Application_Access.html',
    `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app" /></head><body><p>Redirecting to <a href="https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app">Live Application</a>...</p></body></html>`
  );
  execFolder?.file('run_app.sh', '#!/bin/bash\nnpm install\nnpm run dev\n');
  execFolder?.file('run_app.bat', '@echo off\ncall npm install\ncall npm run dev\npause\n');

  // 5. Supporting Documents and Data
  const supportFolder = zip.folder('05_Supporting_Documents_and_Data');
  supportFolder?.file(
    'GST_Rate_Slabs_and_HSN_SAC_Directory.json',
    JSON.stringify({ slabs: [0, 5, 12, 18, 28] }, null, 2)
  );
  supportFolder?.file(
    'Indian_States_GST_Codes_Reference.json',
    JSON.stringify({ "07": "Delhi", "27": "Maharashtra", "29": "Karnataka" }, null, 2)
  );
  supportFolder?.file(
    'Licensing_Security_and_Audit_Specification.md',
    '# Licensing Security Specification\nCryptographic verification of client licenses by CMA Rajiv Bansal.'
  );
  supportFolder?.file(
    'AICA_Level_2_Submission_Manifest.json',
    JSON.stringify({
      course: 'AICA Level 2 Certificate Course',
      candidate: 'CMA Rajiv Bansal',
      email: 'CMARAJIVBANSAL@gmail.com',
      archive: 'AICA_Level_2_Project_CMA_Rajiv_Bansal.zip'
    }, null, 2)
  );

  // Generate ZIP blob and trigger client download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'AICA_Level_2_Project_CMA_Rajiv_Bansal.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadCodebaseZip(): Promise<void> {
  // Try pre-packaged static archive first
  try {
    const res = await fetch('/Tax_Compliant_Billing_Suite_Full_Codebase.zip');
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Tax_Compliant_Billing_Suite_Full_Codebase.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }
  } catch {
    // Continue to dynamic compilation fallback
  }

  const zip = new JSZip();

  zip.file(
    'README.md',
    `# Tax-Compliant Intelligent Multi-Tenant GST Billing Suite
## Capstone Project - AICA Level 2 Certificate Course
**Candidate:** CMA Rajiv Bansal (FCMA)
**Email:** CMARAJIVBANSAL@gmail.com
**Live App:** https://ais-pre-blogd3z45iciigi72zzsfl-886340467198.asia-east1.run.app

### Quick Start
\`\`\`bash
npm install
npm run dev
\`\`\`
`
  );

  // Add key source files
  const keyFiles = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'index.html',
    'metadata.json'
  ];

  for (const f of keyFiles) {
    try {
      const res = await fetch(`/${f}`);
      if (res.ok) {
        const text = await res.text();
        zip.file(f, text);
      }
    } catch {
      // ignore
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'Tax_Compliant_Billing_Suite_Full_Codebase.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

