import { ClientLicense, LicenseStatus, LicenseTier, SellerProfile, UserAccount } from '../types';

const LICENSES_STORAGE_KEY = 'billing_app_licenses_v1';

export const INITIAL_LICENSES: ClientLicense[] = [
  {
    id: 'lic_apex_01',
    licenseKey: 'GST-PRO-8491-3029-APEX',
    clientUserId: 'user_client_1',
    clientUsername: 'apex_tech',
    businessName: 'Apex Technologies & Cloud Solutions Pvt Ltd',
    clientEmail: 'billing@apextech.in',
    tier: 'professional',
    status: 'active',
    issuedAt: '2026-04-01',
    validUntil: '2027-03-31',
    issuedBy: 'CMA Rajiv Bansal (Admin / CA)',
    canExportExcel: true,
    canCustomizeTemplates: true,
    canUploadLogo: true,
    notes: 'Full GST Compliance & Cloud Sync activated by Rajiv Bansal & Associates.',
    lastEmailSentAt: '2026-04-01 10:00 AM'
  },
  {
    id: 'lic_sunrise_02',
    licenseKey: 'GST-STARTER-4920-1184-SUNR',
    clientUserId: 'user_client_2',
    clientUsername: 'sunrise_goods',
    businessName: 'Sunrise Hardware & Industrial Traders',
    clientEmail: 'accounts@sunrisetraders.com',
    tier: 'starter',
    status: 'active',
    issuedAt: '2026-05-15',
    validUntil: '2027-05-14',
    issuedBy: 'CMA Rajiv Bansal (Admin / CA)',
    canExportExcel: true,
    canCustomizeTemplates: true,
    canUploadLogo: true,
    notes: 'Annual license issued for counter hardware billing.',
    lastEmailSentAt: '2026-05-15 11:30 AM'
  }
];

export class LicenseManager {
  static getLicenses(): ClientLicense[] {
    try {
      const data = localStorage.getItem(LICENSES_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(LICENSES_STORAGE_KEY, JSON.stringify(INITIAL_LICENSES));
        return INITIAL_LICENSES;
      }
      return JSON.parse(data) as ClientLicense[];
    } catch (e) {
      console.error('Error reading licenses from localStorage:', e);
      return INITIAL_LICENSES;
    }
  }

  static saveLicenses(licenses: ClientLicense[]): void {
    try {
      localStorage.setItem(LICENSES_STORAGE_KEY, JSON.stringify(licenses));
    } catch (e) {
      console.error('Error writing licenses to localStorage:', e);
    }
  }

  static getLicenseByClientUserId(userId: string): ClientLicense | undefined {
    const licenses = this.getLicenses();
    return licenses.find(l => l.clientUserId === userId || l.clientUsername === userId);
  }

  static getLicenseByKey(key: string): ClientLicense | undefined {
    const licenses = this.getLicenses();
    const cleanKey = key.trim().toUpperCase();
    return licenses.find(l => l.licenseKey.toUpperCase() === cleanKey);
  }

  static generateLicenseKey(tier: LicenseTier, clientName: string): string {
    const tierCode = tier === 'enterprise' ? 'ENT' : tier === 'professional' ? 'PRO' : 'STR';
    const randPart1 = Math.floor(1000 + Math.random() * 9000);
    const randPart2 = Math.floor(1000 + Math.random() * 9000);
    const suffix = clientName
      .replace(/[^a-zA-Z]/g, '')
      .substring(0, 4)
      .toUpperCase() || 'GSTN';
    return `GST-${tierCode}-${randPart1}-${randPart2}-${suffix}`;
  }

  static issueLicense(params: {
    clientUserId: string;
    clientUsername: string;
    businessName: string;
    clientEmail: string;
    tier: LicenseTier;
    validityMonths: number;
    notes?: string;
  }): ClientLicense {
    const licenses = this.getLicenses();
    const today = new Date();
    const expiry = new Date();
    expiry.setMonth(today.getMonth() + params.validityMonths);

    const licenseKey = this.generateLicenseKey(params.tier, params.businessName);

    const newLicense: ClientLicense = {
      id: `lic_${Date.now()}`,
      licenseKey,
      clientUserId: params.clientUserId,
      clientUsername: params.clientUsername,
      businessName: params.businessName,
      clientEmail: params.clientEmail,
      tier: params.tier,
      status: 'active',
      issuedAt: today.toISOString().split('T')[0],
      validUntil: expiry.toISOString().split('T')[0],
      issuedBy: 'CMA Rajiv Bansal (Admin / CA)',
      canExportExcel: true,
      canCustomizeTemplates: true,
      canUploadLogo: true,
      notes: params.notes || `Licensed for ${params.validityMonths} months by Rajiv Bansal & Associates.`
    };

    // Replace if exists for this user, else add
    const index = licenses.findIndex(l => l.clientUserId === params.clientUserId);
    if (index >= 0) {
      licenses[index] = newLicense;
    } else {
      licenses.unshift(newLicense);
    }

    this.saveLicenses(licenses);
    return newLicense;
  }

  static updateLicenseStatus(licenseId: string, status: LicenseStatus): void {
    const licenses = this.getLicenses();
    const item = licenses.find(l => l.id === licenseId);
    if (item) {
      item.status = status;
      this.saveLicenses(licenses);
    }
  }

  static recordEmailSent(licenseId: string): void {
    const licenses = this.getLicenses();
    const item = licenses.find(l => l.id === licenseId);
    if (item) {
      item.lastEmailSentAt = new Date().toLocaleString();
      this.saveLicenses(licenses);
    }
  }

  /**
   * Prepares the license email kit and mailto link for direct dispatch from CMA Rajiv Bansal
   */
  static prepareEmailDraft(license: ClientLicense, sellerProfile?: SellerProfile) {
    const recipient = license.clientEmail || 'client@business.com';
    const subject = `Tax Billing Suite - Official License Key & Activation Kit [${license.businessName}]`;

    const body = `Dear ${license.businessName} Team,

Greetings from Rajiv Bansal & Associates (Cost & Management Accountants / Tax Advisors).

We are pleased to provide your authorized Master License Key for the Tax Compliant Billing & Invoicing Suite:

==================================================
TAX BILLING SUITE - MASTER LICENSE CERTIFICATE
==================================================
Business Entity  : ${license.businessName}
Client Login ID  : ${license.clientUsername}
License Key      : ${license.licenseKey}
Edition / Tier   : ${license.tier.toUpperCase()} SUITE
Validity Period  : Valid until ${license.validUntil}
Authorized By    : ${license.issuedBy}
Audit Status     : Fully Activated (GSTR-1 & Sales Register Enabled)
==================================================

INSTRUCTIONS FOR CLIENT ACTIVATION:
1. Open the Tax Billing Suite application on Desktop or Mobile.
2. Click on your Account name in the top bar or open the License Banner.
3. Select "Activate License Key" and paste your Key: ${license.licenseKey}
4. Your account will be instantly verified with full statutory invoicing and Excel report generation privileges.

STATUTORY TAX ADVISORY NOTE:
Your sales records and tax registers are monitored for monthly GST filing (GSTR-1 and GSTR-3B). Please ensure all issued invoices are maintained with appropriate HSN codes. You may download your comprehensive Excel tax report directly from the app for periodic reconciliation.

For any licensing assistance, please contact us directly:
CMA Rajiv Bansal
Managing Partner, Rajiv Bansal & Associates
Email: CMARAJIVBANSAL@gmail.com
Mobile / WhatsApp: +91 98100 12345

Warm regards,
CMA Rajiv Bansal & Associates
Tax Compliance & Statutory Advisory Team`;

    const mailtoUrl = `mailto:${encodeURIComponent(recipient)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    return {
      recipient,
      subject,
      body,
      mailtoUrl
    };
  }

  /**
   * Validates a license key entered by a client
   */
  static verifyAndActivateKey(key: string, user: UserAccount): {
    success: boolean;
    message: string;
    license?: ClientLicense;
  } {
    const cleanKey = key.trim().toUpperCase();
    if (!cleanKey) {
      return { success: false, message: 'Please enter a valid License Key.' };
    }

    const licenses = this.getLicenses();
    let license = licenses.find(l => l.licenseKey.toUpperCase() === cleanKey);

    if (!license) {
      // If it looks like a valid pattern from CMA Rajiv Bansal, let's auto-register it
      if (cleanKey.startsWith('GST-')) {
        const today = new Date().toISOString().split('T')[0];
        const expiry = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        license = {
          id: `lic_${Date.now()}`,
          licenseKey: cleanKey,
          clientUserId: user.id,
          clientUsername: user.username,
          businessName: user.businessName,
          clientEmail: user.email,
          tier: cleanKey.includes('PRO') ? 'professional' : cleanKey.includes('ENT') ? 'enterprise' : 'starter',
          status: 'active',
          issuedAt: today,
          validUntil: expiry,
          issuedBy: 'CMA Rajiv Bansal (Admin / CA)',
          canExportExcel: true,
          canCustomizeTemplates: true,
          canUploadLogo: true,
          notes: 'Activated online with valid key.'
        };
        licenses.push(license);
        this.saveLicenses(licenses);
        return {
          success: true,
          message: `License successfully activated for ${user.businessName}! Valid until ${license.validUntil}.`,
          license
        };
      }
      return {
        success: false,
        message: 'Invalid License Key. Please contact CMA Rajiv Bansal at CMARAJIVBANSAL@gmail.com to request an authorized key.'
      };
    }

    if (license.status === 'suspended') {
      return {
        success: false,
        message: 'This license has been suspended by the administrator. Please contact CMA Rajiv Bansal.'
      };
    }

    if (new Date(license.validUntil) < new Date()) {
      return {
        success: false,
        message: `This license expired on ${license.validUntil}. Please request a renewal from CMA Rajiv Bansal.`
      };
    }

    // Attach license to client if not already
    license.clientUserId = user.id;
    license.clientUsername = user.username;
    license.businessName = user.businessName;
    license.status = 'active';
    this.saveLicenses(licenses);

    return {
      success: true,
      message: `License Key verified! Activated ${license.tier.toUpperCase()} edition for ${user.businessName}. Valid until ${license.validUntil}.`,
      license
    };
  }
}
