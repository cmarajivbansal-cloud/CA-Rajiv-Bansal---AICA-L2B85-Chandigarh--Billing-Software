import {
  INITIAL_CLIENT_BUYERS,
  INITIAL_INVOICES,
  INITIAL_PRODUCTS,
  INITIAL_SELLER_PROFILES,
  INITIAL_USERS
} from '../data/seedData';
import { ClientBuyer, Invoice, ProductServiceItem, SellerProfile, UserAccount } from '../types';

const STORAGE_KEYS = {
  USERS: 'billing_app_users_v1',
  CURRENT_USER: 'billing_app_current_user_v1',
  SELLER_PROFILES: 'billing_app_seller_profiles_v1',
  CLIENT_BUYERS: 'billing_app_client_buyers_v1',
  PRODUCTS: 'billing_app_products_v1',
  INVOICES: 'billing_app_invoices_v1',
};

// Helper to safely read from localStorage
function getStoredItem<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Error loading key ${key} from storage:`, error);
    return fallback;
  }
}

// Helper to safely write to localStorage
function setStoredItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error saving key ${key} to storage:`, error);
  }
}

export class StorageService {
  // Users & Session
  static getUsers(): UserAccount[] {
    return getStoredItem<UserAccount[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  }

  static getCurrentUser(): UserAccount {
    return getStoredItem<UserAccount>(STORAGE_KEYS.CURRENT_USER, INITIAL_USERS[1]); // Default to Client (Apex Tech)
  }

  static setCurrentUser(user: UserAccount): void {
    setStoredItem(STORAGE_KEYS.CURRENT_USER, user);
  }

  // Seller Profiles
  static getSellerProfiles(): SellerProfile[] {
    return getStoredItem<SellerProfile[]>(STORAGE_KEYS.SELLER_PROFILES, INITIAL_SELLER_PROFILES);
  }

  static getSellerProfile(id: string): SellerProfile | undefined {
    const profiles = this.getSellerProfiles();
    return profiles.find(p => p.id === id);
  }

  static saveSellerProfile(profile: SellerProfile): void {
    const profiles = this.getSellerProfiles();
    const index = profiles.findIndex(p => p.id === profile.id);
    if (index >= 0) {
      profiles[index] = profile;
    } else {
      profiles.push(profile);
    }
    setStoredItem(STORAGE_KEYS.SELLER_PROFILES, profiles);
  }

  // Client Buyers (Buyers of the current business)
  static getClientBuyers(ownerClientId?: string): ClientBuyer[] {
    const buyers = getStoredItem<ClientBuyer[]>(STORAGE_KEYS.CLIENT_BUYERS, INITIAL_CLIENT_BUYERS);
    if (!ownerClientId) return buyers;
    return buyers.filter(b => b.ownerClientId === ownerClientId);
  }

  static saveClientBuyer(buyer: ClientBuyer): void {
    const buyers = getStoredItem<ClientBuyer[]>(STORAGE_KEYS.CLIENT_BUYERS, INITIAL_CLIENT_BUYERS);
    const index = buyers.findIndex(b => b.id === buyer.id);
    if (index >= 0) {
      buyers[index] = buyer;
    } else {
      buyers.unshift(buyer);
    }
    setStoredItem(STORAGE_KEYS.CLIENT_BUYERS, buyers);
  }

  static deleteClientBuyer(id: string): void {
    const buyers = getStoredItem<ClientBuyer[]>(STORAGE_KEYS.CLIENT_BUYERS, INITIAL_CLIENT_BUYERS);
    setStoredItem(STORAGE_KEYS.CLIENT_BUYERS, buyers.filter(b => b.id !== id));
  }

  // Products & Services
  static getProducts(ownerClientId?: string): ProductServiceItem[] {
    const prods = getStoredItem<ProductServiceItem[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    if (!ownerClientId) return prods;
    return prods.filter(p => p.ownerClientId === ownerClientId);
  }

  static saveProduct(product: ProductServiceItem): void {
    const prods = getStoredItem<ProductServiceItem[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    const index = prods.findIndex(p => p.id === product.id);
    if (index >= 0) {
      prods[index] = product;
    } else {
      prods.unshift(product);
    }
    setStoredItem(STORAGE_KEYS.PRODUCTS, prods);
  }

  static deleteProduct(id: string): void {
    const prods = getStoredItem<ProductServiceItem[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    setStoredItem(STORAGE_KEYS.PRODUCTS, prods.filter(p => p.id !== id));
  }

  // Invoices
  static getInvoices(ownerClientId?: string): Invoice[] {
    const invoices = getStoredItem<Invoice[]>(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
    if (!ownerClientId) return invoices;
    return invoices.filter(inv => inv.createdByClientId === ownerClientId);
  }

  static getInvoiceById(id: string): Invoice | undefined {
    const invoices = getStoredItem<Invoice[]>(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
    return invoices.find(inv => inv.id === id);
  }

  static saveInvoice(invoice: Invoice): void {
    const invoices = getStoredItem<Invoice[]>(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
    const index = invoices.findIndex(i => i.id === invoice.id);
    if (index >= 0) {
      invoices[index] = invoice;
    } else {
      invoices.unshift(invoice);
    }
    setStoredItem(STORAGE_KEYS.INVOICES, invoices);

    // If this is a new invoice, increment the seller's next invoice number
    if (index < 0) {
      const seller = this.getSellerProfile(invoice.createdByClientId);
      if (seller) {
        seller.nextInvoiceNumber += 1;
        this.saveSellerProfile(seller);
      }
    }
  }

  static deleteInvoice(id: string): void {
    const invoices = getStoredItem<Invoice[]>(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
    setStoredItem(STORAGE_KEYS.INVOICES, invoices.filter(i => i.id !== id));
  }

  // Reset to initial demo database
  static resetAllData(): void {
    setStoredItem(STORAGE_KEYS.USERS, INITIAL_USERS);
    setStoredItem(STORAGE_KEYS.CURRENT_USER, INITIAL_USERS[1]);
    setStoredItem(STORAGE_KEYS.SELLER_PROFILES, INITIAL_SELLER_PROFILES);
    setStoredItem(STORAGE_KEYS.CLIENT_BUYERS, INITIAL_CLIENT_BUYERS);
    setStoredItem(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    setStoredItem(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
  }
}
