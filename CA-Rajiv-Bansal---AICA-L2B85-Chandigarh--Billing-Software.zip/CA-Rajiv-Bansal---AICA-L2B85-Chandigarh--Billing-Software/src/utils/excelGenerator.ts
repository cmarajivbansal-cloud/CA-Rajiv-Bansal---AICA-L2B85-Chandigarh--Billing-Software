import * as XLSX from 'xlsx';
import { Invoice, SellerProfile } from '../types';

/**
 * Generates and downloads a comprehensive Excel file (.xlsx) for Tax Compliance & Accounting
 */
export function exportTaxComplianceExcel(
  invoices: Invoice[],
  seller?: SellerProfile,
  reportTitle: string = 'Tax_Compliance_Sales_Register'
) {
  const wb = XLSX.utils.book_new();

  // --- SHEET 1: GSTR-1 Sales Register ---
  const salesRegisterData = invoices.map((inv, index) => ({
    'Sr No': index + 1,
    'Invoice No': inv.invoiceNumber,
    'Invoice Date': inv.invoiceDate,
    'Customer Name': inv.buyer.companyName || inv.buyer.name,
    'Customer GSTIN': inv.buyer.gstin || 'Unregistered',
    'Customer State / POS': inv.buyer.placeOfSupply || inv.buyer.billingAddress.state,
    'Supply Type': inv.isInterState ? 'Inter-State' : 'Intra-State',
    'Invoice Type': inv.buyer.gstin ? 'B2B (Registered)' : 'B2C (Consumer)',
    'Taxable Value (₹)': inv.totalTaxableAmount,
    'CGST Amount (₹)': inv.cgstTotal,
    'SGST Amount (₹)': inv.sgstTotal,
    'IGST Amount (₹)': inv.igstTotal,
    'Total Tax (₹)': inv.totalTax,
    'Round Off (₹)': inv.roundOff,
    'Invoice Grand Total (₹)': inv.grandTotal,
    'Payment Status': inv.status.toUpperCase(),
    'Payment Date': inv.paymentDate || '-',
    'Payment Method': inv.paymentMethod || '-',
    'PO Number': inv.poNumber || '-',
    'Seller Business': inv.seller.businessName,
    'Seller GSTIN': inv.seller.gstin
  }));

  const wsSales = XLSX.utils.json_to_sheet(salesRegisterData);
  // Auto-fit column widths
  wsSales['!cols'] = [
    { wch: 6 },  // Sr No
    { wch: 16 }, // Invoice No
    { wch: 12 }, // Date
    { wch: 28 }, // Customer Name
    { wch: 18 }, // GSTIN
    { wch: 20 }, // POS
    { wch: 14 }, // Supply Type
    { wch: 18 }, // Invoice Type
    { wch: 16 }, // Taxable
    { wch: 14 }, // CGST
    { wch: 14 }, // SGST
    { wch: 14 }, // IGST
    { wch: 14 }, // Total Tax
    { wch: 12 }, // Round Off
    { wch: 18 }, // Grand Total
    { wch: 14 }, // Status
    { wch: 14 }, // Payment Date
    { wch: 16 }, // Method
    { wch: 14 }, // PO
    { wch: 24 }, // Seller
    { wch: 18 }, // Seller GSTIN
  ];
  XLSX.utils.book_append_sheet(wb, wsSales, 'Sales Register (GSTR-1)');

  // --- SHEET 2: HSN / SAC Summary (Mandatory for GST Compliance) ---
  const hsnMap: {
    [key: string]: {
      hsnCode: string;
      description: string;
      uqc: string;
      totalQty: number;
      taxableValue: number;
      cgst: number;
      sgst: number;
      igst: number;
      totalTax: number;
      totalValue: number;
    };
  } = {};

  invoices.forEach((inv) => {
    inv.items.forEach((item) => {
      const code = item.hsnSacCode || 'N/A';
      if (!hsnMap[code]) {
        hsnMap[code] = {
          hsnCode: code,
          description: item.description || 'Goods / Services',
          uqc: item.unit || 'NOS',
          totalQty: 0,
          taxableValue: 0,
          cgst: 0,
          sgst: 0,
          igst: 0,
          totalTax: 0,
          totalValue: 0,
        };
      }
      hsnMap[code].totalQty += item.quantity;
      hsnMap[code].taxableValue += item.taxableAmount;
      hsnMap[code].cgst += item.cgstAmount;
      hsnMap[code].sgst += item.sgstAmount;
      hsnMap[code].igst += item.igstAmount;
      hsnMap[code].totalTax += (item.cgstAmount + item.sgstAmount + item.igstAmount);
      hsnMap[code].totalValue += item.totalAmount;
    });
  });

  const hsnSummaryData = Object.values(hsnMap).map((h) => ({
    'HSN / SAC Code': h.hsnCode,
    'Description': h.description,
    'Unit of Measure (UQC)': h.uqc,
    'Total Quantity': Number(h.totalQty.toFixed(2)),
    'Total Taxable Value (₹)': Number(h.taxableValue.toFixed(2)),
    'Central Tax CGST (₹)': Number(h.cgst.toFixed(2)),
    'State Tax SGST (₹)': Number(h.sgst.toFixed(2)),
    'Integrated Tax IGST (₹)': Number(h.igst.toFixed(2)),
    'Total Tax (₹)': Number(h.totalTax.toFixed(2)),
    'Total Value (₹)': Number(h.totalValue.toFixed(2)),
  }));

  const wsHsn = XLSX.utils.json_to_sheet(hsnSummaryData);
  wsHsn['!cols'] = [
    { wch: 16 }, { wch: 30 }, { wch: 14 }, { wch: 14 },
    { wch: 20 }, { wch: 18 }, { wch: 18 }, { wch: 18 },
    { wch: 18 }, { wch: 20 }
  ];
  XLSX.utils.book_append_sheet(wb, wsHsn, 'HSN-SAC Summary');

  // --- SHEET 3: GST Slab-wise Tax Summary (Audit Ready) ---
  const slabMap: {
    [rate: number]: {
      taxable: number;
      cgst: number;
      sgst: number;
      igst: number;
      totalTax: number;
    };
  } = { 0: { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 },
        5: { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 },
        12: { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 },
        18: { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 },
        28: { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 } };

  invoices.forEach((inv) => {
    inv.items.forEach((item) => {
      const rate = item.gstRate || 0;
      if (!slabMap[rate]) {
        slabMap[rate] = { taxable: 0, cgst: 0, sgst: 0, igst: 0, totalTax: 0 };
      }
      slabMap[rate].taxable += item.taxableAmount;
      slabMap[rate].cgst += item.cgstAmount;
      slabMap[rate].sgst += item.sgstAmount;
      slabMap[rate].igst += item.igstAmount;
      slabMap[rate].totalTax += (item.cgstAmount + item.sgstAmount + item.igstAmount);
    });
  });

  const slabData = Object.entries(slabMap).map(([rate, vals]) => ({
    'GST Rate Slab': `${rate}%`,
    'Taxable Turnover (₹)': Number(vals.taxable.toFixed(2)),
    'CGST Liability (₹)': Number(vals.cgst.toFixed(2)),
    'SGST Liability (₹)': Number(vals.sgst.toFixed(2)),
    'IGST Liability (₹)': Number(vals.igst.toFixed(2)),
    'Total Output Tax (₹)': Number(vals.totalTax.toFixed(2)),
  }));

  const wsSlab = XLSX.utils.json_to_sheet(slabData);
  wsSlab['!cols'] = [
    { wch: 16 }, { wch: 22 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 20 }
  ];
  XLSX.utils.book_append_sheet(wb, wsSlab, 'Tax Liability Summary');

  // --- SHEET 4: Itemized Master Line-Items ---
  const lineItemData: any[] = [];
  invoices.forEach((inv) => {
    inv.items.forEach((item, itemIdx) => {
      lineItemData.push({
        'Invoice No': inv.invoiceNumber,
        'Invoice Date': inv.invoiceDate,
        'Buyer Name': inv.buyer.companyName || inv.buyer.name,
        'Item Index': itemIdx + 1,
        'Item Description': item.description,
        'HSN / SAC': item.hsnSacCode,
        'Quantity': item.quantity,
        'Unit': item.unit,
        'Unit Rate (₹)': item.unitPrice,
        'Discount %': item.discountPercent,
        'Discount Amt (₹)': item.discountAmount,
        'Taxable Amt (₹)': item.taxableAmount,
        'GST Rate %': item.gstRate,
        'CGST (₹)': item.cgstAmount,
        'SGST (₹)': item.sgstAmount,
        'IGST (₹)': item.igstAmount,
        'Total (₹)': item.totalAmount
      });
    });
  });

  const wsItems = XLSX.utils.json_to_sheet(lineItemData);
  wsItems['!cols'] = [
    { wch: 16 }, { wch: 12 }, { wch: 24 }, { wch: 10 },
    { wch: 28 }, { wch: 14 }, { wch: 10 }, { wch: 8 },
    { wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 16 },
    { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 16 }
  ];
  XLSX.utils.book_append_sheet(wb, wsItems, 'Detailed Item Ledger');

  const now = new Date().toISOString().split('T')[0];
  const sellerSuffix = seller ? `_${seller.businessName.replace(/\s+/g, '_')}` : '_Master_Admin';
  const fileName = `${reportTitle}${sellerSuffix}_${now}.xlsx`;

  XLSX.writeFile(wb, fileName);
}
