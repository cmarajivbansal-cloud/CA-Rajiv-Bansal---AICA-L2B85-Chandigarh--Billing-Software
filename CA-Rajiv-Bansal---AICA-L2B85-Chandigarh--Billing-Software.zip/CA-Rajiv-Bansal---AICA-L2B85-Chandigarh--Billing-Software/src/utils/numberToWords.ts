const ONES = [
  '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
  'Seventeen', 'Eighteen', 'Nineteen'
];

const TENS = [
  '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
];

function convertLessThanThousand(num: number): string {
  if (num === 0) return '';
  if (num < 20) return ONES[num] + ' ';
  if (num < 100) return TENS[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + ONES[num % 10] : '') + ' ';
  return ONES[Math.floor(num / 100)] + ' Hundred ' + (num % 100 !== 0 ? convertLessThanThousand(num % 100) : '');
}

/**
 * Converts numbers into words following Indian numbering system (Crore, Lakh, Thousand)
 */
export function numberToIndianWords(amount: number, currency: string = 'INR'): string {
  if (isNaN(amount) || amount === 0) {
    return `${currency} Zero Only`;
  }

  const rounded = Math.round((amount + Number.EPSILON) * 100) / 100;
  const isNegative = rounded < 0;
  const positiveAmount = Math.abs(rounded);

  const integerPart = Math.floor(positiveAmount);
  const decimalPart = Math.round((positiveAmount - integerPart) * 100);

  let words = '';

  const crore = Math.floor(integerPart / 10000000);
  let remainder = integerPart % 10000000;

  const lakh = Math.floor(remainder / 100000);
  remainder = remainder % 100000;

  const thousand = Math.floor(remainder / 1000);
  remainder = remainder % 1000;

  const hundreds = remainder;

  if (crore > 0) {
    words += convertLessThanThousand(crore).trim() + ' Crore ';
  }
  if (lakh > 0) {
    words += convertLessThanThousand(lakh).trim() + ' Lakh ';
  }
  if (thousand > 0) {
    words += convertLessThanThousand(thousand).trim() + ' Thousand ';
  }
  if (hundreds > 0) {
    words += convertLessThanThousand(hundreds).trim() + ' ';
  }

  words = words.trim();
  if (!words) {
    words = 'Zero';
  }

  let result = (isNegative ? 'Minus ' : '') + currency + ' ' + words;

  if (decimalPart > 0) {
    const decimalWords = convertLessThanThousand(decimalPart).trim();
    result += ` and ${decimalWords} Paise`;
  }

  return result + ' Only';
}

export function formatCurrency(amount: number, symbol: string = '₹'): string {
  if (isNaN(amount)) return `${symbol}0.00`;
  return `${symbol}${amount.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}
