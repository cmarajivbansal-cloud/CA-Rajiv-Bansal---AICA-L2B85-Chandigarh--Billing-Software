import { InvoiceLineItem, StateCodeMap } from '../types';

export const INDIAN_STATES: StateCodeMap = {
  '01': { code: '01', name: 'Jammu & Kashmir' },
  '02': { code: '02', name: 'Himachal Pradesh' },
  '03': { code: '03', name: 'Punjab' },
  '04': { code: '04', name: 'Chandigarh' },
  '05': { code: '05', name: 'Uttarakhand' },
  '06': { code: '06', name: 'Haryana' },
  '07': { code: '07', name: 'Delhi' },
  '08': { code: '08', name: 'Rajasthan' },
  '09': { code: '09', name: 'Uttar Pradesh' },
  '10': { code: '10', name: 'Bihar' },
  '11': { code: '11', name: 'Sikkim' },
  '12': { code: '12', name: 'Arunachal Pradesh' },
  '13': { code: '13', name: 'Nagaland' },
  '14': { code: '14', name: 'Manipur' },
  '15': { code: '15', name: 'Mizoram' },
  '16': { code: '16', name: 'Tripura' },
  '17': { code: '17', name: 'Meghalaya' },
  '18': { code: '18', name: 'Assam' },
  '19': { code: '19', name: 'West Bengal' },
  '20': { code: '20', name: 'Jharkhand' },
  '21': { code: '21', name: 'Odisha' },
  '22': { code: '22', name: 'Chhattisgarh' },
  '23': { code: '23', name: 'Madhya Pradesh' },
  '24': { code: '24', name: 'Gujarat' },
  '27': { code: '27', name: 'Maharashtra' },
  '29': { code: '29', name: 'Karnataka' },
  '30': { code: '30', name: 'Goa' },
  '32': { code: '32', name: 'Kerala' },
  '33': { code: '33', name: 'Tamil Nadu' },
  '36': { code: '36', name: 'Telangana' },
  '37': { code: '37', name: 'Andhra Pradesh' },
  '38': { code: '38', name: 'Ladakh' },
  '97': { code: '97', name: 'Other Territory' }
};

export const GST_SLABS = [0, 5, 12, 18, 28];

export function getStateByGstin(gstin: string): { stateCode: string; stateName: string } | null {
  if (!gstin || gstin.length < 2) return null;
  const code = gstin.substring(0, 2);
  const state = INDIAN_STATES[code];
  return state ? { stateCode: state.code, stateName: state.name } : null;
}

export function calculateLineItem(
  item: Omit<InvoiceLineItem, 'discountAmount' | 'taxableAmount' | 'cgstRate' | 'cgstAmount' | 'sgstRate' | 'sgstAmount' | 'igstRate' | 'igstAmount' | 'totalAmount'>,
  isInterState: boolean
): InvoiceLineItem {
  const qty = Number(item.quantity) || 0;
  const rate = Number(item.unitPrice) || 0;
  const gross = qty * rate;
  
  const discountPct = Number(item.discountPercent) || 0;
  const discountAmount = (gross * discountPct) / 100;
  const taxableAmount = Math.max(0, gross - discountAmount);

  const gstRate = Number(item.gstRate) || 0;

  let cgstRate = 0;
  let cgstAmount = 0;
  let sgstRate = 0;
  let sgstAmount = 0;
  let igstRate = 0;
  let igstAmount = 0;

  if (isInterState) {
    igstRate = gstRate;
    igstAmount = (taxableAmount * igstRate) / 100;
  } else {
    cgstRate = gstRate / 2;
    cgstAmount = (taxableAmount * cgstRate) / 100;
    sgstRate = gstRate / 2;
    sgstAmount = (taxableAmount * sgstRate) / 100;
  }

  const totalAmount = taxableAmount + cgstAmount + sgstAmount + igstAmount;

  return {
    ...item,
    quantity: qty,
    unitPrice: rate,
    discountPercent: discountPct,
    discountAmount: Number(discountAmount.toFixed(2)),
    taxableAmount: Number(taxableAmount.toFixed(2)),
    gstRate,
    cgstRate: Number(cgstRate.toFixed(2)),
    cgstAmount: Number(cgstAmount.toFixed(2)),
    sgstRate: Number(sgstRate.toFixed(2)),
    sgstAmount: Number(sgstAmount.toFixed(2)),
    igstRate: Number(igstRate.toFixed(2)),
    igstAmount: Number(igstAmount.toFixed(2)),
    totalAmount: Number(totalAmount.toFixed(2)),
  };
}

export function calculateInvoiceTotals(items: InvoiceLineItem[]) {
  const subTotal = items.reduce((acc, it) => acc + (it.quantity * it.unitPrice), 0);
  const totalDiscount = items.reduce((acc, it) => acc + it.discountAmount, 0);
  const totalTaxableAmount = items.reduce((acc, it) => acc + it.taxableAmount, 0);
  const cgstTotal = items.reduce((acc, it) => acc + it.cgstAmount, 0);
  const sgstTotal = items.reduce((acc, it) => acc + it.sgstAmount, 0);
  const igstTotal = items.reduce((acc, it) => acc + it.igstAmount, 0);
  const totalTax = cgstTotal + sgstTotal + igstTotal;
  
  const rawGrandTotal = totalTaxableAmount + totalTax;
  const grandTotal = Math.round(rawGrandTotal);
  const roundOff = Number((grandTotal - rawGrandTotal).toFixed(2));

  return {
    subTotal: Number(subTotal.toFixed(2)),
    totalDiscount: Number(totalDiscount.toFixed(2)),
    totalTaxableAmount: Number(totalTaxableAmount.toFixed(2)),
    cgstTotal: Number(cgstTotal.toFixed(2)),
    sgstTotal: Number(sgstTotal.toFixed(2)),
    igstTotal: Number(igstTotal.toFixed(2)),
    totalTax: Number(totalTax.toFixed(2)),
    roundOff,
    grandTotal,
  };
}
