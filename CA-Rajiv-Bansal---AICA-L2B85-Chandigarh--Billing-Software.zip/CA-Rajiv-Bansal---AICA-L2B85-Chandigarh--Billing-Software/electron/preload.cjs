const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getNetworkInfo: () => ipcRenderer.invoke('get-network-info'),
  printPage: () => ipcRenderer.send('print-page'),
  isElectron: true,
  platform: process.platform,
  version: process.versions.electron
});
