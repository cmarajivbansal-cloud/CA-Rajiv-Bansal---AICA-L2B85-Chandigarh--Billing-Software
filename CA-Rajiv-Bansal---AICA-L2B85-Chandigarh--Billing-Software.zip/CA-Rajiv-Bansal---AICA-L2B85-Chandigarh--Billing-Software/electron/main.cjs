const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const http = require('http');
const fs = require('fs');
const os = require('os');

let mainWindow = null;
let server = null;
const DEFAULT_PORT = 3850;
let activePort = DEFAULT_PORT;

// Get local network IPv4 addresses
function getLocalNetworkAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({
          name: name,
          address: iface.address,
          url: `http://${iface.address}:${activePort}`
        });
      }
    }
  }
  return addresses;
}

// Simple MIME type resolver for static server
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'font/otf',
    '.wasm': 'application/wasm',
    '.pdf': 'application/pdf',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  };
  return mimeTypes[ext] || 'application/octet-stream';
}

// Start built-in local HTTP server for LAN sharing
function startLocalServer(distPath) {
  return new Promise((resolve) => {
    server = http.createServer((req, res) => {
      // Decode URL to handle query parameters and special chars
      let reqUrl = req.url.split('?')[0];
      if (reqUrl === '/') reqUrl = '/index.html';

      let safePath = path.normalize(path.join(distPath, reqUrl));
      if (!safePath.startsWith(distPath)) {
        res.writeHead(403);
        return res.end('Forbidden');
      }

      fs.stat(safePath, (err, stats) => {
        if (err || !stats.isFile()) {
          // Fallback to index.html for SPA routing
          const indexPath = path.join(distPath, 'index.html');
          fs.readFile(indexPath, (readErr, content) => {
            if (readErr) {
              res.writeHead(404);
              return res.end('Not Found');
            }
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(content);
          });
          return;
        }

        fs.readFile(safePath, (readErr, content) => {
          if (readErr) {
            res.writeHead(500);
            return res.end('Internal Server Error');
          }
          res.writeHead(200, { 'Content-Type': getMimeType(safePath) });
          res.end(content);
        });
      });
    });

    server.listen(activePort, '0.0.0.0', () => {
      console.log(`Local LAN server running on port ${activePort}`);
      resolve(activePort);
    });

    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        activePort += 1;
        server.listen(activePort, '0.0.0.0');
      } else {
        console.error('Server error:', err);
        resolve(null);
      }
    });
  });
}

function createWindow() {
  const iconPath = path.join(__dirname, '../assets/icon.png');
  const hasIcon = fs.existsSync(iconPath);

  mainWindow = new BrowserWindow({
    width: 1366,
    height: 868,
    minWidth: 1024,
    minHeight: 700,
    title: 'Tax Compliant Billing & Invoicing Suite',
    icon: hasIcon ? iconPath : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false // allow local assets
    },
    show: false,
    backgroundColor: '#0f172a'
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize();
    mainWindow.show();
  });

  // Determine load source
  const isDev = !app.isPackaged && process.env.NODE_ENV === 'development';
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    const distPath = path.join(__dirname, '../dist');
    startLocalServer(distPath);
    mainWindow.loadFile(path.join(distPath, 'index.html'));
  }

  // Build native application menu
  const menuTemplate = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Print Active Invoice / Page',
          accelerator: 'CmdOrCtrl+P',
          click: () => {
            mainWindow.webContents.print({ silent: false, printBackground: true });
          }
        },
        { type: 'separator' },
        {
          label: 'Local Network (LAN) Sharing Info...',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            const addrs = getLocalNetworkAddresses();
            let msg = `Your Billing Suite is running locally and can be accessed across your local Wi-Fi / LAN network.\n\n`;
            if (addrs.length === 0) {
              msg += `Localhost: http://localhost:${activePort}`;
            } else {
              msg += `Connect any smartphone, tablet, or PC on your network to:\n\n`;
              addrs.forEach(a => {
                msg += `â€¢ [${a.name}]: ${a.url}\n`;
              });
            }
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Local Network (LAN) Sharing',
              message: 'Share On Local Network',
              detail: msg,
              buttons: ['OK', 'Copy First LAN URL'],
              defaultId: 0
            }).then(({ response }) => {
              if (response === 1 && addrs.length > 0) {
                const { clipboard } = require('electron');
                clipboard.writeText(addrs[0].url);
              }
            });
          }
        },
        { type: 'separator' },
        { role: 'reload', label: 'Refresh App' },
        { role: 'forceReload', label: 'Force Refresh' },
        { type: 'separator' },
        { role: 'quit', label: 'Exit Application' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'resetZoom', label: 'Actual Size' },
        { role: 'zoomIn', label: 'Zoom In' },
        { role: 'zoomOut', label: 'Zoom Out' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Toggle Full Screen' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About Tax Compliant Billing Suite',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About',
              message: 'Tax Compliant Billing & Invoicing Suite',
              detail: `Multi-Tenant Enterprise Invoicing & Tax Compliance Suite\nVersion: 1.0.0\nAuthor: CMA Rajiv Bansal\nBuilt with Electron & React\n\nRuns fully offline on any Windows system with instant local network sharing support.`,
              buttons: ['OK']
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC Handlers
ipcMain.handle('get-network-info', () => {
  return {
    port: activePort,
    addresses: getLocalNetworkAddresses()
  };
});

ipcMain.on('print-page', () => {
  if (mainWindow) {
    mainWindow.webContents.print({ silent: false, printBackground: true });
  }
});

// Single instance lock
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(createWindow);

  app.on('window-all-closed', () => {
    if (server) {
      server.close();
    }
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
}
